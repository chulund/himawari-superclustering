import arcpy

in_rows = arcpy.SearchCursor(r"D:/Research/2021/Gridding/ExportTirData/rmit_drops.csv")

point = arcpy.Point()
array = arcpy.Array()

featureList = []
#arcpy.CreateFeatureclass_management("D:/Research/2021/Gridding/ExportTirData/", "RMIT_DROPS.shp", "POLYLINE", "EPSG:4326", "DISABLED", "DISABLED")
cursor = arcpy.InsertCursor(r"D:/Research/2021/Gridding/ExportTirData/RMIT_DROPS.shp")
feat = cursor.newRow()

for in_row in in_rows:
    # Set X and Y for start and end points
    point.X = float(in_row.startLongitude)
    point.Y = float(in_row.startLatitude)
    array.add(point)
    if in_row.endLongitude == 'NA' or in_row.endLongitude == 'NA':
        point.X = float(in_row.startLongitude)
        point.Y = float(in_row.startLatitude)
    else:
        point.X = float(in_row.endLongitude)
        point.Y = float(in_row.endLatitude)
    array.add(point)   
    # Create a Polyline object based on the array of points
    polyline = arcpy.Polyline(array)
    # Clear the array for future use
    array.removeAll()
    # Append to the list of Polyline objects
    featureList.append(polyline)
    # Insert the feature
    feat.shape = polyline
    feat.ID = in_row.id
    cursor.insertRow(feat)
del feat
del cursor