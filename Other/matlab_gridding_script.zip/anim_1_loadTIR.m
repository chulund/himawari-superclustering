%load himawari TIR data and study case vertices for study case 1
clc;clear
MIR=load('../Matfile/MIR_studycase1.mat');
TIR=load('../Matfile/TIR_studycase1.mat');

%load data
vertices=readmatrix('D:/Research/2021/Gridding/Data/foranimation/studycase1_vertices.csv');
%get rid of extra coordinates
vertices(1:5:end,:)=[];
%create polygon 
for i=1:(length(vertices)/4)
    studycase{i}.shape=polyshape(vertices(4*(i-1)+1:4*i,2),vertices(4*(i-1)+1:4*i,3));
    studycase{i}.timespan=MIR.data(i).timespan;
    %remove zeroes
    TIRi=TIR.data(i).brightness;
    MIRi=MIR.data(i).brightness;
    k=find(TIRi==0);
    TIRi(k)=NaN;
    k=find(MIRi==0);
    MIRi(k)=NaN;
    studycase{i}.TIR=TIRi;
    studycase{i}.MIR=MIRi;
    clear TIN
end

save('../Matfile/data_studycase1.mat','studycase')


listcoord=table2array(readtable('D:\Research\2021\Gridding\ExportTirData\list_coord_noheader.csv'));

%export study case to Simon
fid=fopen('TIR&MIR_studycase1_v2.csv','w');
fprintf(fid,'pixelID,time,long,lat,MIR(band7),TIR(band13)\n')
counter=1;
for i=1:length(studycase)
    for j=1:length(studycase{i}.timespan)
        fprintf(fid,'%i,%s,%f,%f,%f,%f\n',i,datestr(studycase{i}.timespan(j),'DD-mm-YYYY HH:MM:SS'),listcoord(i,4),listcoord(i,5),studycase{i}.MIR(j),studycase{i}.TIR(j));
        %sprintf(fid,'%s,%f,%f,%f\n',datestr(data(i).timespan(j),'DD-mm-YYYY HH:MM:SS'),listcoord(i,4),listcoord(i,5),data(i).brightness(j));
        counter=counter+1;
    end
end
fclose(fid)