%read tranformed data form cs2cs command
clc;clear;
fid=fopen('../Fileout/XY_transformed1.txt');
counter=1;
h=waitbar(0,'pleasewait');
while ~feof(fid)
    waitbar(counter/1982902,h,sprintf('%.2f%%',counter*100/273000))
    line=fgetl(fid);
    temp=strsplit(line);
    %lat
    temp2=sscanf(temp{1},'%fd%f''%f""%s');
    if length(temp2)==1
        temp2(2)=0;temp2(3)=0;
    end
    if length(temp2)==2
        temp2(3)=0;
    end
    lat(counter)=temp2(1)+temp2(2)/60+temp2(3)/3600;
    if strcmp(temp{1}(end),'S')
        lat(counter)=-lat(counter);
    end
    %long
    temp3=sscanf(temp{2},'%fd%f''%f');
    if length(temp3)==1
        temp3(2)=0;temp3(3)=0;
    end
    if length(temp3)==2
        temp3(3)=0;
    end
    long(counter)=temp3(1)+temp3(2)/60+temp3(3)/3600;
    counter=counter+1;
    end
fclose(fid);
close(h);
save ../Fileout/XY_transformed1.mat lat long 
if 0
    
    plot(long,lat,'x')
    hold on
    coastal=load('coast_i_aus.mat');
    plot(coastal.long,coastal.lat,'-b')
    unik=load('../Matfile/unik.mat');
    plot(unik.unik(:,1),unik.unik(:,2),'xr')
end
