%plot anim 1 cluster zone
clc;clear;
load('../Matfile/hotspotpoly_clusterzone3.mat')
load('../Matfile/clusterzone3.mat')

%sort data per time
timeunique=unique(cluster(:,1));
timeall=linspace(min(timeunique),max(timeunique),(6*24*(floor(max(timeunique))-floor(min(timeunique))))+10);

s = get(0, 'ScreenSize');
colorschemen=flipud(hot(length(timeunique)+100));
colorschemen(1:100,:)=[]; %remove whitepart of the colorscheme
Radius=1.5/111; %15km
h=waitbar(0,'pleasewait');
for i=985:length(hotspotpoly)
    waitbar(i/length(hotspotpoly),h,sprintf('%.2f%%',i*100/length(hotspotpoly)))

    f = figure('visible', 'on','Position', [0 0 s(3) s(4)]);
    set(gca,'XLim',[146.4 147.6],'YLim',[-37.4 -36.6]);
    hold on
    ratiofix
    for j=1:i
        if isfield(hotspotpoly{j},'shape')
            for k=1:length(hotspotpoly{j})
                colorindices=find(hotspotpoly{j}.time==timeunique);
                plot(hotspotpoly{j}.shape(k),'FaceColor',colorschemen(colorindices,:),'EdgeColor',colorschemen(colorindices,:),'FaceAlpha',1)
            end
            
        end
    end
    set(get(gca,'title'),'string',(sprintf('Study Case 1 hotspot clusters - %s',datestr(timeall(i),'DD/mm/YYYY HH:MM UTC'))))
    exportgraphics(f,sprintf('D:/Research/2021/Gridding/Figures/clusteranim/zone3_%04d.png',i))
    close(f)
end

close(h)
load chirp
sound(y,Fs)