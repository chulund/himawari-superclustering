%obtain TIR data from NCI
clc;clear;

%example
%ano='http://dapds00.nci.org.au/thredds/dodsC/rr5/satellite/obs/himawari8/FLDK/2020/01/01/0000/20200101000000-P1S-ABOM_OBS_B07-PRJ_GEOS141_2000-HIMAWARI8-AHI.nc.ascii?channel_0007_brightness_temperature%5B0%5D%5B3008%5D%5B4574%5D'

%request date
counter=1;
awal=datenum([2020 01 10 0 0 0]);
akhir=datenum([2020 01 18 23 50 0]);
timespan=linspace(awal,akhir,(floor(akhir)-floor(awal)+1)*6*24);

unik=load('../Matfile/unik.mat');
%long=146.708008;
%lat=-36.736328;
long=146.808676390681967;
lat=-36.813852061849481;
locate=find((abs(unik.unik(:,1)-long)<1e-3) &(abs(unik.unik(:,2)-lat)<1e-3));
xy=unik.unik(locate,:);
x=xy(4);y=xy(3);
return
h=waitbar(0,'pleasewait');
for i=1:length(timespan)
    waitbar(i/length(timespan),h,sprintf('%.2f%%',i*100/length(timespan)))
    timespannow=datestr(timespan(i),'YYYYmmDDHHMMSS');
    url = ['http://dapds00.nci.org.au/thredds/dodsC/rr5/satellite/obs/himawari8/FLDK/' timespannow(1:4) '/' timespannow(5:6) ...
        '/' timespannow(7:8) '/' timespannow(end-5:end-2) '/' timespannow ...
        '-P1S-ABOM_OBS_B07-PRJ_GEOS141_2000-HIMAWARI8-AHI.nc.ascii?channel_0007_brightness_temperature%5B0%5D%5B'...
        num2str(y) '%5D%5B' num2str(x) '%5D'];
    try
        rgb = webread(url);
        temp=strsplit(rgb,'\n');
        temp2=strsplit(temp{13});
        brightness(counter)=str2double(temp2{2});
    catch
        brightness(counter)=NaN;
    end
    counter=counter+1;
end
close(h)
plot(timespan,brightness)
title(sprintf('Band 7 (TIR) of (%f,%f)',long,lat))
set(gcf, 'Position', get(0, 'Screensize'));hb
set(gca,'FontSize',15)
datetick('x')

%save data
data.timespan=timespan;data.brightness=brightness;
save(sprintf('../Matfile/TIR_%i_%i.mat',x,y),'data')
