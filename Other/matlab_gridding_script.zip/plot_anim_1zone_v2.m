%plot anim 1 cluster zone
clc;clear;

load('../Matfile/studycase1_bigger_picture.mat')
load coast_i_aus.mat
load('../studyarea1_vertices.mat')
%sort data per time
cluster_sorted=sortrows(cluster,1);
timeall=linspace(min(cluster_sorted(:,1)),max(cluster_sorted(:,1)),(6*24*(floor(max(cluster_sorted(:,1)))-floor(min(cluster_sorted(:,1)))))-1);


%create color map for aging hotspot
colormap1_start=[235/255 155/255 165/255]; %red
colormap1_inter=[1 0 0]; %red
colormap1_end=[0.6 0 0]; %light red 235, 155, 165
agecolor1_arr1(:,1)=linspace(colormap1_start(1),colormap1_inter(1),16);
agecolor1_arr1(:,2)=linspace(colormap1_start(2),colormap1_inter(2),16);
agecolor1_arr1(:,3)=linspace(colormap1_start(3),colormap1_inter(3),16);
agecolor1_arr2(:,1)=linspace(colormap1_inter(1),colormap1_end(1),16);
agecolor1_arr2(:,2)=linspace(colormap1_inter(2),colormap1_end(2),16);
agecolor1_arr2(:,3)=linspace(colormap1_inter(3),colormap1_end(3),16);
agecolor1_arr2(1,:)=[];
agecolor1_arr=[agecolor1_arr1;agecolor1_arr2];

S = shaperead('D:/Research/2021/Gridding/Data/fire_polygons/zone_3_fire_polygon.shp');
s = get(0, 'ScreenSize');
h=waitbar(0,'pleasewait');
for i=1:length(timeall)
    waitbar(i/length(timeall),h,sprintf('%.2f%%',i*100/length(timeall)))
    k=find(cluster_sorted(:,1)<=timeall(i));
    plotthis=cluster_sorted(k,:);
    
    f = figure('visible', 'off','Position', [0 0 s(3) s(4)]);
    hold on

    
    %plot coast line
    plot(long,lat)
    %plot 
    mapshow(S,'FaceColor','magenta','FaceAlpha',0.05,'LineStyle',':')
    
    %decide each hotspot color
    ukuran=size(plotthis);
    for j=1:ukuran(1)
        hotspotcolors(j,:)=agecolor1_arr(floor(floor(plotthis(j,1))-floor(cluster_sorted(1,1)))+1,:);
    end
    %plot hotspot
    scatter(plotthis(:,2),plotthis(:,3),60,hotspotcolors,'filled','MarkerEdgeColor','none')
    
    %plot study area
    plot(studyarea,'FaceColor','none','LineStyle','--','EdgeColor','black')
    
    set(gca,'XLim',[145.91 148.15],'YLim',[-38.87 -36.18]);
    ratiofix

       
    set(get(gca,'title'),'string',(sprintf('Study Case 1 hotspot clusters - %s',datestr(timeall(i),'DD/mm/YYYY HH:MM UTC'))))
    exportgraphics(f,sprintf('D:/Research/2021/Gridding/Figures/clusteranim/zone3_%04d.png',i))
    close(f)
end

close(h)
load chirp
sound(y,Fs)