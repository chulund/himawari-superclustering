%create animation for 1 zone
clc;clear
%D:/Research/2021/Gridding/Figures/clusteranim
load('../Matfile/clusterzone3.mat')

%sort data per time
timeunique=unique(cluster(:,1));
timeall=linspace(min(timeunique),max(timeunique),(6*24*(floor(max(timeunique))-floor(min(timeunique))))+10);

h=waitbar(0,'pleasewait');

%create shape
for i=1:length(timeall)
    waitbar(i/length(timeall),h,sprintf('%.2f%%',i*100/length(timeall)))
    k=find(datenum(datestr(timeall(i)))==datenum(datestr(cluster(:,1))));
    hotspotpoly{i}.time=timeall(i);
    if ~isempty(k)
        for j=1:length(k)
            %create hotspot
            hotspotpoly{i}.shape(j)=nsidedpoly(20,'Center',[cluster(k(j),2) cluster(k(j),3)],'Radius',Radius);
        end
    end
end
close(h
save('../Matfile/hotspotpoly_clusterzone3.mat','hotspotpoly'))
return
