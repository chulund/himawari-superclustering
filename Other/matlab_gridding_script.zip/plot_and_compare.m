%plot center and compare it with chermelles coordinate
clc;clear
load('../Fileout/XY_transformed.mat')

plot(long,lat,'x')
hold on
coastal=load('coast_i_aus.mat');
plot(coastal.long,coastal.lat,'-b')
unik=load('../Matfile/unik.mat');
plot(unik.unik(:,1),unik.unik(:,2),'xr')
ratiofix