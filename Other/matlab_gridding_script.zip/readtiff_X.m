clc;clear;
%read tif
filename='../Data/HIMAWARI-8_AHI_B07_20200113_235020_FLDK.tif';
[A,R,cmap] = readgeoraster(filename);
%mapshow(A,R)
imagesc(A(:,:,1))
set(gca,'YDir','normal')
rastersize=R.RasterSize;
[X,Y] = pix2map(R,1:rastersize(1),1:rastersize(2));
load('../Matfile/unik.mat')
unik(1,:)


fid =fopen('../Fileout/XY2.txt','w')
h=waitbar(0,'pleasewait');
counter=1;
%create a grid
min_unique_i=min(unik(:,3))-5.5;
max_unique_i=max(unik(:,3))+5.5;
min_unique_j=min(unik(:,4))-5.5;
max_unique_j=max(unik(:,4))+5.5;
for i=min_unique_i:1:max_unique_i
    for j=min_unique_j:1:max_unique_j
        waitbar(counter/((3300-1500)*(4600-3500)),h,sprintf('%.2f%%',counter*100/((3300-1500)*(4600-3500))))
        counter=counter+1;
        [X,Y] = pix2map(R,j,i);
        fprintf(fid,'%f\t%f\n',X,Y);
    end
end
close(h);
fclose(fid);