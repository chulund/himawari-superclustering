%test custom color
function test_color(colormap_array)

ukuran=size(colormap_array);
s = get(0, 'ScreenSize');
f = figure('visible', 'on','Position', [0 0 s(3) s(4)]);
hold on
for i=1:ukuran(1)
    shape=polyshape([(i-1)+1,(i-1)+2,(i-1)+2,(i-1)+1],[(1-1)+1,(1-1)+1,(1-1)+2,(1-1)+2]);
    plot(shape,'FaceColor',colormap_array(i,:),'FaceAlpha',1,'EdgeColor','none')
end

end
