%load himawari hotspot data for 1 zone
clc;clear;
filename='D:/Research/2021/Gridding/Figures/clusteranim/zone3_hotspots.csv';

fid=fopen(filename,'r');
line=fgetl(fid); %skip header
counter=1;
h=waitbar(0,'pleasewait');
while ~feof(fid)
    waitbar(counter/7918,h,sprintf('%.2f%%',counter*100/7918))
    line=fgetl(fid);
    temp=strsplit(line,',');
    cluster(counter,1)=datenum(temp{14},'DD/mm/YYYY HH:MM'); %time
    cluster(counter,2)=str2double(temp{1}); %long
    cluster(counter,3)=str2double(temp{2}); %lat
    cluster(counter,4)=str2double(temp{8}); %FRP
    cluster(counter,5)=str2double(temp{5}); %MIR
    cluster(counter,6)=str2double(temp{6}); %TIR
    cluster(counter,7)=str2double(temp{12});% cluster
    counter=counter+1;
end
fclose(fid)
close(h)