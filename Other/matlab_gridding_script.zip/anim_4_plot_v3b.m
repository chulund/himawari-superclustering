%plot animation version 3 (with correction from 13/5/2021)
clc;clear
load('../Matfile/data_studycase1.mat')
load('../Matfile/hotspot_studycase1.mat')
load('../Matfile/drop_studycase1.mat')

hotspot_age=2; %hours

%create color map for aging hotspot
colormap1_start=[1 0 0]; %red
colormap1_end=[235/255 155/255 165/255]; %light red 235, 155, 165
agecolor1_arr(:,1)=linspace(colormap1_start(1),colormap1_end(1),7);
agecolor1_arr(:,2)=linspace(colormap1_start(2),colormap1_end(2),7);
agecolor1_arr(:,3)=linspace(colormap1_start(3),colormap1_end(3),7);

%create color map for aging suppression
colormap2_start=[0 0 1]; %blue
colormap2_end=[39/255 202/255 255/255]; %light blue
agecolor2_arr(:,1)=linspace(colormap2_start(1),colormap2_end(1),6);
agecolor2_arr(:,2)=linspace(colormap2_start(2),colormap2_end(2),6);
agecolor2_arr(:,3)=linspace(colormap2_start(3),colormap2_end(3),6);

%create color map for MIR
for i=1:length(studycase)
    brightnessmin(i)=min(studycase{i}.MIR);
    brightnessmax(i)=max(studycase{i}.MIR);
end
cmapmax=floor(max(brightnessmax)-min(brightnessmin)+1);
himacmap=(summer(cmapmax));

%create studycase 1 area
vertices3=studycase{63}.shape.Vertices(3,:);
vertices4=studycase{9}.shape.Vertices(2,:);
vertices2=studycase{55}.shape.Vertices(4,:);
vertices1=studycase{1}.shape.Vertices(1,:);
studyarea=polyshape([vertices1(1) vertices2(1) vertices3(1) vertices4(1)],[vertices1(2) vertices2(2) vertices3(2) vertices4(2)]);

%create data for subplot 2 / time slider
counter=1;
hotspotcounter=NaN(length(studycase{1}.timespan),3);
hotspotcounter(:,1)=studycase{1}.timespan;
for i=1:length(studycase{1}.timespan)
    if counter>length(hotspotaggregate)
        break
    end
    if datenum(datestr(studycase{1}.timespan(i))) == datenum(datestr(hotspotaggregate{counter}(1,1)))
        ukuran=size(hotspotaggregate{counter});
        hotspotcounter(i,2)=ukuran(1);
        hotspotcounter(i,3)=1;
        counter=counter+1;
    end
end

h=waitbar(0,'pleasewait');
for i=1:length(studycase{1}.timespan)
    waitbar(i/length(studycase{1}.timespan),h,sprintf('plotting %.2f%%',i*100/length(studycase{1}.timespan)))
    s = get(0, 'ScreenSize');
    f = figure('visible', 'off','Position', [0 0 s(3) s(4)]);
    hold all
    set(f, 'PaperPositionMode', 'auto');
    sgtitle(sprintf('Study Case 1 - %s UTC',datestr(studycase{1}.timespan(i),'DD/mm/YYYY HH:MM')))
    sp1= subplot(4,1,1);
    ratiofix
    hold on
    
    %plot MIR
    for j=1:length(studycase)
        if isnan(studycase{j}.MIR(i))
           colour = [0.5 0.5 0.5]; 
        else
            indices=round(studycase{j}.MIR(i)-min(brightnessmin));
            if indices==0
                indices=1;
            end
            colour = himacmap(indices,:);
        end
        plot(studycase{j}.shape,'FaceColor',colour,'FaceAlpha',1,'EdgeColor','none')
        %,
%         [x,y] = centroid(studycase{j}.shape);
%         text(x-0.007,y,sprintf('%.2f',studycase{j}.TIR(i)),'FontSize',5);
    c=colorbar(sp1,'Ticks',[0:0.1:1],...
         'TickLabels',{'220','238','256','274','292','310','328','346','364','382','400'});
    colormap((himacmap))

    %set value
    %c.Label.String = 'Kelvin';
    c.Title.String='MIR (K)';

    end 
        
    %plot study area
    plot(studyarea,'FaceColor','none','LineStyle','--','EdgeColor','black')
    
%     %plot TIR availability
%     for j=1:length(studycase)
%         if studycase{j}.TIRflag(i)==0
%            colourTIR = [1 1 1]; 
%         elseif studycase{j}.TIRflag(i)==1
%             colourTIR = [0.5 0.5 0.5]; %grey if TIR not available
%         end
%         plot(studycase{j}.shape,'FaceColor',colourTIR,'FaceAlpha',1,'EdgeColor','none')
%     end
    
    %plot hotspot
    k=find(hotspot(:,1)<studycase{1}.timespan(i));

    for m=1:length(k)
       
        %create hotspot
        Radius=1/111; %15km
        hotspotpoly=nsidedpoly(20,'Center',[hotspot(k(m),2) hotspot(k(m),3)],'Radius',Radius);
        usia= (studycase{1}.timespan(i)-hotspot(k(m),1))*24;
        if usia == 0
            hs_colour = agecolor1_arr(1,:);
        elseif usia <= 1
            hs_colour = agecolor1_arr(2,:);
        elseif usia <= 2
            hs_colour = agecolor1_arr(3,:);
        elseif usia <= 6
            hs_colour = agecolor1_arr(4,:);
        elseif usia <= 24
            hs_colour = agecolor1_arr(5,:);
        elseif usia <= 48
            hs_colour = agecolor1_arr(6,:);
        else 
            hs_colour = agecolor1_arr(7,:);
        end
        
        plot(hotspotpoly,'FaceColor',hs_colour,'EdgeColor',hs_colour,'FaceAlpha',1);
    end
    ratiofix
    
    %plot all drop happening in the last X hours
    max_hour = 48;
    l=find((drop(:,1)>=(studycase{1}.timespan(i)-(max_hour/24)))&(drop(:,1)<(studycase{1}.timespan(i))));

    for n=1:length(l)
        if i==117 & (n==1 | n==8) %skip blunder
            continue
        end
        p1 = [drop(l(n),2) drop(l(n),3)]; % First Point
        p2 = [drop(l(n),4) drop(l(n),5)]; % Second Point
        dp = (p2-p1).*15;                       % Difference
        dp_threshold = 2/111;%in km
        if dp(1)>dp_threshold 
            dp(1)=dp_threshold;
        elseif dp(1) < -dp_threshold
            dp(1)=-dp_threshold;
        end
        if dp(2)>dp_threshold
            dp(2)=dp_threshold;
        elseif dp(2)<-dp_threshold
            dp(2)=-dp_threshold;
        end
        
        %check the age of the hotpost
        usiasp= (studycase{1}.timespan(i)-drop(l(n),1))*24;
        if usiasp <= 1
            sp_colour = agecolor2_arr(1,:);
        elseif usiasp <= 2
            sp_colour = agecolor2_arr(2,:);
        elseif usiasp <= 6
            sp_colour = agecolor2_arr(3,:);
        elseif usiasp <= 24
            sp_colour = agecolor2_arr(4,:);
        elseif usiasp <= 48
            sp_colour = agecolor2_arr(5,:);
        else 
            sp_colour = 'none';
        end
        
        quiver(p1(1),p2(2),dp(1),dp(2),'LineWidth',3,'Color',sp_colour,'ShowArrowHead','on','MaxHeadSize',5)
    end  
    
    %plot hotspot current epoch
    
    k=find(hotspot(:,1)==studycase{1}.timespan(i));

    for m=1:length(k)
       
        %create hotspot
        Radius=1/111; %15km
        hotspotpoly=nsidedpoly(20,'Center',[hotspot(k(m),2) hotspot(k(m),3)],'Radius',Radius);
        usia= (studycase{1}.timespan(i)-hotspot(k(m),1))*24;
        if usia == 0
            hs_colour = agecolor1_arr(1,:);
        elseif usia <= 1
            hs_colour = agecolor1_arr(2,:);
        elseif usia <= 2
            hs_colour = agecolor1_arr(3,:);
        elseif usia <= 6
            hs_colour = agecolor1_arr(4,:);
        elseif usia <= 24
            hs_colour = agecolor1_arr(5,:);
        elseif usia <= 48
            hs_colour = agecolor1_arr(6,:);
        else 
            hs_colour = agecolor1_arr(7,:);
        end
        
        plot(hotspotpoly,'FaceColor',hs_colour,'EdgeColor',hs_colour,'FaceAlpha',1);
    end
    ratiofix
    
    %plot drop current epoch
    
    if i==length(studycase{1}.timespan)
        l=find(drop(:,1)>=studycase{1}.timespan(i));
    else
        l=find(drop(:,1)<studycase{1}.timespan(i+1) & drop(:,1)>=studycase{1}.timespan(i));
    end
    
    for n=1:length(l)
        if i==117 & (n==1 | n==8) %skip blunder
            continue
        end
        p1 = [drop(l(n),2) drop(l(n),3)]; % First Point
        p2 = [drop(l(n),4) drop(l(n),5)]; % Second Point
        dp = (p2-p1).*15;                       % Difference
        dp_threshold = 2/111;%in km
        if dp(1)>dp_threshold 
            dp(1)=dp_threshold;
        elseif dp(1) < -dp_threshold
            dp(1)=-dp_threshold;
        end
        if dp(2)>dp_threshold
            dp(2)=dp_threshold;
        elseif dp(2)<-dp_threshold
            dp(2)=-dp_threshold;
        end
        
        %check the age of the hotpost
        usiasp= (studycase{1}.timespan(i)-drop(l(n),1))*24;
        if usiasp <= 1
            sp_colour = agecolor2_arr(1,:);
        elseif usiasp <= 2
            sp_colour = agecolor2_arr(2,:);
        elseif usiasp <= 6
            sp_colour = agecolor2_arr(3,:);
        elseif usiasp <= 24
            sp_colour = agecolor2_arr(4,:);
        elseif usiasp <= 48
            sp_colour = agecolor2_arr(5,:);
        else 
            sp_colour = 'none';
        end
        
        quiver(p1(1),p2(2),dp(1),dp(2),'LineWidth',3,'Color',sp_colour,'ShowArrowHead','on','MaxHeadSize',5)
    end  
    
    %plot time slider
    sp2=subplot(4,1,2);
    plot(hotspotcounter(:,1),hotspotcounter(:,3),'o','MarkerEdgeColor','red','MarkerFaceColor','red')
    hold on
    avail(:,1)=availcounter.timespan;
    avail(:,2)=availcounter.TIR;
    avail(:,3)=availcounter.MIR;
    k=find(avail(:,3)==0);
    avail(k,3)=NaN;
    k=find(avail(:,3)>=1);
    avail(k,3)=0.5;
    plot(avail(:,1),avail(:,3),'o','MarkerEdgeColor',[0.5 0.5 0.5],'MarkerFaceColor',[0.5 0.5 0.5]) %availability for MIR
    plot(drop(:,1),1.5,'o','MarkerEdgeColor',[0.25 0.25 1],'MarkerFaceColor',[0.25 0.25 1])
    text(studycase{1}.timespan(i)-0.025,1.05,'I','FontSize',30)
    set(gca,'YTickLabel',[]);
    xlabel('UTC')
    sp2.XLim=[737804 737809];
    sp2.Position=[0.13 0.11 0.775 0.02];drawnow
    datetick('x')
    
    %plot the hotspot legend
    sp3=subplot(4,1,3);
    hold on
    
    hs_colour_arr(1,:) = agecolor1_arr(1,:);
    hs_colour_arr(2,:) = agecolor1_arr(2,:);
    hs_colour_arr(3,:) = agecolor1_arr(3,:);
    hs_colour_arr(4,:) = agecolor1_arr(4,:);
    hs_colour_arr(5,:) = agecolor1_arr(5,:);
    hs_colour_arr(6,:) = agecolor1_arr(6,:);
    hs_colour_arr(7,:) = agecolor1_arr(7,:);
    hs_colour_text{1}='Current hotspot';
    hs_colour_text{2}='0-1 hours';
    hs_colour_text{3}='1-2 hours';
    hs_colour_text{4}='2-6 hours';
    hs_colour_text{5}='6-24 hours';
    hs_colour_text{6}='24-48 hours';
    hs_colour_text{7}='>48 hours';
        
    for j=1:length(hs_colour_arr)
        shape=polyshape([(1-1)+1,(1-1)+1,(1-1)+2,(1-1)+2],[(j-1)+1,(j-1)+2,(j-1)+2,(j-1)+1]);
        [x,y]=centroid(shape);
        text(x+1,y,hs_colour_text{j});
        plot(shape,'FaceColor',hs_colour_arr(j,:),'EdgeColor','none','FaceAlpha',1);
    end
    set(sp3,'XColor','none','YColor','none','Color','none','XTick',[],'YTick',[])
    sp3.Title.Position=[3 8.25 0];
    title('Hotspot Legend')
    ratiofix
    
    %set each axes position
    
    %plot the suppression legend
    sp4=subplot(4,1,4);
    hold on
    
    sp_colour_arr(1,:) = agecolor2_arr(1,:);
    sp_colour_arr(2,:) = agecolor2_arr(2,:);
    sp_colour_arr(3,:) = agecolor2_arr(3,:);
    sp_colour_arr(4,:) = agecolor2_arr(4,:);
    sp_colour_arr(5,:) = agecolor2_arr(5,:);
    sp_colour_arr(6,:) = agecolor2_arr(6,:);
    sp_colour_text{1}='0-1 hours';
    sp_colour_text{2}='1-2 hours';
    sp_colour_text{3}='2-6 hours';
    sp_colour_text{4}='6-24 hours';
    sp_colour_text{5}='24-48 hours';
    sp_colour_text{6}='>48 hours';
        
    for j=1:length(sp_colour_arr)
        shape=polyshape([(1-1)+1,(1-1)+1,(1-1)+2,(1-1)+2],[(j-1)+1,(j-1)+2,(j-1)+2,(j-1)+1]);
        [x,y]=centroid(shape);
        text(x+1,y,sp_colour_text{j});
        plot(shape,'FaceColor',sp_colour_arr(j,:),'EdgeColor','none','FaceAlpha',1);
    end
    set(sp4,'XColor','none','YColor','none','Color','none','XTick',[],'YTick',[])
    sp4.Title.Position=[3 7.25 0];
    title('Suppresion Legend')
    ratiofix
    
    %set each axes position
    %set(gca,'PositionConstraint','outerposition')

    sp2.Position=[0.13 0.11 0.775 0.02];drawnow
    sp1.Position=[0.1 0.2 0.8 0.7];drawnow  
    sp2.Position=[0.13 0.11 0.775 0.02];drawnow
    sp3.Position=[0.45 0.21 0.775 0.22];drawnow
    sp4.Position=[0.45 0.45 0.775 0.22];drawnow
    %set(gca,'Position',[0.1300 0.1100 0.7750 0.1])
    %ylim([0.99999 1.00001])
    %line([studycase{1}.timespan(i) studycase{1}.timespan(i)],[ylimit(1) ylimit(2)],'LineStyle','--','LineWidth',5,'Color','black')
    %plot(studycase{1}.timespan(i),1,'o','MarkerEdgeColor','black','MarkerFaceColor','black')

    
    exportgraphics(f,sprintf('D:/Research/2021/Gridding/Figures/animation/studycase1_%04d.png',i))
    close(f)
end
close(h)