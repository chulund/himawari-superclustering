figure
hold on
for i=1:length(TIR.data)
    plot(TIR.data(i).timespan,TIR.data(i).brightness)
    plot(MIR.data(i).timespan,MIR.data(i).brightness)
end

%fid=fopen('TIR_studycase1.csv','w');
%fprintf(fid,'time,long,lat,TIR')
counter=1;
for i=1:length(data)
    for j=1:length(data(i).timespan)
        %fprintf(fid,'%s,%f,%f,%f\n',datestr(data(i).timespan(j),'DD-mm-YYYY HH:MM:SS'),listcoord(i,4),listcoord(i,5),data(i).brightness(j));
        sprintf('%s,%f,%f,%f\n',datestr(data(i).timespan(j),'DD-mm-YYYY HH:MM:SS'),listcoord(i,4),listcoord(i,5),data(i).brightness(j))
        counter=counter+1;
    end
end
%fclose(fid)