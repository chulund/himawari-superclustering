%obtain TIR data from NCI
clc;clear;

%example
%ano='http://dapds00.nci.org.au/thredds/dodsC/rr5/satellite/obs/himawari8/FLDK/2020/01/01/0000/20200101000000-P1S-ABOM_OBS_B07-PRJ_GEOS141_2000-HIMAWARI8-AHI.nc.ascii?channel_0007_brightness_temperature%5B0%5D%5B3008%5D%5B4574%5D'
%ane='http://dapds00.nci.org.au/thredds/dodsC/rr5/satellite/obs/himawari8/FLDK/2020/01/14/0910/20200114091000-P1S-ABOM_OBS_B13-PRJ_GEOS141_2000-HIMAWARI8-AHI.nc.html

%band

band=13;
%request date

awal=datenum([2019 12 28 0 0 0]);
akhir=datenum([2020 01 22 23 50 0]);
daysnumber=(floor(akhir)-floor(awal));
timespan=linspace(awal,akhir,(floor(akhir)-floor(awal)+1)*6*24);

unik=load('../Matfile/unik_centre.mat');

%long=146.708008;
%lat=-36.736328;
listcoord=table2array(readtable('D:\Research\2021\Gridding\ExportTirData\study_area3\coord_studyarea5.csv'));
h=waitbar(0,'pleasewait');
for j=1:length(listcoord)
    counter=1;brightness=[];
    long=listcoord(j,4);
    lat=listcoord(j,5);
    locate=find((abs(unik.unik_centre(:,1)-long)<1e-3) &(abs(unik.unik_centre(:,2)-lat)<1e-3));
    xy=unik.unik_centre(locate,:);
    x=xy(3);y=xy(4);

    for i=1:length(timespan)
        waitbar(i/length(timespan),h,sprintf('downloading TIR %i out of %i (%.2f%%)',j,length(listcoord),i*100/length(timespan)))
        timespannow=datestr(timespan(i),'YYYYmmDDHHMMSS');
        bandstr=sprintf('B%02d',band');
        bandnumberstr=sprintf('%04d',band');
        url = ['http://dapds00.nci.org.au/thredds/dodsC/rr5/satellite/obs/himawari8/FLDK/' timespannow(1:4) '/' timespannow(5:6) ...
            '/' timespannow(7:8) '/' timespannow(end-5:end-2) '/' timespannow ...
            '-P1S-ABOM_OBS_' bandstr '-PRJ_GEOS141_2000-HIMAWARI8-AHI.nc.ascii?channel_' bandnumberstr '_brightness_temperature%5B0%5D%5B'...
            num2str(y) '%5D%5B' num2str(x) '%5D'];
        try
            rgb = webread(url);
            temp=strsplit(rgb,'\n');
            temp2=strsplit(temp{13});
            brightness(counter)=str2double(temp2{2});
        catch
            brightness(counter)=NaN;
        end
        counter=counter+1;
    end
    
    % plot(timespan,brightness)
    % title(sprintf('Band 7 (TIR) of (%f,%f)',long,lat))
    % set(gcf, 'Position', get(0, 'Screensize'));hb
    % set(gca,'FontSize',15)
    % datetick('x')
    data(j).timespan=timespan;
    data(j).brightness=brightness;
end
close(h);
%save data

save(sprintf('../Matfile/TIR_studycase5.mat',x,y),'data');

return
fid=fopen('TIR_studycase1_v2.csv','w');
fprintf(fid,'pixelID,time,long,lat,MIR\n')
counter=1;
for i=1:length(data)
    for j=1:length(data(i).timespan)
        fprintf(fid,'%i,%s,%f,%f,%f\n',i,datestr(data(i).timespan(j),'DD-mm-YYYY HH:MM:SS'),listcoord(i,4),listcoord(i,5),data(i).brightness(j));
        %sprintf(fid,'%s,%f,%f,%f\n',datestr(data(i).timespan(j),'DD-mm-YYYY HH:MM:SS'),listcoord(i,4),listcoord(i,5),data(i).brightness(j));
        counter=counter+1;
    end
end
fclose(fid)
