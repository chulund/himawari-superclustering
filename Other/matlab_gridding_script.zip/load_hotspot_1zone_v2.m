%load himawari hotspot data for 1 zone
clc;clear;
filename='D:/Research/2021/Gridding/Data/foranimation/studycase1_bigger_picture.csv';

fid=fopen(filename,'r');
line=fgetl(fid); %skip header
counter=1;
h=waitbar(0,'pleasewait');
while ~feof(fid)
    waitbar(counter/28402,h,sprintf('%.2f%%',counter*100/28402))
    line=fgetl(fid);
    temp=strsplit(line,',');
    temp2=strsplit(temp{5},' ');
    temp3=strsplit(temp2{1},'/');
    temp4=strsplit(temp2{2},':');
    %cluster(counter,1)=datenum(temp{5},'DD/mm/YYYY HH:MM:SS'); %time
    cluster(counter,1)=datenum(str2double(temp3{3}),str2double(temp3{2}),str2double(temp3{1}),str2double(temp4{1}),str2double(temp4{2}),0); %time
    cluster(counter,2)=str2double(temp{2}); %long
    cluster(counter,3)=str2double(temp{3}); %lat
    cluster(counter,4)=str2double(temp{4}); %FRP
    cluster_name{counter}=temp{8};% cluster
    counter=counter+1;
end
fclose(fid)
close(h)
%remove data vefore 1 january and after 31 january
k=find(cluster(:,1)<737791);
cluster(k,:)=[];
cluster_name(k)=[];
k=find(cluster(:,1)>737821);
cluster(k,:)=[];
cluster_name(k)=[];
save('../matfile/studycase1_bigger_picture.mat','cluster','cluster_name')