%load drop data for animation
clc;clear;
filename='D:/Research/2021/Gridding/ExportTirData/drops_studyarea_coordonly.csv';

fid=fopen(filename,'r');
line=fgetl(fid);%skip header
counter=1;
while ~feof(fid)
    line=fgetl(fid);
    temp=strsplit(line,',');
    drop(counter,1)=datenum(temp{3},'DD/mm/YYYY HH:MM'); %time
    drop(counter,2)=str2double(temp{5}); %long start
    drop(counter,3)=str2double(temp{4}); %lat start
    drop(counter,4)=str2double(temp{7}); %long end
    drop(counter,5)=str2double(temp{6}); %lat end
    counter=counter+1;
end
fclose(fid);

%remove all unneeded data
k=find(drop(:,1)<737804 | drop(:,1)>737808.993055556);
drop(k,:)=[];
save('../Matfile/drop_studycase1.mat','drop')
