%plot animation
clc;clear
load('../Matfile/data_studycase1.mat')
load('../Matfile/hotspot_studycase1.mat')
load('../Matfile/drop_studycase1.mat')

hotspot_age=2; %hours

%create color map for aging hotspot
colormap1_start=[1 0 0]; %red
colormap1_end=[0.6 0.6 0.6]; %grey
agecolor1_arr(:,1)=linspace(colormap1_start(1),colormap1_end(1),hotspot_age*6);
agecolor1_arr(:,2)=linspace(colormap1_start(2),colormap1_end(2),hotspot_age*6);
agecolor1_arr(:,3)=linspace(colormap1_start(3),colormap1_end(3),hotspot_age*6);

%create color map for persisting hotspot
colormap2_start=[1 0 0]; %red
colormap2_end=[0.025 0 0]; %red to black
agecolor2_arr(:,1)=linspace(colormap2_start(1),colormap2_end(1),hotspot_age*6);
agecolor2_arr(:,2)=linspace(colormap2_start(2),colormap2_end(2),hotspot_age*6);
agecolor2_arr(:,3)=linspace(colormap2_start(3),colormap2_end(3),hotspot_age*6);

%create color map for TIR
for i=1:length(studycase)
    brightnessmin(i)=min(studycase{i}.TIR);
    brightnessmax(i)=max(studycase{i}.TIR);
end
cmapmax=floor(max(brightnessmax)-min(brightnessmin)+1);
himacmap=hot(cmapmax);

%create data for subplot 2 
counter=1;
hotspotcounter=NaN(length(studycase{1}.timespan),3);
hotspotcounter(:,1)=studycase{1}.timespan;
for i=1:length(studycase{1}.timespan)
    if counter>length(hotspotaggregate)
        break
    end
    if datenum(datestr(studycase{1}.timespan(i))) == datenum(datestr(hotspotaggregate{counter}(1,1)))
        ukuran=size(hotspotaggregate{counter});
        hotspotcounter(i,2)=ukuran(1);
        hotspotcounter(i,3)=1;
        counter=counter+1;
    end
end

%create hotspot status for plotting
hotspot_table=array2table(hotspot(:,2:3));
unique_coordinates=unique(hotspot_table,'rows');
unique_coordinates=table2array(unique_coordinates);
counter1=1;
for i=1:length(studycase{1}.timespan)
    hotspotstatus(i).hotspot=zeros(length(unique_coordinates),1);
    if counter1>length(hotspotaggregate)
        counter1=length(hotspotaggregate);
    end
    if datenum(datestr(studycase{1}.timespan(i))) == datenum(datestr(hotspotaggregate{counter1}(1,1)))
        for j=1:length(unique_coordinates)
            ukuran_aggr=size(hotspotaggregate{counter1});
            k=find(unique_coordinates(j,1)==(hotspotaggregate{counter1}(:,2)));
            if ~isempty(k)
                if hotspotstatus(i-1).hotspot(j)<0
                    hotspotstatus(i).hotspot(j)=1;
                else
                    hotspotstatus(i).hotspot(j)=hotspotstatus(i-1).hotspot(j)+1;
                end
                if hotspotstatus(i).hotspot(j)>=12
                    hotspotstatus(i).hotspot(j)=12;
                end
            else
                if i==1 | hotspotstatus(i-1).hotspot(j)==0 
                    hotspotstatus(i).hotspot(j)=0;
                else
                    if hotspotstatus(i-1).hotspot(j)==1
                        hotspotstatus(i).hotspot(j)=-1;
                    else
                        hotspotstatus(i).hotspot(j)=hotspotstatus(i-1).hotspot(j)-1;
                    end
                    if hotspotstatus(i).hotspot(j)<=-12
                        hotspotstatus(i).hotspot(j)=-12;
                    end
                end
            end
        end
        counter1=counter1+1;
    else
        for j=1:length(unique_coordinates)
            if i==1 | hotspotstatus(i-1).hotspot(j)==0 
                hotspotstatus(i).hotspot(j)=0;
            else
                if hotspotstatus(i-1).hotspot(j)==1
                    hotspotstatus(i).hotspot(j)=-1;
                else
                    hotspotstatus(i).hotspot(j)=hotspotstatus(i-1).hotspot(j)-1;
                end
                if hotspotstatus(i).hotspot(j)<=-12
                    hotspotstatus(i).hotspot(j)=-12;
                end
            end
        end
    end
end

for i=1:length(unique_coordinates)
    for j=1:length(hotspotstatus)
        hotspotstatus_percoord(i,j)=hotspotstatus(j).hotspot(i);
    end
end

% figure
% hold on
% for i=1:length(unique_coordinates)
%     bar(hotspotstatus_percoord(i,:))
% end


h=waitbar(0,'pleasewait');
for i=1:length(studycase{1}.timespan)
    waitbar(i/length(studycase{1}.timespan),h,sprintf('plotting %.2f%%',i*100/length(studycase{1}.timespan)))
    s = get(0, 'ScreenSize');
    f = figure('visible', 'on','Position', [0 0 s(3) s(4)]);
    set(f, 'PaperPositionMode', 'auto');
    sgtitle(sprintf('Study Case 1 - %s UTC',datestr(studycase{1}.timespan(i),'DD/mm/YYYY HH:MM')))
    sp1= subplot(2,1,1);
    ratiofix
    colormap(flipud(himacmap));
    hold on
    %plot TIR
    for j=1:length(studycase)
        if isnan(studycase{j}.TIR(i))
           colour = [1 1 1]; 
        else
            indices=round(studycase{j}.TIR(i)-min(brightnessmin));
            if indices==0
                indices=1;
            end
            colour = himacmap(indices,:);
        end
        plot(studycase{j}.shape,'FaceColor',colour,'FaceAlpha',1,'EdgeColor','none')
        %,
%         [x,y] = centroid(studycase{j}.shape);
%         text(x-0.007,y,sprintf('%.2f',studycase{j}.TIR(i)),'FontSize',5);
    c=colorbar('Ticks',[0:0.1:1],...
         'TickLabels',{'222','231','240','249','258','267','276','285','294','303','311'});
    %set value
    %c.Label.String = 'Kelvin';
    c.Title.String='TIR (K)';

    end
    
    %plot hotspot
    k=find(hotspot(:,1)<=studycase{1}.timespan(i));

    for m=1:length(k)
        %find hotspot status
        n=find(hotspot(k(m),2)==unique_coordinates(:,1) & hotspot(k(m),3)==unique_coordinates(:,2));
        status=hotspotstatus_percoord(n,i);
        if status<0
            hs_colormap=agecolor1_arr; %for aging hotspot
        else
            hs_colormap=agecolor2_arr; %for persisting hotspot
        end           
        hs_colour=hs_colormap(abs(status),:);
        
        %create hotspot
        Radius=1/111; %15km
        hotspotpoly=nsidedpoly(20,'Center',[hotspot(k(m),2) hotspot(k(m),3)],'Radius',Radius);
%         ac_num=round((studycase{1}.timespan(i)-hotspot(k(m),1))*24*6)+1;
%         if ac_num>length(agecolor1_arr)
%             ac_num=length(agecolor1_arr);
%         end 
        plot(hotspotpoly,'FaceColor',hs_colour,'EdgeColor',[0.25 0.25 0.25],'HoleEdgeAlpha',0.1,'FaceAlpha',1);
    end
    ratiofix
    
    %plot drop
    if i==length(studycase{1}.timespan)
        l=find(drop(:,1)>=studycase{1}.timespan(i));
    else
        l=find(drop(:,1)<studycase{1}.timespan(i+1) & drop(:,1)>=studycase{1}.timespan(i));
    end

    for n=1:length(l)
        if i==117 & (n==1 | n==8) %skip blunder
            continue
        end
        p1 = [drop(l(n),2) drop(l(n),3)]; % First Point
        p2 = [drop(l(n),4) drop(l(n),5)]; % Second Point
        dp = p2-p1;                       % Difference
        quiver(p1(1),p2(2),dp(1),dp(2),'LineWidth',3,'Color','blue')
    end  
    
    %plot time slider
    sp2=subplot(2,1,2);
    plot(hotspotcounter(:,1),hotspotcounter(:,3),'o','MarkerEdgeColor','red','MarkerFaceColor','red')
    hold on
    plot(drop(:,1),1.5,'o','MarkerEdgeColor',[0.25 0.25 1],'MarkerFaceColor',[0.25 0.25 1])
    text(studycase{1}.timespan(i)-0.025,1.25,'I','FontSize',25)
    set(gca,'YTickLabel',[]);
    datetick('x')
    sp2.Position=[0.13 0.11 0.775 0.01];drawnow
    sp2.XLim=[737804 737809];
    %set(gca,'PositionConstraint','outerposition')
    sp1.Position=[0.1 0.2 0.8 0.7];drawnow
    sp2.Position=[0.13 0.11 0.775 0.01];drawnow
    %set(gca,'Position',[0.1300 0.1100 0.7750 0.1])
    %ylim([0.99999 1.00001])
    %line([studycase{1}.timespan(i) studycase{1}.timespan(i)],[ylimit(1) ylimit(2)],'LineStyle','--','LineWidth',5,'Color','black')
    %plot(studycase{1}.timespan(i),1,'o','MarkerEdgeColor','black','MarkerFaceColor','black')
    
    exportgraphics(f,sprintf('D:/Research/2021/Gridding/Figures/animation/studycase1_%04d.png',i))
    close(f)
end
close(h)