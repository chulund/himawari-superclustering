%load himawari hotspot data for 
clc;clear;
filename='D:/Research/2021/Gridding/Data/foranimation/studycase1_himawari8.csv';

fid=fopen(filename,'r');
line=fgetl(fid); %skip header
counter=1;
while ~feof(fid)
    line=fgetl(fid);
    temp=strsplit(line,',');
    hotspot(counter,1)=datenum(temp{16},'DD/mm/YYYY HH:MM'); %time
    hotspot(counter,2)=str2double(temp{1}); %long
    hotspot(counter,3)=str2double(temp{2}); %lat
    hotspot(counter,4)=str2double(temp{9}); %FRP
    hotspot(counter,5)=str2double(temp{6}); %MIR
    hotspot(counter,6)=str2double(temp{7}); %TIR
    counter=counter+1;
end
fclose(fid)

%group by time
uniktime=unique(hotspot(:,1));
for i=1:length(uniktime)
    k=find(hotspot(:,1)==uniktime(i));
    hotspotaggregate{i}=hotspot(k,:);
end

save('../Matfile/hotspot_studycase1.mat','hotspot','hotspotaggregate')

