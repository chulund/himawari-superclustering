%create polyline
clc;clear;
XY1=load('../Fileout/XY_transformed1.mat')
XY2=load('../Fileout/XY_transformed2.mat')

%check size of 
load('../Matfile/unik.mat')
min_unique_i=min(unik(:,3))-5;
max_unique_i=max(unik(:,3))+5;
min_unique_j=min(unik(:,4))-5;
max_unique_j=max(unik(:,4))+5;

size_of_long=max_unique_j-min_unique_j+2;
size_of_lat=max_unique_i-min_unique_i+2;
fid=fopen('../Fileout/XY_transformed_WKT_horizontal.csv','w');
counter=1;
for j=1:size_of_long
    fprintf(fid,'LINESTRING(');
    for i=1:size_of_lat
        fprintf(fid,'%f %f',XY1.long(counter),XY1.lat(counter));
        counter=counter+1;
        if i==size_of_lat
        else
            fprintf(fid,',');
        end
    end
    fprintf(fid,')\n');
end
fclose(fid);
fid=fopen('../Fileout/XY_transformed_WKT_vertical.csv','w');
counter=1;
for i=1:size_of_lat
    fprintf(fid,'LINESTRING(');
    for j=1:size_of_long
        fprintf(fid,'%f %f',XY2.long(counter),XY2.lat(counter));
        counter=counter+1;
        if j==size_of_long
        else
            fprintf(fid,',');
        end
    end
    fprintf(fid,')\n');
end
fclose(fid);
load chirp
sound(y);