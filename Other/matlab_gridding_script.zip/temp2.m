%check validity of my TIR
clc;clear;
load('../Matfile/hotspot_studycase1.mat')
load('../Matfile/data_studycase1.mat')
%hotspot number to test
numb=1;

TIR2check=hotspot(numb,6);

for i=1:length(studycase)
    k=find(studycase{i}.TIR==TIR2check);
    if ~isempty(k)
        for j=1:length(k)
            if strcmp(datestr(hotspot(numb,1)),datestr(studycase{i}.timespan(k(j))))
                fprintf('impossible in %i ad %i\n',i,j)
                break
            else
                fprintf('match in studycase %i date %s, different from hotspot %i date %s\n'...
                    ,i,datestr(studycase{i}.timespan(k(j))),numb,datestr(hotspot(numb,1)))
            end
        end
    end
end

% fprintf('%f\n',studycase{33}.TIR(56))
% fprintf('%f\n',studycase{32}.TIR(56))
% fprintf('%f\n',studycase{31}.TIR(56))
% fprintf('%f\n',studycase{22}.TIR(56))
% fprintf('%f\n',studycase{23}.TIR(56))
% fprintf('%f\n',studycase{24}.TIR(56))
% fprintf('%f\n',studycase{14}.TIR(56))
% fprintf('%f\n',studycase{15}.TIR(56))
% plot(studycase{32}.shape)
% plot(studycase{31}.shape)
% plot(studycase{22}.shape)
% plot(studycase{24}.shape)
% plot(studycase{14}.shape)
% plot(studycase{15}.shape)