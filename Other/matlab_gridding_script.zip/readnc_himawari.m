%read nc himawari
filename='../Data/20200101000000-P1S-ABOM_OBS_B07-PRJ_GEOS141_2000-HIMAWARI8-AHI.nc';
anu=ncinfo(filename);
waktu=ncread(filename,'time');
x=ncread(filename,'x');
y=ncread(filename,'y');
geostationary=ncread(filename,'geostationary');
data=ncread(filename,'channel_0007_brightness_temperature');
return
%read nc himawari
filename='../Data/20200114000000-P1S-ABOM_OBS_B07-PRJ_GEOS141_2000-HIMAWARI8-AHI.nc';
anu=ncinfo(filename);
waktu=ncread(filename,'time');
x=ncread(filename,'x');
y=ncread(filename,'y');
geostationary=ncread(filename,'geostationary');
data=ncread(filename,'channel_0007_brightness_temperature');
latarr=(1:length(y));
lonarr=(1:length(x));
imagesc(lonarr,latarr,data')
set(gca,'YDir','reverse')
hold on
load coast_i_aus.mat
plot(long,lat,'Color','Black')
load('../Matfile/unik.mat')
return
filename='../Data/20200114000000-P1S-ABOM_BRF_B01-PRJ_GEOS141_1000-HIMAWARI8-AHI.nc';
anu=ncinfo(filename);
waktu=ncread(filename,'time');
x=ncread(filename,'x');
y=ncread(filename,'y');
geostationary=ncread(filename,'geostationary');
data=ncread(filename,'channel_0001_brf');
latarr=(linspace(-79.6869147,79.6853012,5500));
lonarr=linspace(59.4112507,140.6998616,5500);
imagesc(lonarr,latarr,data)
set(gca,'YDir','normal')
hold on
load coast_i_aus.mat
plot(long,lat,'Color','Black')
return
filename='../Data/20200114000000-P1S-ABOM_BRF_B03-PRJ_GEOS141_500-HIMAWARI8-AHI.nc';
anu=ncinfo(filename);
waktu=ncread(filename,'time');
x=ncread(filename,'x');
y=ncread(filename,'y');
geostationary=ncread(filename,'geostationary');
data=ncread(filename,'channel_0003_brf');
latarr=(linspace(-79.6869147,79.6853012,22000));
lonarr=linspace(59.4112507,140.6998616,22000);
imagesc(lonarr,latarr,data)
set(gca,'YDir','normal')
ratiofix
return
