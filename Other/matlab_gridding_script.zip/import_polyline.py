import os
import arcpy
inFile = "D:/Research/2021/Gridding/Fileout/XY_transformed_WKT_horizontal.csv"
outFC = "D:/Research/2021/Gridding/Fileout/XY_transformed_WKT_horizontal.shp"
srs = arcpy.SpatialReference(4326)

arcpy.CreateFeatureclass_management(os.path.dirname(outFC), os.path.basename(outFC), 'POLYLINE', spatial_reference=srs)
with open(inFile, 'r') as f:
    inWKT = f.readline()
    while inWKT:
        geom = arcpy.FromWKT(inWKT, srs)
        with arcpy.da.InsertCursor(outFC, ["SHAPE@"]) as cur:
            cur.insertRow([geom])
        inWKT = f.readline()
