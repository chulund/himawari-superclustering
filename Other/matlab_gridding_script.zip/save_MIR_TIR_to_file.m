clc;clear
MIR=load('../Matfile/MIR_studycase5.mat');
TIR=load('../Matfile/TIR_studycase5.mat');

%export MIR & TIR data to Simon

listcoord=table2array(readtable('D:\Research\2021\Gridding\ExportTirData\study_area3\coord_studyarea5.csv'));

%export study case to Simon
fid=fopen('TIR&MIR_studycase5.csv','w');
fprintf(fid,'pixelID,time,long,lat,MIR(band7),TIR(band13)\n')
counter=1;
for i=1:length(MIR.data)
    for j=1:length(MIR.data(i).timespan)
        fprintf(fid,'%i,%s,%f,%f,%f,%f\n',i,datestr(MIR.data(1).timespan(j),'DD-mm-YYYY HH:MM:SS'),listcoord(i,4),listcoord(i,5),MIR.data(i).brightness(j),TIR.data(i).brightness(j));
        %sprintf(fid,'%s,%f,%f,%f\n',datestr(data(i).timespan(j),'DD-mm-YYYY HH:MM:SS'),listcoord(i,4),listcoord(i,5),data(i).brightness(j));
        counter=counter+1;
    end
end
fclose(fid)