%create lookup table for centre pixel X and Y himawari
clc;clear;
load('../Matfile/unik.mat')
load('D:/Research/2021/Gridding/Fileout/XY_transformed.mat')
min_unique_i=min(unik(:,3))-5;
max_unique_i=max(unik(:,3))+5;
min_unique_j=min(unik(:,4))-5;
max_unique_j=max(unik(:,4))+5;
counter=1;
for i=min_unique_j:1:max_unique_j
    for j=min_unique_i:1:max_unique_i
        unik_centre(counter,1)=long(counter);
        unik_centre(counter,2)=lat(counter);
        unik_centre(counter,3)=j-1;
        unik_centre(counter,4)=i-1;
        counter=counter+1;
    end
end

%testing
testlong=146.785248738833872
testlat=-36.813537076133883
locate1=find((abs(unik_centre(:,1)-testlong)<1e-3) &(abs(unik_centre(:,2)-testlat)<1e-3));
unik_centre(locate1,:)
locate2=find((abs(unik(:,1)-testlong)<1e-3) &(abs(unik(:,2)-testlat)<1e-3));
unik(locate2,:)

save('../matfile/unik_centre','unik_centre')