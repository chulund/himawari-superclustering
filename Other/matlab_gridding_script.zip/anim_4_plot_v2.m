%plot animation version 2 (with correction from 10/5/2021)
clc;clear
load('../Matfile/data_studycase1.mat')
load('../Matfile/hotspot_studycase1.mat')
load('../Matfile/drop_studycase1.mat')

%create studycase 1 area
vertices3=studycase{63}.shape.Vertices(3,:);
vertices4=studycase{9}.shape.Vertices(2,:);
vertices2=studycase{55}.shape.Vertices(4,:);
vertices1=studycase{1}.shape.Vertices(1,:);
studyarea=polyshape([vertices1(1) vertices2(1) vertices3(1) vertices4(1)],[vertices1(2) vertices2(2) vertices3(2) vertices4(2)]);

%create data for subplot 2 
counter=1;
hotspotcounter=NaN(length(studycase{1}.timespan),3);
hotspotcounter(:,1)=studycase{1}.timespan;
for i=1:length(studycase{1}.timespan)
    if counter>length(hotspotaggregate)
        break
    end
    if datenum(datestr(studycase{1}.timespan(i))) == datenum(datestr(hotspotaggregate{counter}(1,1)))
        ukuran=size(hotspotaggregate{counter});
        hotspotcounter(i,2)=ukuran(1);
        hotspotcounter(i,3)=1;
        counter=counter+1;
    end
end

h=waitbar(0,'pleasewait');
for i=511:546%:length(studycase{1}.timespan)
    waitbar(i/length(studycase{1}.timespan),h,sprintf('plotting %.2f%%',i*100/length(studycase{1}.timespan)))
    s = get(0, 'ScreenSize');
    f = figure('visible', 'off','Position', [0 0 s(3) s(4)]);
    set(f, 'PaperPositionMode', 'auto');
    sgtitle(sprintf('Study Case 1 - %s UTC',datestr(studycase{1}.timespan(i),'DD/mm/YYYY HH:MM')))
    sp1= subplot(3,1,1);
    ratiofix
    hold on
    %plot study area
    plot(studyarea,'FaceColor','none','LineStyle','--','EdgeColor','black')
    
    %plot TIR availability
    for j=1:length(studycase)
        if studycase{j}.TIRflag(i)==0
           colourTIR = [1 1 1]; 
        elseif studycase{j}.TIRflag(i)==1
            colourTIR = [0.5 0.5 0.5]; %grey if TIR not available
        end
        plot(studycase{j}.shape,'FaceColor',colourTIR,'FaceAlpha',1,'EdgeColor','none')
    end
    
    %plot hotspot
    k=find(hotspot(:,1)<=studycase{1}.timespan(i));

    for m=1:length(k)
       
        %create hotspot
        Radius=1/111; %15km
        hotspotpoly=nsidedpoly(20,'Center',[hotspot(k(m),2) hotspot(k(m),3)],'Radius',Radius);
        usia= (studycase{1}.timespan(i)-hotspot(k(m),1))*24;
        if usia == 0
            hs_colour = [0 0 0];
        elseif usia <= 2
            hs_colour = [151 0 30]./255;
        elseif usia <= 6
            hs_colour = [182 34 12]./255;
        elseif usia <= 24
            hs_colour = [167 71 2]./255;
        elseif usia <= 48
            hs_colour = [148 103 1]./255;
        else 
            hs_colour = [97 97 0]./255;
        end
        
        plot(hotspotpoly,'FaceColor',hs_colour,'EdgeColor',hs_colour,'FaceAlpha',1);
    end
    ratiofix
    
    %plot drop
    if i==length(studycase{1}.timespan)
        l=find(drop(:,1)>=studycase{1}.timespan(i));
    else
        l=find(drop(:,1)<studycase{1}.timespan(i+1) & drop(:,1)>=studycase{1}.timespan(i));
    end

    for n=1:length(l)
        if i==117 & (n==1 | n==8) %skip blunder
            continue
        end
        p1 = [drop(l(n),2) drop(l(n),3)]; % First Point
        p2 = [drop(l(n),4) drop(l(n),5)]; % Second Point
        dp = (p2-p1).*15;                       % Difference
        dp_threshold = 2/111;%in km
        if dp(1)>dp_threshold 
            dp(1)=dp_threshold;
        elseif dp(1) < -dp_threshold
            dp(1)=-dp_threshold;
        end
        if dp(2)>dp_threshold
            dp(2)=dp_threshold;
        elseif dp(2)<-dp_threshold
            dp(2)=-dp_threshold;
        end
        quiver(p1(1),p2(2),dp(1),dp(2),'LineWidth',3,'Color','blue','ShowArrowHead','on','MaxHeadSize',5)
    end  
    
    %plot time slider
    sp2=subplot(3,1,2);
    plot(hotspotcounter(:,1),hotspotcounter(:,3),'o','MarkerEdgeColor','red','MarkerFaceColor','red')
    hold on
    avail(:,1)=availcounter.timespan;
    avail(:,2)=availcounter.TIR;
    avail(:,3)=availcounter.MIR;
    k=find(avail(:,2)==0);
    avail(k,2)=NaN;
    k=find(avail(:,2)>=1);
    avail(k,2)=0.5;
    plot(avail(:,1),avail(:,2),'o','MarkerEdgeColor',[0.5 0.5 0.5],'MarkerFaceColor',[0.5 0.5 0.5])
    plot(drop(:,1),1.5,'o','MarkerEdgeColor',[0.25 0.25 1],'MarkerFaceColor',[0.25 0.25 1])
    text(studycase{1}.timespan(i)-0.025,1.05,'I','FontSize',30)
    set(gca,'YTickLabel',[]);
    xlabel('UTC')
    datetick('x')
    sp2.XLim=[737804 737809];
    
    %plot the hotspot legend
    sp3=subplot(3,1,3);
    hold on
    
    hs_colour_arr(1,:) = [0 0 0];
    hs_colour_arr(2,:) = [151 0 30]./255;
    hs_colour_arr(3,:) = [182 34 12]./255;
    hs_colour_arr(4,:) = [167 71 2]./255;
    hs_colour_arr(5,:) = [148 103 1]./255;
    hs_colour_arr(6,:) = [97 97 0]./255;
    hs_colour_text{1}='Current hotspot';
    hs_colour_text{2}='0-2 hours';
    hs_colour_text{3}='2-6 hours';
    hs_colour_text{4}='6-24 hours';
    hs_colour_text{5}='24-48 hours';
    hs_colour_text{6}='>48 hours';
        
    for j=1:length(hs_colour_arr)
        shape=polyshape([(1-1)+1,(1-1)+1,(1-1)+2,(1-1)+2],[(j-1)+1,(j-1)+2,(j-1)+2,(j-1)+1]);
        [x,y]=centroid(shape);
        text(x+1,y,hs_colour_text{j});
        plot(shape,'FaceColor',hs_colour_arr(j,:),'EdgeColor','none','FaceAlpha',1);
    end
    set(sp3,'XColor','none','YColor','none','Color','none','XTick',[],'YTick',[])
    sp3.Title.Position=[3 7.25 0];
    title('Hotspot Legend')
    ratiofix
    
    %set each axes position
    %set(gca,'PositionConstraint','outerposition')
    sp2.Position=[0.13 0.11 0.775 0.02];drawnow
    sp1.Position=[0.1 0.2 0.8 0.7];drawnow
    sp2.Position=[0.13 0.11 0.775 0.02];drawnow
    sp3.Position=[0.4 0.21 0.775 0.22];drawnow
    %set(gca,'Position',[0.1300 0.1100 0.7750 0.1])
    %ylim([0.99999 1.00001])
    %line([studycase{1}.timespan(i) studycase{1}.timespan(i)],[ylimit(1) ylimit(2)],'LineStyle','--','LineWidth',5,'Color','black')
    %plot(studycase{1}.timespan(i),1,'o','MarkerEdgeColor','black','MarkerFaceColor','black')

    
    exportgraphics(f,sprintf('D:/Research/2021/Gridding/Figures/animation/studycase1_%04d.png',i))
    close(f)
end
close(h)