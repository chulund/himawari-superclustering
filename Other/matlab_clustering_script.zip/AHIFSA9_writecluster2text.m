%script to write supercluster data to file (including shapes
clc;clear

load('matfile/AHIFSA_aus_supercluster_att.mat')

fid=fopen('fileout/AHIFSA_aus_supercluster.csv','w');
%fprintf(fid,'fid,supercluster name,time start,time end,no of hotspots,fire duration(hours),fire area(km2),WKT supercluster,WKT hotspot\n');
fprintf(fid,'fid,name,time start,time end,no of hotspots,duration(hours),area(km2)\n');
for i=1:length(supercluster)
    if strcmp(supercluster{i}.id,'SC')
        %if it is supercluster
        %write supercluster id,supercluster name,time start,time end,no of hotspot
        fprintf(fid,'%i,%s,%s,%s,%i,',i,supercluster{i}.id,datestr(supercluster{i}.startend(1),'DD-mm-YYYY HH:MM:SS'),datestr(supercluster{i}.startend(2),'DD-mm-YYYY HH:MM:SS'),supercluster{i}.numHS);
        %write fire duration(hours),fire area(km2)
        fprintf(fid,'%.3f,%.3f',supercluster{i}.duration,supercluster{i}.area);
        %write WKT supercluster
        %S=polyshape2WKT(supercluster{i}.circle);
        %fprintf(fid,'%s,',S);
        %WKT hotspot
        %S=hsdatas2WKT(supercluster{i}.hs_datas);
        %fprintf(fid,'%s\n',S);
        fprintf(fid,'\n');
    else
        %if it is just a cluster
        %write supercluster id,supercluster name,time start,time end,no of hotspot
        fprintf(fid,'%i,%s,%s,%s,%i,%i,\n',i,supercluster{i}.id,datestr(supercluster{i}.startend(1),'DD-mm-YYYY HH:MM:SS'),datestr(supercluster{i}.startend(2),'DD-mm-YYYY HH:MM:SS'),supercluster{i}.numHS);
        %write fire duration(hours),fire area(km2)
        fprintf(fid,'%.3f,%.3f',supercluster{i}.duration,supercluster{i}.area);
        %write WKT supercluster
        %S=polyshape2WKT(supercluster{i}.circle);
        %fprintf(fid,'%s,',S);
        %WKT hotspot
        %S=hsdata2WKT(supercluster{i}.hs_data);
        %fprintf(fid,'%s',S);
        fprintf(fid,'\n');
    end
end
fclose(fid);