%script to clean AHIDEA data and cut the data
clc;clear;  
% Data readme
%    date, longitude, latitude, MIR, TIR, Albedo, FRP
%

%load cleaned data
if ~exist('matfile/AHIFSA_all_clean.mat')
    load('matfile/AHIFSA_all.mat')
    %get long lat time
    for i=1:length(data)
        hs_long(i)=str2double(data{i,2});
        hs_lat(i) =str2double(data{i,3});
        timestr = sprintf('%i',str2double(data{i,1}));
        hs_time(i) =datenum(str2num(timestr(1:4)),str2num(timestr(5:6)),str2num(timestr(7:8)),str2num(timestr(9:10)),str2num(timestr(11:12)),str2num(timestr(13:14)));
        hs_frp(i) = str2double(data{i,7});
    end
    save matfile/AHIFSA_all_clean hs_long hs_lat hs_time hs_frp
else
    load('matfile/AHIFSA_all_clean.mat')
end

%cut data to only 1 phenomenon
save4cut=[];
for i=1:length(hs_long)
    if (hs_lat(i)<-38)||(hs_lat(i)>-35.8)||(hs_long(i)<146)||(hs_long(i)>150)
        save4cut=[save4cut;i];
    end
end
hs_long(save4cut)=[];hs_lat(save4cut)=[];hs_time(save4cut)=[];hs_frp(save4cut)=[];
save matfile/AHIFSA_aus_clean hs_long hs_lat hs_frp hs_time 

return
%cut data to only australia
save4cut=[];
for i=1:length(hs_long)
    if (hs_lat(i)>-11)
        save4cut=[save4cut;i];
    end
end
hs_long(save4cut)=[];hs_lat(save4cut)=[];hs_time(save4cut)=[];hs_frp(save4cut)=[];
save matfile/AHIFSA_aus_clean hs_long hs_lat hs_frp hs_time 

return


