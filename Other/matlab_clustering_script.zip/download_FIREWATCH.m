% download AHI data from FIREWATCH
clc;clear;
%outfolder='data/FIREWATCH_NEW/result/dailySRSS/';
outfolder='D:\Research\2021\Clustering\data\firewatch_compare\';
if ~exist(outfolder)
    mkdir(outfolder)
end
import java.util.TimeZone

%https://srss-ows-11.landgate.wa.gov.au/wxs/dynamic.php?&type=64&fromdate=1551358800&todate=1551963599&mapextent=&SERVICE=WFS&REQUEST=GetFeature&VERSION=1.1.0&SRS=EPSG:4326&BBOX=87,-51,178,-8.9&TYPENAME=layer64_201902282200_HI8_AHI_TKY_FHS.shp&OUTPUTFORMAT=text/csv&DOWNLOAD=1
%https://srss-ows-11.landgate.wa.gov.au/wxs/dynamic.php?&type=64&fromdate=1551358800&todate=1551963599&mapextent=&SERVICE=WFS&REQUEST=GetFeature&VERSION=1.1.0&SRS=EPSG:4326&BBOX=87,-51,178,-8.9&TYPENAME=layer64_201902282120_HI8_AHI_TKY_FHS.shp&OUTPUTFORMAT=text/csv&DOWNLOAD=1
datemin=[2019 12 01]; %sydney time
datemax=[2020 02 01];

%processing start
datenumST=datenum(datemin);
datenumED=datenum(datemax);
datenumTO=datenumST:datenumED;
h=waitbar(0,'please wait');
for i=1:length(datenumTO)
    waitbar(i/length(datenumTO),h,sprintf('%.2f%%',i/length(datenumTO)*100));
    dateToday= datevec(datenumTO(i));
    
    %download for each 10 minutes
    timeStart=datenumTO(i)-datenum([0 0 0 3 0 0]); %tokyo time vs sydney time
    timeEnd=datenumTO(i)+datenum([0 0 0 23 50 0])-datenum([0 0 0 3 0 0]);
    timeTotal=linspace(timeStart,timeEnd,144);
    
    for j=1:length(timeTotal)
        posixStart=posixtime(datetime(datestr(timeTotal(j)-3),'TimeZone',char(TimeZone.getDefault().getID())));
        posixEnd=posixtime(datetime(datestr(timeTotal(j)+3),'TimeZone',char(TimeZone.getDefault().getID())));
        urlbase=sprintf('https://srss-ows-11.landgate.wa.gov.au/wxs/dynamic.php?&type=64&fromdate=%i&todate=%i&mapextent=&SERVICE=WFS&REQUEST=GetFeature&VERSION=1.1.0&SRS=EPSG:4326&BBOX=87,-51,178,-8.9&TYPENAME=layer64_',posixStart,posixEnd);

        dT=datevec(timeTotal(j));
        frmt1=datestr(timeTotal(j),'YYYYmmDD');
        frmt2=datestr(timeTotal(j),'HHMM');
        url2dwl=sprintf('%s%s%s_HI8_AHI_TKY_FHS.shp&OUTPUTFORMAT=text/csv&DOWNLOAD=1',urlbase,frmt1,frmt2);
        filename=sprintf('%s%s%sAHI_TKY_FHS.txt',outfolder,frmt1,frmt2);
        fprintf('downloading %s\n',filename);   
        try
            websave(filename,url2dwl);
        catch
            delete(filename);
            continue
        end
        
    end
    
end
close(h);