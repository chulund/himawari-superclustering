%script to cluster the dailydata
clc;clear;
load('matfile/AHIFSA_aus_daily.mat')
tic
%search radius in m
radius=3500;

%timing threshold in minutes
timeThres=0;

for k=1:length(dailydata)
    
    %take todays data
    hs_long=dailydata{k}.hs_long;
    hs_lat=dailydata{k}.hs_lat;
    hs_frp=dailydata{k}.hs_frp;
    hs_time=dailydata{k}.hs_time;
    hs_id=dailydata{k}.hs_id;
    
    if isempty(hs_long)
        continue
    end
    fprintf('processing date %s\n',datestr(floor(hs_time(1))))
    
    cor=[];
    fprintf('     1.creating circle\n')
    for i=1:length(hs_long)

        %create circle to check radius
        %[xv,yv] = createcircle(hs_long(i),hs_lat(i),radius,pi/5);
        newcircle = nsidedpoly(10, 'Center',[hs_long(i),hs_lat(i)], 'Radius', rad2deg(radius/6378137));
        xv=newcircle.Vertices(:,1);
        yv=newcircle.Vertices(:,2);

        [in,on] = inpolygon(hs_long,hs_lat,xv,yv);
        
        %create a corelation matrix
        cor(i,:)=in;
        
        %save circle
        hs_circle{i}=newcircle;
        
    end    

    %update corelation matrix to also consider time difference
    fprintf('     2.considering time difference\n')
    timediffcnt=0;
    if timeThres
        for i=1:length(cor)
            for j=1:length(cor)
                %skip if self correlation
                if i==j
                    continue
                end
                %skip if correlation is zero
                if cor(i,j)==0
                    continue
                end
                %check if time difference > threshold
                timediff=hs_time(i)-hs_time(j);
                if (timediff*1440)>abs(timeThres)
                    cor(i,j)=0; %set correlation to 0
                    timediffcnt=timediffcnt+1;
                end
            end
        end
    end

    %spatial clustering
    cor_check=cor;

    counter2=1; % for each cluster
    aggregate=[];
    fprintf('     3.spatial clustering\n')
    for i=1:length(cor_check)
        cor_process=cor_check(i,:);
        if sum(cor_process)==0
            continue
        end
        %remove self correlation
        cor_check(i,i)=0;

        member=[];
        looping=[];
        counter=1;
        member(counter)=i;
        cor_check(i,:)=0;

        index=[];index=find(cor_process);
        if isempty(index)
            aggregate{counter2}=member;
            counter2=counter2+1;
        end

        looping=[looping;index'];
        while ~isempty(looping)

            counter=counter+1;
            member(counter)=looping(1,1);

            index=[];
            index=find(cor_check(looping(1,1),:));        
            if ~isempty(index)
                looping=[looping;index'];
            end
            %remove visited row
            cor_check(looping(1,1),:)=0;
            looping(1)=[];

        end
        aggregate{counter2}=unique(member);
        counter2=counter2+1;

    end

    cluster_HS{k}=aggregate';
    
    %creating a cluster structure
    fprintf('     4.creating a structure\n')
    
    %declare a structure
    doy = day(datetime(datevec(floor(hs_time(1)))),'dayofyear');
    dailyaggregate{k}.date=datestr(floor(hs_time(1)));
    dailyaggregate{k}.numcluster=length(aggregate);
    
    %insert HS info into dailyaggregate
    for i=1:length(aggregate)
        %make an ID
        doy = day(datetime(datevec(floor(hs_time(1)))),'dayofyear');
        dailyaggregate{k}.clusters{i}.id=sprintf('CS%03d_%04i',doy,i);
        %make a startenddate
        dailyaggregate{k}.clusters{i}.startend=[min(hs_time(aggregate{i})) max(hs_time(aggregate{i}))];
        dailyaggregate{k}.clusters{i}.numHS=length(aggregate{i});
        %make a cluster circle
        n=polyshape();
        for j=1:length(aggregate{i})
            n = union(n, hs_circle{aggregate{i}(j)});
        end
        dailyaggregate{k}.clusters{i}.circle=n;
        
        for j=1:length(aggregate{i})
            dailyaggregate{k}.clusters{i}.hs_data.hs_id(j,:)=hs_id(aggregate{i}(j),:);
            dailyaggregate{k}.clusters{i}.hs_data.hs_long(j,1)=hs_long(aggregate{i}(j));
            dailyaggregate{k}.clusters{i}.hs_data.hs_lat(j,1)=hs_lat(aggregate{i}(j));
            dailyaggregate{k}.clusters{i}.hs_data.hs_frp(j,1)=hs_frp(aggregate{i}(j));
            dailyaggregate{k}.clusters{i}.hs_data.hs_time(j,1)=hs_time(aggregate{i}(j));
            dailyaggregate{k}.clusters{i}.hs_data.hs_circle{j}=hs_circle{aggregate{i}(j)};
        end        
    end 
end

save matfile/AHIFSA_aus_daily_cluster.mat dailyaggregate
toc