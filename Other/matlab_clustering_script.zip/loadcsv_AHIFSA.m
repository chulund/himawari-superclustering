%script to load AHI-FSA hotspot
clc;clear;
filename='201906170410_201906170412_28_2968_3186_4239_4404.txt';

fid=fopen(filename);
counter=1;
while ~feof(fid)
    line=fgetl(fid);
    linesplit=strsplit(line,',','CollapseDelimiters', false);
    for i=1:7
        data{counter,i}=linesplit{i};
    end
    counter=counter+1;
end
fclose(fid);
save([filename+".mat"],'data');