%% plotting color coded super cluster 
clc;clear;
load('matfile/AHIDEA_aus_supercluster.mat')

for i=1:length(supercluster)
    supercluster{i}.duration=(supercluster{i}.startend(2)-supercluster{i}.startend(1))*24;
    startend(i,:)=supercluster{i}.startend;
    duration(i)=supercluster{i}.duration;
end

figure
load coast_i_aus
plot(long,lat)
hold on
cmap=flipud(brighten(autumn(6),0.2));

for i=1:length(supercluster)
    if supercluster{i}.duration < 1
        h(1)=plot(supercluster{i}.circle,'FaceColor',cmap(1,:),'FaceAlpha',1);
        legends{1}='< 1 hour';
    elseif supercluster{i}.duration < 24
        h(2)=plot(supercluster{i}.circle,'FaceColor',cmap(2,:),'FaceAlpha',1);
        legends{2}='< 24 hours';
    elseif supercluster{i}.duration < 48
        h(3)=plot(supercluster{i}.circle,'FaceColor',cmap(3,:),'FaceAlpha',1);
        legends{3}='1-2 days';
    elseif supercluster{i}.duration < 120
        h(4)=plot(supercluster{i}.circle,'FaceColor',cmap(4,:),'FaceAlpha',1);
        legends{4}='2-5 days';
    elseif supercluster{i}.duration < 240
        h(5)=plot(supercluster{i}.circle,'FaceColor',cmap(5,:),'FaceAlpha',1);
        legends{5}='5-10 days';
    else
        h(6)=plot(supercluster{i}.circle,'FaceColor',cmap(6,:),'FaceAlpha',1);
        legends{6}='> 10 days';
    end
    [x,y]=centroid(supercluster{i}.circle);
    text(x,y,sprintf('%i',i))
end
%remove empty legends
for i=1:length(legends)
    if isempty(legends{i})
        saved(i)=i;
    end
end
if exist('saved')
    legends(find(saved))=[];
    h(find(saved))=[];
end
legend(h,legends)
xlim([117.778902759457 121.21139855943])
ylim([-34.1418807677157 -31.4721618121808]) 
title(sprintf('Fire clusters Western Australia %s to %s',datestr(floor(min(startend(:,1)))),datestr(floor(max(startend(:,2))))))
saveas(gcf,'figures/Super Cluster WA Reclassification.png')