%writing supercluster in text to create animation
fid=fopen('fileout/superclusteranim.txt','w');
scid=1;
for i=1:length(supercluster)
    if strcmp(supercluster{i}.id,'SC')
        fprintf(fid,'%i\t',scid);
        scid=scid+1;
        for j=1:length(supercluster{i}.clusterid)
            fprintf(fid,'%s\t',supercluster{i}.clusterid{j});
        end
        fprintf(fid,'\n');
    end
end
fclose(fid);