for i=1:length(FSAd.dailydata)
    fprintf('FSA %i data for %s\n',length(FSAd.dailydata{i}.hs_long),FSAd.dailydata{i}.date)
end
for i=1:length(FWTd.dailydata)
    fprintf('FWT %i data for %s\n',length(FWTd.dailydata{i}.hs_long),FWTd.dailydata{i}.date)
end