clc;clear
himawarifakeX(5500,5500,2)=uint16(0);
himawarifakeY(5500,5500,2)=uint16(0);
for i=1:5500
    himawarifakeY(i,:,1)=i;
end
himawarifakeY(:,:,2)=65535;
for j=1:5500
    himawarifakeX(:,j,1)=j;
end
himawarifakeX(:,:,2)=65535;

return
% for k=1:5500
%     himawarifake(:,k,3)=65535;
% end
if exist('t1','var')
    close(t1)
end
if exist('himawarifakeX.tif','file')
    delete himawarifakeX.tif himawarifakeY.tif
    copyfile FulldiskNative.tif himawarifakeX.tif
    copyfile FulldiskNative.tif himawarifakeY.tif
end
faketifname1='himawarifakeX.tif';
faketifname2='himawarifakeY.tif';

%load ref file from the real himawari 
% infos = geotiffinfo('FulldiskNative.tif');

t1=Tiff(faketifname1,'r+');
t2=Tiff(faketifname2,'r+');


% t = Tiff(faketifname,'w');  
% tagstruct.ImageLength = size(himawarifake,1); 
% tagstruct.ImageWidth = size(himawarifake,2);
% tagstruct.Photometric = Tiff.Photometric.MinIsBlack;
% tagstruct.BitsPerSample = 16;
% tagstruct.SamplesPerPixel = 2;
% tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky; 
% tagstruct.Software = 'MATLAB';
% tagstruct.Orientation=Tiff.Orientation.TopLeft;
% tagstruct.SampleFormat=Tiff.SampleFormat.UInt;
% tagstruct.Compression=Tiff.Compression.LZW;

%setTag(t,tagstruct);
fprintf('writing...\n');
setTag(t1,'BitsPerSample',16);
setTag(t2,'BitsPerSample',16);
write(t1,himawarifakeX);
write(t2,himawarifakeY);


close(t1);
close(t2);