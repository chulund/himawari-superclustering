%script to load FIREWATCH hotspot
clc;clear;
folder='D:/Research/2020/Hotspot/persistence/data/FIREWATCH_NEW/result/dailySRSS/FIREWATCH/';

flist=dir([folder '*.txt']);
counter=1;
h=waitbar(0,'please wait');
for i=1:length(flist)
    waitbar(i/length(flist),h,sprintf('%.2f%%',i/length(flist)*100));
    filename=flist(i).name;
    fid=fopen([folder filename],'r');
    line=fgetl(fid);
    while ~feof(fid)
        line=fgetl(fid);
        linesplit=strsplit(line,',','CollapseDelimiters', false);
        for i=1:length(linesplit)
            data{counter,i}=linesplit{i};
        end
        counter=counter+1;
    end
    fclose(fid);

    
end
close(h);
save('FIREWATCH.mat','data');