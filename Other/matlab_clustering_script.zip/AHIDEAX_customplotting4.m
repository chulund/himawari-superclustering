%produce temporal plot of the super cluster
clc;clear
load('matfile/AHIDEA_aus_supercluster_att.mat')
load('matfile/temp.mat')

%tick modifiable
minimumT=min(timeS);
maximumT=max(timeS);
fullT=minimumT:1/6:maximumT+1; %4 hourly 
sumari=tabulate(timeS);
simpan=zeros(length(fullT));

for i=1:length(fullT)
    k=find(fullT(i)==sumari(:,1));
    if ~isempty(k);
        simpan(i)=i;
    end
end
fullT(find(simpan))=[];

data(:,1)=[fullT';sumari(:,1)];
data(:,2)=[zeros(length(fullT),1);sumari(:,2)];
data=sortrows(data,1);
figure
plot(data(:,1),data(:,2),'LineWidth',1.2)
title('Fire Super Cluster 3 Time Series')
set(gca,'XTick',737827.5:737832.5)
hold on
for i=737827:737833
    z=line(linspace(i,i,100),linspace(0,100,100),'LineStyle','--','LineWidth',1.5,'Color',[1 0 0])
end
datetick('x','dd/mm','keepticks')
ylabel('number of hotspot')
xlabel('date')
set(gca,'FontSize',15)
legend(z,{'midnight'})
saveas(gcf,'figures/timeseries.png')
return
%tick max (each 10 minutes)
minimumT=min(timeS);
maximumT=max(timeS);
fullT=minimumT:1/144:maximumT+1;

sumari=tabulate(timeS);
data=zeros(length(fullT));
for i=1:length(fullT)
    k=find(fullT(i)==sumari(:,1));
    if ~isempty(k);
        data(i)=sumari(k,2);
    end
end

MeasurementTime=datetime(datevec(fullT));
TT=timetable(MeasurementTime,data);

plot(fullT,data)

return