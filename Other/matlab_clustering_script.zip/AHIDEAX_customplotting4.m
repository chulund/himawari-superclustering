%produce temporal plot of the super cluster
clc;clear
load('matfile/AHIDEA_aus_supercluster_att.mat')

for i=
%tick modifiable
minimumT=min(timeS);
maximumT=max(timeS);
fullT=minimumT:1/6:maximumT+1; %4 hourly 
sumari=tabulate(timeS);
simpan=zeros(length(fullT));

for i=1:length(fullT)
    k=find(fullT(i)==sumari(:,1));
    if ~isempty(k);
        simpan(i)=i;
    end
end
fullT(find(simpan))=[];

data(:,1)=[fullT';sumari(:,1)];
data(:,2)=[zeros(length(fullT),1);sumari(:,2)];
data=sortrows(data,1);
figure
plot(data(:,1),data(:,2))
title('
return
%tick max (each 10 minutes)
minimumT=min(timeS);
maximumT=max(timeS);
fullT=minimumT:1/144:maximumT+1;

sumari=tabulate(timeS);
data=zeros(length(fullT));
for i=1:length(fullT)
    k=find(fullT(i)==sumari(:,1));
    if ~isempty(k);
        data(i)=sumari(k,2);
    end
end

MeasurementTime=datetime(datevec(fullT));
TT=timetable(MeasurementTime,data);

plot(fullT,data)

return