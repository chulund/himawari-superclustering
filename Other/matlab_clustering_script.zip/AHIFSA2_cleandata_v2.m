tic %script to clean AHIDEA data and cut the data
clc;clear;  
% Data readme
%   dt,hx,hy,lon,lat,mir,tir,albedo,frp
%

%load cleaned data
if ~exist('matfile/AHIFSA_all_clean.mat')
    load('matfile/AHIFSA_all.mat')
    %get long lat time
    for i=1:length(data)
        hs_long(i)=str2double(data{i,4});
        hs_lat(i) =str2double(data{i,5});
        timestr = sprintf('%i',str2double(data{i,1}));
        hs_time(i) =datenum(str2num(timestr(1:4)),str2num(timestr(5:6)),str2num(timestr(7:8)),str2num(timestr(9:10)),str2num(timestr(11:12)),str2num(timestr(13:14)));
        hs_frp(i) = str2double(data{i,9});
        hs_hx(i) = str2double(data{i,2});
        hs_hy(i)=str2double(data{i,3});
    end
    save matfile/AHIFSA_all_clean hs_*
else
    load('matfile/AHIFSA_all_clean.mat')
end
save matfile/AHIFSA_aus_clean hs_* 
return
%cut data to only australia
save4cut=[];
for i=1:length(hs_long)
    if (hs_lat(i)>-11)
        save4cut=[save4cut;i];
    end
end
hs_long(save4cut)=[];hs_lat(save4cut)=[];hs_time(save4cut)=[];hs_frp(save4cut)=[];hs_hx(save4cut)=[];hs_hy(save4cut)=[];

%convert pixel number to long lat
%[hs_longTrans,hs_latTrans]=himapixnum2longlat(hs_hx,hs_hy);
save matfile/AHIFSA_aus_clean hs_* 
toc
return

%cut data to only 1 phenomenon
save4cut=[];
for i=1:length(hs_long)
    if (hs_lat(i)<-34)|(hs_lat(i)>-32)|(hs_long(i)<118.5)|(hs_long(i)>120.5)
        save4cut=[save4cut;i];
    end
end
hs_long(save4cut)=[];hs_lat(save4cut)=[];hs_time(save4cut)=[];hs_temp(save4cut)=[];
save matfile/AHIDEA_aus_clean hs_*
return

