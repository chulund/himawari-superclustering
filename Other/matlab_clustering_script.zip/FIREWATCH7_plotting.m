%plot all data daily
clc;clear;
figure
load coast_i_aus
plot(long,lat)
hold on

load('matfile/FIREWATCH_aus_daily.mat')
day=8;

plot(dailydata{day}.hs_long,dailydata{day}.hs_lat,'.b')
ratiofix


timeS2=dailydata{8}.hs_time-datenum([0 0 0 6 0 0]);
minimumT=min(timeS2);
maximumT=max(timeS2);
fullT2=minimumT:1/8:maximumT+1; %4 hourly 
sumari2=tabulate(timeS2);
simpan=zeros(length(fullT2));

for i=1:length(fullT2)
    k=find(fullT2(i)==sumari2(:,1));
    if ~isempty(k);
        simpan(i)=i;
    end
end
fullT2(find(simpan))=[];

data2(:,1)=[fullT2';sumari2(:,1)];
data2(:,2)=[zeros(length(fullT2),1);sumari2(:,2)];
data2=sortrows(data2,1);

figure
plot(data2(:,1),data2(:,2))
xlim([min(timeS2)-datenum([0 0 0 1 0 0]) max(timeS2)+datenum([0 0 0 1 0 0])])
title('Hotspot Time Series for 8 November 2019')
datetick('x','keeplimits')
ylabel('number of hotspot')
hold on
xlabel('time')
ylimit=get(gca,'YLim');
line([sumari2(find(sumari2(:,2)==max(sumari2(:,2))),1) sumari2(find(sumari2(:,2)==max(sumari2(:,2))),1)],[min(sumari2(:,2))-.2*(max(sumari2(:,2))-min(sumari2(:,2))) max(sumari2(:,2))+.2*(max(sumari2(:,2))-min(sumari2(:,2)))],'Color','blue','LineStyle','--');
set(gca,'YLim',ylimit)
text(sumari2(find(sumari2(:,2)==max(sumari2(:,2))),1)+datenum([0 0 0 0 30 0]),max(sumari2(:,2)),sprintf('maximum %s with %i hotspots',datestr(sumari2(find(sumari2(:,2)==max(sumari2(:,2))),1),'HH:MM'),max(sumari2(:,2))),'Color','blue')
%line([sumari(find(sumari(:,2)==max(sumari(:,2))),1) sumari(find(sumari(:,2)==max(sumari(:,2))),1)],[min(sumari(:,2))-.2*(max(sumari(:,2))-min(sumari(:,2))) max(sumari(:,2))+.2*(max(sumari(:,2))-min(sumari(:,2)))],'Color','blue','LineStyle','--');
%set(gca,'YLim',ylimit)
%text(sumari(find(sumari(:,2)==max(sumari(:,2))),1)+datenum([0 0 0 0 30 0]),max(sumari(:,2)),sprintf('maximum %s with %i hotspots',datestr(sumari(find(sumari(:,2)==max(sumari(:,2))),1),'HH:MM'),max(sumari(:,2))),'Color','blue')

return
%% plot all cluster daily
clc;clear;
figure
load coast_i_aus
plot(long,lat)
hold on

load('matfile/FIREWATCH_aus_daily_cluster.mat')
for i=1:length(dailyaggregate)
    if ~isempty(dailyaggregate{i})%to prevent plotting empty field
        for j=1:length(dailyaggregate{i}.clusters)
           plot(dailyaggregate{i}.clusters{j}.circle,'FaceAlpha',0.1)
        end
    end
end
return

%% plot daily supercluster

clc;clear;

day = 2;

figure
load coast_i_aus
plot(long,lat)
hold on

load('matfile/FIREWATCH_aus_dailysupercluster.mat')
for i=day
    for j=1:length(dailysupercluster{i}.clusters)
        plot(dailysupercluster{i}.clusters{j}.circle,'HoleEdgeAlpha',0.1,'FaceAlpha',0.4)
        [x,y]=centroid(dailysupercluster{i}.clusters{j}.circle);
        if strcmp(dailysupercluster{i}.clusters{j}.id,'SC')
            text(x,y,sprintf('SC%02i',j))
        else
            text(x,y,sprintf('CS%s',dailysupercluster{i}.clusters{j}.id(end-1:end)))
        end
    end
end
title(sprintf('Figure of Clusters on %s',datestr(floor(dailysupercluster{i}.clusters{1}.startend(1)))))
return

%% plotting 1 day cluster only
clc;clear;

day = 2;

figure
load coast_i_aus
plot(long,lat)
hold on

load('matfile/FIREWATCH_aus_daily_cluster.mat')
for i=day
    for j=1:length(dailyaggregate{i}.clusters)
        plot(dailyaggregate{i}.clusters{j}.circle,'HoleEdgeAlpha',0.1,'FaceAlpha',0.4)
        [x,y]=centroid(dailyaggregate{i}.clusters{j}.circle);
        text(x,y,dailyaggregate{i}.clusters{j}.id(end-3:end))
    end
end
title(sprintf('Figure of Clusters on %s',dailyaggregate{i}.date))
return

%% plotting day by day cluster with color
clc;clear;

day = 1:3;

figure
load coast_i_aus
plot(long,lat)
hold on

load('matfile/FIREWATCH_aus_daily_cluster1.mat')
cmap=distinguishable_colors(length(day));
for i=1:length(day)
    if ~isempty(dailyaggregate{day(i)})
        for j=1:length(dailyaggregate{day(i)}.clusters)
            h(i)=plot(dailyaggregate{day(i)}.clusters{j}.circle,'FaceColor',cmap(i,:),'HoleEdgeAlpha',0.1,'FaceAlpha',0.4);
        end
    end
    legends{i}=sprintf('%s',dailyaggregate{day(i)}.date);
end
legend(h,legends)
xlim([117.94748836483 120.526373263382])
ylim([-33.7006864104863 -31.6948870449454])

return
%% custom plotting
clc;clear;
figure
load coast_i_aus
plot(long,lat)
hold on

load('matfile/FIREWATCH_aus_daily_cluster1.mat')
plot(dailyaggregate{1}.clusters{1}.circle,'HoleEdgeAlpha',0.1,'FaceAlpha',0.4)
plot(dailyaggregate{2}.clusters{1}.circle,'HoleEdgeAlpha',0.1,'FaceAlpha',0.4)

return
%% plotting supercluster only
clc;clear;
figure
load coast_i_aus
plot(long,lat)
hold on

load('matfile/FIREWATCH_aus_supercluster.mat')
SC_count=0;
%cmap=distinguishable_colors(15);
for i=1:length(supercluster)
    if strcmp(supercluster{i}.id,'SC')
        SC_count=SC_count+1;
        %plot(supercluster{i}.circle,'FaceColor',cmap(SC_count,:),'HoleEdgeAlpha',0.1,'FaceAlpha',0.4)
        plot(supercluster{i}.circle,'HoleEdgeAlpha',0.1,'FaceAlpha',0.4)
        [x,y]=centroid(supercluster{i}.circle);
        %text(x,y,sprintf('%i',i),'Color',cmap(SC_count,:))
        text(x,y,sprintf('%i',i))
    end
end
title(sprintf('Figure of %i Super Cluster',SC_count))
return
%% plotting hotspot only (all)
clc;clear;
figure
load coast_i_aus
plot(long,lat)
hold on

load('matfile/FIREWATCH_all_clean.mat')
plot(hs_long,hs_lat,'.r')
ratiofix




