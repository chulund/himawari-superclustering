%% plotting heat map each hotspot for a super cluster
clc;clear;
load('matfile/AHIDEA_aus_supercluster.mat')

superclusternumber=3;

for i=1:length(supercluster)
    supercluster{i}.duration=(supercluster{i}.startend(2)-supercluster{i}.startend(1))*24;
    startend(i,:)=supercluster{i}.startend;
    duration(i)=supercluster{i}.duration;
end

superclusterUTM=supercluster;
for i=superclusternumber
    for m=1:length(supercluster{i}.circle.Vertices)
        longitude=supercluster{i}.circle.Vertices(m,1);
        latitude=supercluster{i}.circle.Vertices(m,2);
        xy=ell2utm([latitude;longitude;0],getUTMzone(longitude,'d'),2,'d');
        xys(m,1)=xy(1)+500000;xys(m,2)=xy(2)+10000000;                
    end
    superclusterUTM{i}.circle.Vertices=xys;
    supercluster{i}.area=area(superclusterUTM{i}.circle);
end
                            
figure
load coast_i_aus
plot(long,lat)
hold on
cmap=flipud(brighten(autumn(6),0.2));
if superclusternumber==2
    xlim([118.18800457784 120.766889476392])
    ylim([-33.3592251556771 -31.3534257901363]) 
elseif superclusternumber==3
    xlim([118.98800548836 121.332446305225])
    ylim([-34.0400884654838 -32.2166344968102])
else
    xlim([117.94748836483 120.526373263382])
    ylim([-33.7006864104863 -31.6948870449454])
end
counter=1;counter2=1;
for i=superclusternumber
    plot(supercluster{i}.circle,'FaceColor','none','LineStyle','--')
    for j=1:length(supercluster{i}.hs_datas)
        for k=1:length(supercluster{i}.hs_datas{j}.hs_circle)
            plot(supercluster{i}.hs_datas{j}.hs_circle{k},'FaceColor','red','FaceAlpha',0.01,'LineStyle','none')
            
        end
        for m=1:length(supercluster{i}.hs_datas{j}.hs_time)
            timeS(counter)=supercluster{i}.hs_datas{j}.hs_time(m);
            counter=counter+1;
        end
        for m=1:length(supercluster{i}.hs_datas{j}.hs_temp)
            tempS(counter2)=supercluster{i}.hs_datas{j}.hs_temp(m);
            counter2=counter2+1;
        end
    end
end

%put attribute
pos = arrayfun(@plotboxpos, gca, 'uni', 0);
dim = cellfun(@(x) x.*[1 1 0.5 0.5], pos, 'uni',0);
str = {sprintf('Duration = %i hours',round(supercluster{superclusternumber}.duration)),
    sprintf('Date = %s to %s',datestr(floor(supercluster{superclusternumber}.startend(1))),datestr(floor(supercluster{superclusternumber}.startend(2)))),
    sprintf('Area = %0.3f km2',supercluster{superclusternumber}.area/1000000)}
annotation('textbox',dim{1},'String',str,'FitBoxToText','on','vert','bottom','EdgeColor','none')

title(sprintf('Hotspot Heatmap Super Cluster %i ',superclusternumber))
saveas(gcf,sprintf('figures/Super Cluster %i Hotspot Heatmap.png',superclusternumber))

save matfile/temp.mat timeS tempS