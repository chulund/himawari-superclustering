%% plotting animation
clc;clear;
load('matfile/AHIFSA_aus_dailysupercluster.mat')

for k=1:9
    day = k;

    figure
    load coast_i_aus
    plot(long,lat)
    hold on
    
    if isempty(dailysupercluster{day})
        continue
    end
    
    for i=day
        for j=1:length(dailysupercluster{i}.clusters)
            plot(dailysupercluster{i}.clusters{j}.circle,'HoleEdgeAlpha',0.1,'FaceAlpha',0.4)
            [x,y]=centroid(dailysupercluster{i}.clusters{j}.circle);
            text(x,y,sprintf('%02i',j))
        end
    end
    title(sprintf('Figure of Hotspot Supercluster on %s',datestr(floor(dailysupercluster{i}.clusters{1}.startend(1)))))
    xlim([146.118838806517 148.955612194925])
    ylim([-38.0924940373008 -35.8861147352058])
    saveas(gcf,sprintf('figures/SuperclusteringDay%02i.png',day))
    close(gcf)
end
return
