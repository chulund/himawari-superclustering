%comparing AHIFSA hotspot and FIREWATCH hotspot
clc;clear;
%load data
if ~exist('FSA.mat')
    FSA=load('..\clustering_AHIFSA\matfile\AHIFSA_aus_clean.mat');
    save FSA FSA
else
    load('FSA.mat')
end
if ~exist('FWT.mat')
    FWT=load('..\clustering_FIREWATCH\matfile\FIREWATCH_aus_clean.mat');
    save FWT FWT
else
    load('FWT.mat')
end

algorithm_use =2

%figuring out number of HS per day
datestart=datenum([2019 11 01]);
dateend=datenum([2019 11 30]);
datefull=datestart:dateend;
number=zeros(length(datefull),2);
for i=1:length(datefull)
    k1=find(datefull(i)==floor(FSA.hs_time));
    number(i,1)=length(k1);
    k2=find(datefull(i)==floor(FWT.hs_time));
    number(i,2)=length(k2);
end
%=========================================================================
%SLOWER ALGORITHM BELOW, COUNT ALL
%=========================================================================
%AHIFSA as variable, FIREWATCH as reference
%finding matching hotspot (True Positive) and false positive
if algorithm_use ==1
h=waitbar(0,'pleasewait');
count_TP=1;count_FP=1;
for i=1:length(FSA.hs_long)
    waitbar(i/length(FSA.hs_long),h,sprintf('AHIFSA as variable %.2f%%',i/length(FSA.hs_long)*100))
    agreement=zeros(length(FWT.hs_long),3);
    agreement(:,1)=((FSA.hs_long(i))==(FWT.hs_long));
    agreement(:,2)=((FSA.hs_lat(i))==(FWT.hs_lat));
    agreement(:,3)=((FSA.hs_time(i))==(FWT.hs_time));
    k=find(sum(agreement,2)==3);
    if sum(k)>0
        FSA_TP.hs_long(count_TP)=FSA.hs_long(i);
        FSA_TP.hs_lat(count_TP)=FSA.hs_lat(i);
        FSA_TP.hs_time(count_TP)=FSA.hs_time(i);
        count_TP=count_TP+1;   
    else
        FSA_FP.hs_long(count_FP)=FSA.hs_long(i);
        FSA_FP.hs_lat(count_FP)=FSA.hs_lat(i);
        FSA_FP.hs_time(count_FP)=FSA.hs_time(i);
        count_FP=count_FP+1;
    end       
end
fprintf('FWT as REFERENCE\n')
fprintf('number of FSA TP = %i\n',length(FSA_TP.hs_long))
fprintf('number of FSA FP = %i\n',length(FSA_FP.hs_long))
close(h)
%FIREWATCH as variable, AHIFSA as reference
%finding matching hotspot (True Positive) and false positive
count_TP=1;count_FP=1;
h=waitbar(0,'pleasewait');
for i=1:length(FWT.hs_long)
    waitbar(i/length(FSA.hs_long),h,sprintf('AHIFSA as variable %.2f%%',i/length(FSA.hs_long)*100))
    agreement=zeros(length(FSA.hs_long),3);
    agreement(:,1)=((FWT.hs_long(i))==(FSA.hs_long));
    agreement(:,2)=((FWT.hs_lat(i))==(FSA.hs_lat));
    agreement(:,3)=((FWT.hs_time(i))==(FSA.hs_time));
    k=find(sum(agreement,2)==3);
    if sum(k)>0
        FWT_TP.hs_long(count_TP)=FWT.hs_long(i);
        FWT_TP.hs_lat(count_TP)=FWT.hs_lat(i);
        FWT_TP.hs_time(count_TP)=FWT.hs_time(i);
        count_TP=count_TP+1;   
    else
        FWT_FP.hs_long(count_FP)=FWT.hs_long(i);
        FWT_FP.hs_lat(count_FP)=FWT.hs_lat(i);
        FWT_FP.hs_time(count_FP)=FWT.hs_time(i);
        count_FP=count_FP+1;
    end       
end
close(h)
fprintf('FSA as REFERENCE\n')
fprintf('number of FWT TP = %i\n',length(FWT_TP.hs_long))
fprintf('number of FWT FP = %i\n',length(FWT_FP.hs_long))
fprintf('TOTAL\n')
fprintf('total FSA hotspot= %i\n',length(FSA.hs_long))
fprintf('total FIREWATCH hotspot = %i\n',length(FWT.hs_long))
fprintf('total ALL hotpost = %i\n',length(FSA_TP.hs_long)+length(FSA_FP.hs_long)+length(FWT_FP.hs_long))

%plot
load coast_i_aus.mat
figure
plot(long,lat,'-k')
hold on
cmap=distinguishable_colors(3);
go=.2;
h3=plot(FWT_FP.hs_long,FWT_FP.hs_lat,'o','Color',[go go go],'MarkerFaceColor',cmap(3,:));
h2=plot(FSA_FP.hs_long,FSA_FP.hs_lat,'o','Color',[go go go],'MarkerFaceColor',cmap(2,:));
h1=plot(FSA_TP.hs_long,FSA_TP.hs_lat,'o','Color',[go go go],'MarkerFaceColor',cmap(1,:));
title(' WF-ABBA and FIREWATCH Comparison','FontSize',30)
legend([h1,h2,h3],{'Agreement','AHI-FSA only','Firewatch only'})
set(gcf, 'Position', get(0, 'Screensize'));
xlimit=xlim;ylimit=ylim;
pbaspect([xlimit(2)-xlimit(1) ylimit(2)-ylimit(1) 1])
saveas(gcf,'AHIFSA-FIREWATCH.png')
end


%=========================================================================
%FASTER ALGORITHM BELOW, BUT ONLY COUNT AGREEMENT   
%=========================================================================
%AHIFSA as variable, FIREWATCH as reference
%finding matching hotspot (True Positive) and false positive
if algorithm_use==2
h=waitbar(0,'pleasewait');
count_TP=1;
for i=1:length(FSA.hs_long)
    waitbar(i/length(FSA.hs_long),h,sprintf('AHIFSA as variable %.2f%%',i/length(FSA.hs_long)*100))
    long_agreement=find((FWT.hs_long)==(FSA.hs_long(i)));
    if sum(long_agreement)>0
        for j=1:length(long_agreement)
            if (FWT.hs_lat(long_agreement(j))==FSA.hs_lat(i))&&(FWT.hs_time(long_agreement(j))==FSA.hs_time(i))
                FSA_TP.hs_long(count_TP)=FSA.hs_long(i);
                FSA_TP.hs_lat(count_TP)=FSA.hs_lat(i);
                FSA_TP.hs_time(count_TP)=FSA.hs_time(i);
                count_TP=count_TP+1;
                break
            end
        end
    end
end
close(h)
fprintf('FWT as REFERENCE\n')
fprintf('number of FSA TP = %i\n',length(FSA_TP.hs_long))

%FIREWATCH as variable, AHIFSA as reference
%finding matching hotspot (True Positive) and false positive
h=waitbar(0,'pleasewait');
count_TP=1;
for i=1:length(FWT.hs_long)
    waitbar(i/length(FSA.hs_long),h,sprintf('FIREWATCH as variable %.2f%%',i/length(FSA.hs_long)*100))
    long_agreement=find((FSA.hs_long)==(FWT.hs_long(i)));
    if sum(long_agreement)>0
        for j=1:length(long_agreement)
            if (FSA.hs_lat(long_agreement(j))==FWT.hs_lat(i))&&(FSA.hs_time(long_agreement(j))==FWT.hs_time(i))
                FWT_TP.hs_long(count_TP)=FWT.hs_long(i);
                FWT_TP.hs_lat(count_TP)=FWT.hs_lat(i);
                FWT_TP.hs_time(count_TP)=FWT.hs_time(i);
                count_TP=count_TP+1;
                break
            end
        end
    end
end
close(h)
fprintf('FSA as REFERENCE\n')
fprintf('number of FWT TP = %i\n',length(FWT_TP.hs_long))
end


load coast_i_aus.mat
figure
plot(long,lat,'-k')
hold on
cmap=distinguishable_colors(3);
h1=plot(FSA.hs_long,FSA.hs_lat,'x','Color',cmap(1,:))
h2=plot(FWT.hs_long,FWT.hs_lat,'x','Color',cmap(2,:))
title('AHI-FSA vs Firewatch Hotspot')
legend([h1,h2],{'AHI-FSA hotspot','Firewatch hotspot'})
ratiofix