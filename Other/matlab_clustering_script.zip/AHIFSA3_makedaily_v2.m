%script to compile AHIFSA data daily and make it a structure 
clc;clear;
load('matfile/AHIFSA_aus_clean.mat')

%load lookuptable data
load('D:\Research\2020\Hotspot\persistence\compare2\nativeVSnearest\gdal\lookuptable.mat');

%doing the process daily
days=floor(min(hs_time)):floor(max(hs_time));

%load daily data
if ~exist('matfile/AHIFSA_aus_daily.mat')
    %separate data by date
    for i=1:length(days)
        today=find(~(floor(hs_time)-days(i)));
        doy = day(datetime(datevec(days(i))),'dayofyear');
        dailydata{i}.date=datestr(days(i));
        dailydata{i}.hs_id=['']; %initiate to prevent empty field
        for j=1:length(today)
            dailydata{i}.hs_id(j,:)=sprintf('HS%03d_%05i',doy,j);
        end
        dailydata{i}.hs_long=hs_long(today)';
        dailydata{i}.hs_lat=hs_lat(today)';
        dailydata{i}.hs_frp=hs_frp(today)';
        dailydata{i}.hs_time=hs_time(today)';
        dailydata{i}.hs_hx=hs_hx(today)';
        dailydata{i}.hs_hy=hs_hy(today)';
        %dailydata{i}.hs_longT=hs_longT(today)';
        %dailydata{i}.hs_latT=hs_latT(today)';

        hx=hs_hx(today)'+1;
        hy=hs_hy(today)'+1;

        long_out=zeros(size(hx));
        lat_out=zeros(size(hy));
        h=waitbar(0,'please wait');
        counter=1;
        doubleInc=0;
        for j=1:length(hx)
            waitbar(j/length(hx),h,sprintf('processing day %i/%i %.2f%%',i,length(days),j*100/length(hx)));
            k1=find(A1(:,:,1)==hx(j)); %find occurences in row
            k2=find(A2(:,:,1)==hy(j)); %find occurences in col
            [k,~,~]=intersect(k1,k2); %find intersection in occ.
            if ~isempty(k)
                [I,J]=ind2sub(size(A1),k); %convert found indices into matrix index
                if length(I)>1
                    doubleInc=doubleInc+1;
                end
                for z=1:length(I)
                    long_out(counter)=lon(I(z),J(z));
                    lat_out(counter)=lat(I(z),J(z));
                    counter=counter+1;
                end
            else
                long_out(counter)=NaN;
                lat_out(counter)=NaN;
                counter=counter+1;
            end
        end
        close(h)
        %hs_longT=long_out;
        %hs_latT=lat_out;
        dailydata{i}.hs_longT=long_out;
        dailydata{i}.hs_latT=lat_out;
    end
    save matfile/AHIFSA_aus_daily.mat dailydata
else
    load('matfile/AHIFSA_aus_daily.mat')
end