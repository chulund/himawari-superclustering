%script to clean BRIGHT data and cut the data
clc;clear;  
% Data readme
%    datetime, longitude, latitude, x, y, mir, tir, albedo
%
tic
%load cleaned data
if ~exist('matfile/BRIGHT_all_clean.mat')
    fdir=dir('matfile/BRIGHT_all_*.mat');
    for i=1:length(fdir)
        load(['matfile/',fdir(i).name])
        %get long lat time
        fprintf('reading file %s\n',fdir(i).name)
        if exist('hs_long','var')
            counter=length(hs_long);
        else
            counter=0;
        end
        for i=1:length(data)
            hs_long(counter+i)=str2double(data{i,2});
            hs_lat(counter+i) =str2double(data{i,3});
            timestr = sprintf('%i',str2double(data{i,1}));
            hs_time(counter+i) =datenum(str2num(timestr(1:4)),str2num(timestr(5:6)),str2num(timestr(7:8)),str2num(timestr(9:10)),str2num(timestr(11:12)),str2num(timestr(13:14)));
            hs_x(counter+i) = str2double(data{i,4});
            hs_y(counter+i) = str2double(data{i,5});
            hs_mir(counter+i) = str2double(data{i,6});
            hs_tir(counter+i) = str2double(data{i,7});
            hs_albedo(counter+i) = str2double(data{i,8});
        end
    end
    save matfile/BRIGHT_all_clean hs_long hs_lat hs_time hs_x hs_y
else
    load('matfile/BRIGHT_all_clean.mat')
end

%cut data to a large area

%k=find((hs_lat>=-37.4)&(hs_lat<=-36.5)&(hs_long>=146)&(hs_long<=147.7));
k=find((hs_lat>=-37.8)&(hs_lat<=-36.9)&(hs_long>=148.3)&(hs_long<=150.15));

hs_long=hs_long(k);hs_lat=hs_lat(k);hs_time=hs_time(k);hs_x=hs_x(k);hs_y=hs_y(k);
save matfile/BRIGHT_aus_clean hs_long hs_lat hs_time hs_x hs_y 

return

%cut data to only australia
save4cut=[];
for i=1:length(hs_long)
    if (hs_lat(i)>-11)
        save4cut=[save4cut;i];
    end
end
hs_long(save4cut)=[];hs_lat(save4cut)=[];hs_time(save4cut)=[];hs_x(save4cut)=[];hs_y(save4cut)=[];
save matfile/BRIGHT_aus_clean hs_long hs_lat hs_time hs_x hs_y 

toc
return


%cut data to only 1 phenomenon
save4cut=[];
for i=1:length(hs_long)
    if (hs_lat(i)<-38)||(hs_lat(i)>-35.8)||(hs_long(i)<146)||(hs_long(i)>150)
        save4cut=[save4cut;i];
    end
end
hs_long(save4cut)=[];hs_lat(save4cut)=[];hs_time(save4cut)=[];hs_x(save4cut)=[];hs_y(save4cut)=[];
save matfile/BRIGHT_aus_clean hs_long hs_lat hs_time hs_x hs_y

return