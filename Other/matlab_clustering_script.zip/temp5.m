clc;clear;
load('dataBRIcomb.mat')

%check fix vs round
dataBRI(:,1)=dataBRIcomb.hs_timeT;
dataBRI(:,2)=dataBRIcomb.hs_longT;
dataBRI(:,3)=edataBRIcomb.hs_latT;

dataBRI_fix(:,1)=dataBRIcomb.hs_timeT;
dataBRI_fix(:,2)=fix(dataBRIcomb.hs_longT*100)/100;
dataBRI_fix(:,3)=fix(dataBRIcomb.hs_latT*100)/100;

dataBRI_round(:,1)=dataBRIcomb.hs_timeT;
dataBRI_round(:,2)=round(dataBRIcomb.hs_longT,2);
dataBRI_round(:,3)=round(dataBRIcomb.hs_latT,2);

checking=ones(size(dataBRI));
for i=1:length(dataBRI)
    if sum(dataBRI_fix(i,:)==dataBRI_round(i,:))<3
        break
    end
end    