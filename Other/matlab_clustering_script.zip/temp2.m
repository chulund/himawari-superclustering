%plotting spatial and temporal distribution of BRI
if 0
    clc;clear;
    load matching_BRI
    load unmatching_BRI
    figure
    load coast_i_aus.mat
    plot(long,lat)
    hold on
    plot(matchingtotal_BRI(:,2),matchingtotal_BRI(:,3),'x')
    ratiofix
    title('spatial distribution of FIREWATCH and BRIGHT hotstpot matches')

    % create counting variable
    if ~exist('countmatch_exact_BRI.mat')
        counter=1;
        h=waitbar(0,'pleasewait');
        for i=1:length(dataBRI_epoch)
            waitbar(i/length(dataBRI_epoch),h,sprintf('counting match percentage\n%.2f%%',i/length(dataBRI_epoch)))  
            if sum(dataBRI_epoch{i}.matches)==0
                ukuran=size(dataBRI_epoch{i}.matches);
                countmax(counter)=ukuran(1);
                countmatch(counter)=sum(dataBRI_epoch{i}.matches);
                datematch(counter)=dataBRI_epoch{i}.epoch;
                counter=counter+1;
            else
                ukuran=size(dataBRI_epoch{i}.matches);
                countmax(counter)=ukuran(1);
                countmatch(counter)=sum(dataBRI_epoch{i}.matches);
                datematch(counter)=dataBRI_epoch{i}.epoch;
                counter=counter+1;
            end
        end
        close(h)
        save countmatch_exact_BRI countmax countmatch datematch
    else
        load countmatch_exact_BRI.mat
    end

    %aggregate per month
    %setting month
    monthlydate=datenum(2019,3:15,1);
    for i=1:length(monthlydate)
        if i==length(monthlydate)
            k=find(datematch>=monthlydate(i));
            monthlyindex{i}=k;
        else
            k=find(datematch>=monthlydate(i)&datematch<monthlydate(i+1));
            monthlyindex{i}=k;
        end
    end

    for i=2:length(monthlyindex)
        data(i-1,1)=(monthlydate(i-1)+monthlydate(i))/2;%date
        data(i-1,2)=sum(countmatch(monthlyindex{i}));%total match
        data(i-1,3)=sum(countmax(monthlyindex{i}));%total data
    end

    figure
    bar(data(:,1),[data(:,2) data(:,3)-data(:,2)],'stacked')
    for i=1:length(data)
        text(data(i,1),data(i,3),sprintf('%.1f%%',data(i,2)./data(i,3)*100),'vert','bottom','horiz','center'); 
    end
    box off
    title('monthly stratified BRIGHT hotstpot matches')
    datetick('x')
    oldxtick=xticks;
    xticks(oldxtick-15)
    legend('matching','notmatching','location','northwest')

    return
    figure
    plot(datematch,countmatch)
    hold on
    plot(datematch,countmax)
    title('temporal distribution of FIREWATCH and BRIGHT hotstpot matches')
    datetick('x')

    for i=1:length(matching)
        countmatch(i)=matching{i}.count;
        datematch(i)=matching{i}.date;
    end

    figure
    plot(datematch,countmatch)
    title('temporal distribution of FIREWATCH and BRIGHT hotstpot matches')
    datetick('x')
end
%% %plotting spatial and temporal distribution of FWT
if 1
    clc;clear;
    load matching_FWT
    load unmatching_FWT
    figure
    load coast_i_aus.mat
    plot(long,lat)
    hold on
    plot(matchingtotal_FWT(:,2),matchingtotal_FWT(:,3),'x')
    ratiofix
    title('spatial distribution of FIREWATCH and BRIGHT hotstpot matches')

    % create counting variable
    if ~exist('countmatch_exact_FWT.mat')
        counter=1;
        h=waitbar(0,'pleasewait');
        for i=1:length(dataFWT_epoch)
            waitbar(i/length(dataFWT_epoch),h,sprintf('counting match percentage\n%.2f%%',i/length(dataFWT_epoch)))  
            if sum(dataFWT_epoch{i}.matches)==0
                ukuran=size(dataFWT_epoch{i}.matches);
                countmax(counter)=ukuran(1);
                countmatch(counter)=sum(dataFWT_epoch{i}.matches);
                datematch(counter)=dataFWT_epoch{i}.epoch;
                counter=counter+1;
            else
                ukuran=size(dataFWT_epoch{i}.matches);
                countmax(counter)=ukuran(1);
                countmatch(counter)=sum(dataFWT_epoch{i}.matches);
                datematch(counter)=dataFWT_epoch{i}.epoch;
                counter=counter+1;
            end
        end
        close(h)
        save countmatch_exact_FWT countmax countmatch datematch
    else
        load countmatch_exact_FWT.mat
    end

    %aggregate per month
    %setting month
    monthlydate=datenum(2019,3:15,1);
    for i=1:length(monthlydate)
        if i==length(monthlydate)
            k=find(datematch>=monthlydate(i));
            monthlyindex{i}=k;
        else
            k=find(datematch>=monthlydate(i)&datematch<monthlydate(i+1));
            monthlyindex{i}=k;
        end
    end

    for i=2:length(monthlyindex)
        data(i-1,1)=(monthlydate(i-1)+monthlydate(i))/2;%date
        data(i-1,2)=sum(countmatch(monthlyindex{i}));%total match
        data(i-1,3)=sum(countmax(monthlyindex{i}));%total data
    end

    figure
    bar(data(:,1),[data(:,2) data(:,3)-data(:,2)],'stacked')
    for i=1:length(data)
        text(data(i,1),data(i,3),sprintf('%.1f%%',data(i,2)./data(i,3)*100),'vert','bottom','horiz','center'); 
    end
    box off
    title('monthly stratified FIREWATCH hotstpot matches')
    datetick('x')
    oldxtick=xticks;
    xticks(oldxtick-15)
    legend('matching','notmatching','location','northwest')

    return
    figure
    plot(datematch,countmatch)
    hold on
    plot(datematch,countmax)
    title('temporal distribution of FIREWATCH and BRIGHT hotstpot matches')
    datetick('x')

    for i=1:length(matching)
        countmatch(i)=matching{i}.count;
        datematch(i)=matching{i}.date;
    end

    figure
    plot(datematch,countmatch)
    title('temporal distribution of FIREWATCH and BRIGHT hotstpot matches')
    datetick('x')
end