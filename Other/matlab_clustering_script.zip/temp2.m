clc;clear;
%load data
if ~exist('FSA.mat')
    FSA=load('..\clustering_AHIFSA\matfile\AHIFSA_aus_clean.mat');
    save FSA FSA
else
    load('FSA.mat')
end
if ~exist('FWT.mat')
    FWT=load('..\clustering_FIREWATCH\matfile\FIREWATCH_aus_clean.mat');
    save FWT FWT
else
    load('FWT.mat')
end

timemin=-11; %in hour
FWT.hs_time=FWT.hs_time+datenum([0 0 0 timemin 0 0]);

load coast_i_aus.mat
figure
plot(long,lat,'-k')
hold on
cmap=distinguishable_colors(4);
h3=plot(FSA.hs_long,FSA.hs_lat,'^','Color',cmap(3,:));
h4=plot(FWT.hs_long,FWT.hs_lat,'^','Color',cmap(4,:));


legend([h3,h4],{'RMIT ','Firewatch'})
title(sprintf('Hotspot RMIT vs Firewatch'))
set(gca,'FontSize',12)
xlim([150.14 150.26])
ylim([-30.44 -30.34])
ratiofix
return

