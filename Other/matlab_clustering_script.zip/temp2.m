figure
load coast_i_aus
hold on

for i=1:length(superclusterUTM)
    plot(superclusterUTM{i}.circle,'HoleEdgeAlpha',0.1,'FaceAlpha',0.4)
    [x,y]=centroid(superclusterUTM{i}.circle);
    text(x,y,sprintf('%i',i))
end

%xlim([117.94748836483 120.526373263382])
%ylim([-33.7006864104863 -31.6948870449454])
