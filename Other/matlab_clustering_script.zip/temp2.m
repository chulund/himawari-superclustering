counterNumHS=0;
for i=1:length(supercluster)
    if strcmp(supercluster{i}.id,'SC')
       for j=1:length(supercluster{i}.hs_datas)
          
           counterNumHS=counterNumHS+length(supercluster{i}.hs_datas{j}.hs_long);
       end
    else
        counterNumHS=counterNumHS+length(supercluster{i}.hs_data.hs_long);
    end
end
return
counter=1;
for i=1:length(supercluster)
     if sum(isnan(supercluster{i}.circle.Vertices(:,1)))>0
         counter=counter+1;
         i
     end
end