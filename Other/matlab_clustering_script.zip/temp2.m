clc;clear;
load matching
figure
load coast_i_aus.mat
plot(long,lat)
hold on
plot(matchingtotal(:,2),matchingtotal(:,3),'x')
ratiofix
title('spatial distribution of FIREWATCH and BRIGHT hotstpot matches')

for i=1:length(matching)
    countmatch(i)=matching{i}.count;
    datematch(i)=matching{i}.date;
end

figure
plot(datematch,countmatch)
title('temporal distribution of FIREWATCH and BRIGHT hotstpot matches')
datetick('x')