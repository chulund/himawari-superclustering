%deletethis
sortedmat=sortrows(nomatch_negative,4);
counter=1;counter2=1;clear saved;
for i=1:length(sortedmat)-1
    if (sortedmat(i+1,4)-sortedmat(i,4))<=0.0416666666666667
        saved{counter}(counter2)=i;
        saved{counter}(counter2+1)=i+1;
        counter2=counter2+2;
        dothis=1;
    else
        if dothis
            counter2=1;
            saved{counter}=unique(saved{counter});
            counter=counter+1;
            dothis=0;
        end
    end
end

for i=1:length(saved)
    lengthsaved(i)=length(saved{i});
end

sortedlengthsaved=sort(lengthsaved,'descend');

% find the top 5 clusters
counter=1;
for i=1:5
    fprintf('\ncase number %i\n',i)
    k=find(lengthsaved==sortedlengthsaved(i));
    temp=sortedmat(saved{k},4);
    temp2=sortedmat(saved{k},5);
    for j=1:length(temp)
        plotthis(counter,1)=temp(j);
        plotthis(counter,2)=i;
        plotthis(counter,3)=temp2(j);
        counter=counter+1;
    end
end
