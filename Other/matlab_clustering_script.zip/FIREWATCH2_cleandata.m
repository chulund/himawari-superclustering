%script to clean FIREWATCH data and cut the data for 2 or more MATFILEs
clc;clear;  
% Data readme
%    WKT,ID,Longitude,Latitude,Descriptio,Satellite,Orbit,Time,Date,SatZenith,Confidence,Intensity,Location
%

%load cleaned data
if ~exist('matfile/FIREWATCH_all_clean.mat')
    fdir=dir('matfile/FIREWATCH0*.mat');
    for i=1:length(fdir)
        load(['matfile/',fdir(i).name])
        %get long lat time
        fprintf('reading file %s\n',fdir(i).name)
        if exist('hs_long','var')
            counter=length(hs_long);
        else
            counter=1;
        end
        for i=1:length(data)
            if ~isempty(data{i,3})&&~isempty(data{i,4})     
                hs_long(counter)=str2double(data{i,3}(2:end-1));
                hs_lat(counter) =str2double(data{i,4}(2:end-1));
                hs_temp(counter) =str2double(data{i,12}(2:end-1));
                time=strsplit(data{i,8},':');
                date = sprintf('%i',str2double(data{i,9}(2:end-1)));
                hs_time(counter) =datenum(str2double(date(1:4)),str2double(date(5:6)),str2double(date(7:8)),str2double(time{1}),str2double(time{2}),0) ...
                    - datenum([0 0 0 8 0 0]); %plus 8 hour time to convert to UTC
                counter=counter+1;
            end
        end
    end
    save matfile/FIREWATCH_all_clean hs_long hs_lat hs_time hs_temp
else
    load('matfile/FIREWATCH_all_clean.mat')
end

%cut data to only australia
k=find(hs_lat>-11);
hs_long(k)=[];hs_lat(k)=[];hs_time(k)=[];hs_temp(k)=[];
save matfile/FIREWATCH_aus_clean hs_long hs_lat hs_temp hs_time 

return

%cut data to only 1 phenomenon
save4cut=[];
for i=1:length(hs_long)
    if (hs_lat(i)<-34)|(hs_lat(i)>-32)|(hs_long(i)<118.5)|(hs_long(i)>120.5)
        save4cut=[save4cut;i];
    end
end
hs_long(save4cut)=[];hs_lat(save4cut)=[];hs_time(save4cut)=[];hs_temp(save4cut)=[];
save matfile/FIREWATCH_aus_clean hs_long hs_lat hs_temp hs_time 
return

