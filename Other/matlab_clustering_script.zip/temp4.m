%comparing sensitivity between bright and 
clc;clear;
load unmatching
load dataFWT_epoch

%

%find unique 
for i=1:length(dataBRI_epoch)
    epokBRI(i,1)=dataBRI_epoch{i}.epoch;
end
counter=1;
for i=1:length(dataFWT_epoch)
    epokFWT(i,1)=dataFWT_epoch{i}.epoch;
    if ~(sum(epokBRI==dataFWT_epoch{i}.epoch)==1)
        noFWT(counter)=i;
        counter=counter+1;
    end
end

for i=1:length(dataBRI_epoch)
    anu(i,1)=sum(dataBRI_epoch{i}.matches);
    
    
    k=find(dataBRI_epoch{i}.epoch==epokFWT);
    if ~isempty(k)
        ukuran1=size(dataFWT_epoch{k}.data);
        anu(i,2)=ukuran1(1);
    else
        anu(i,2)=0;
    end
    
    ukuran2=size(dataBRI_epoch{i}.data);    
    anu(i,3)=ukuran2(1);
end

difference=anu(:,3)-anu(:,2);
(log10(difference))
set(gca,'YScale','log')
