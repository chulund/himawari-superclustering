%script to load BRIGHT hotspot (12 file)
clc;clear;
location='D:\Research\2020\Hotspot\persistence\data\BRIGHT\yearly';
fdir=dir([location,'\YEARLYDATA*']);
for i=12:length(fdir)
    filename=fdir(i).name;
    fid=fopen([location,'\',filename],'r');
    %line=fgetl(fid); %skip 1st line (header)
    fprintf('reading file %s\n',filename)
    counter=1;
    while ~feof(fid)
        line=fgetl(fid);
        linesplit=strsplit(line,',','CollapseDelimiters', false);
        for j=1:8
            data{counter,j}=linesplit{j};
        end
        counter=counter+1;
    end
    fclose(fid);
    save(sprintf('matfile/BRIGHT_all_%02i.mat',i),'data');
end