    clc;clear;
load dataFSA
load dataFWT


load coast_i_aus.mat
figure
plot(long,lat,'-k')
hold on
cmap=distinguishable_colors(4);
go=.1;
h1=plot(dataFSA.hs_long,dataFSA.hs_lat,'X','Color',cmap(2,:),'MarkerFaceColor',cmap(2,:),'MarkerSize',15);
%h3=plot(round(dataFSA.hs_longT,2)+0.01,round(dataFSA.hs_latT,2)+0.01,'^','Color',cmap(1,:),'MarkerFaceColor',cmap(1,:),'MarkerSize',10);
h3=plot(round(dataFSA.hs_longT,2),round(dataFSA.hs_latT,2),'^','Color',cmap(1,:),'MarkerFaceColor',cmap(1,:),'MarkerSize',10);
%h3=plot(floor(dataFSA.hs_longT*100)/100,floor(dataFSA.hs_latT*100)/100,'^','Color',cmap(1,:),'MarkerFaceColor',cmap(1,:),'MarkerSize',10);
%h3=plot(ceil(dataFSA.hs_longT*100)/100,ceil(dataFSA.hs_latT*100)/100,'^','Color',cmap(1,:),'MarkerFaceColor',cmap(1,:),'MarkerSize',10);
h2=plot(dataFWT.hs_long,dataFWT.hs_lat,'o','Color',[go go go],'MarkerFaceColor',cmap(3,:),'MarkerSize',7);
%plot state boundary
load stateboundary
h4=plot(bnd_long,bnd_lat,'-r');
title(sprintf('RMIT and FIREWATCH Comparison %s',dataFSA.date),'FontSize',15)
legend([h1,h3,h2],{'RMIT','RMIT Transformed','Firewatch'})
xlim([min(dataFSA.hs_long)-3 max(dataFSA.hs_long)+3])
ylim([min(dataFSA.hs_lat)-3 max(dataFSA.hs_lat)+3])

set(gcf, 'Position', get(0, 'Screensize'));
ratiofix
%saveas(gcf,'RMIT_FIREWATCH_all.png')