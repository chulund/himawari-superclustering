% comparison using chermelle method
clc;clear;

%load aus clean data
if ~exist('BRI.mat')
    BRI=load('BRIGHT_aus_clean.mat');
    save BRI BRI
else
    load('BRI.mat')
end
if ~exist('FWT.mat')
    FWT=load('FIREWATCH_aus_clean.mat');
    save FWT FWT
else
    load('FWT.mat')
end

%specify date to compare
date2comp='11-Apr-2019';
fprintf('date2compare = %s\n',date2comp);
%get the data
k=find(floor(BRI.hs_time)==datenum(date2comp));
dataBRIGHT.hs_long=BRI.hs_long(k);
dataBRIGHT.hs_lat=BRI.hs_lat(k);
dataBRIGHT.hs_time=BRI.hs_time(k);
dataBRIGHT.hs_x=BRI.hs_x(k);
dataBRIGHT.hs_y=BRI.hs_y(k);

k=find(floor(FWT.hs_time)==datenum(date2comp));
dataFWT.hs_long=FWT.hs_long(k);
dataFWT.hs_lat=FWT.hs_lat(k);
dataFWT.hs_time=FWT.hs_time(k);

for i=1:length(dataBRIGHT)
	dataFWT
end