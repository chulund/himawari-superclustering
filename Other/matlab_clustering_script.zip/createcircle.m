%createcircle function
%nur(2/3/2020)

%compute circle coordinate (long,lat) on earth given
%long lat center and radius in km

%input:
%long = longitude (in decimal degrees)
%lat = latitude (in decimal degrees)
%radius = circle radius (in meters)
%cty = circularity (roundness) default is pi/50

function [xout,yout] = createcircle(long,lat,radius,cty)
%give default circularity
if nargin==3
    cty = pi/50;
end
%convert radius to radian
R = 6378137; %earth radius in m
r = radius/R;
%calculate circle coordinates
th = 0:cty:2*pi;
xv = r * cos(th) + deg2rad(long);
yv = r * sin(th) + deg2rad(lat);
xout = rad2deg(xv);
yout = rad2deg(yv);
end