%analysis Firewatch unmatch

clc;clear
load matching_FWT.mat
load unmatching_FWT.mat
load matching_BRI.mat
load unmatching_BRI.mat

if ~exist('count_nomatch_FWT.mat')
    for i=1:length(dataBRI_epoch)
        uniqueBRI(i)=dataBRI_epoch{i}.epoch;
    end
    uniqueBRI=datenum(datestr(uniqueBRI));
    %count matchingcount
    counter=1;
    for i=1:length(dataFWT_epoch)
        %number of matches col 1
        count_nomatch(i,1)=sum(dataFWT_epoch{i}.matches);
        %number of firewatch at that epoch col 2
        ukuran=size(dataFWT_epoch{i}.data);
        count_nomatch(i,2)=ukuran(1);
        k=find(datenum(datestr(dataFWT_epoch{i}.epoch))==uniqueBRI);
        if isempty(k)
            count_nomatch(i,3)=0;
            counter=counter+1;
        else
            %number of bright at that epoch col 3
            ukuran2=size(dataBRI_epoch{k}.data);
            count_nomatch(i,3)=ukuran2(1);
        end
        %the epoch col 4
        count_nomatch(i,4)=dataFWT_epoch{i}.epoch;    
    end
    %number of unmatch col 5
    count_nomatch(:,5)=count_nomatch(:,3)-count_nomatch(:,2);
    count_nomatch=sortrows(count_nomatch,5);
    save count_nomatch_FWT count_nomatch
else
    load count_nomatch_FWT
end

maksimum=count_nomatch(1,5);
k=find(count_nomatch(:,5)==maksimum);
fprintf('maximum number of non match is %i, which happen at %s\n',maksimum, datestr(count_nomatch(k,4)))
count_nomatch(k,4);

% check for monthly no match distribution
monthly_i=(datestr(count_nomatch(:,4),'mm'));
for i=1:length(monthly_i)
    monthly_index(i)=double(convertCharsToStrings(monthly_i(i,:)));
end
% col 6
count_nomatch(:,6)=monthly_index;

% check for hourly no match distribution
hourly_i=(datestr(count_nomatch(:,4)+datenum([0 0 0 9 0 0]),'HH'));%plus 9 hour = local time
for i=1:length(hourly_i)
    hourly_index(i)=double(convertCharsToStrings(hourly_i(i,:)));
end
% col 7
count_nomatch(:,7)=hourly_index;

k=find(count_nomatch(:,5)<0);
nomatch_negative=count_nomatch(k,:);

k=find(~nomatch_negative(:,3)==0);
nomatch_negative=nomatch_negative(k,:);

%summary by month
[a,~,c] = unique(nomatch_negative(:,6));
AvgCost1 = [a accumarray(c,1) accumarray(c,nomatch_negative(:,5))]

%summary by hour
[a,~,c] = unique(nomatch_negative(:,7));
AvgCost2 = [a accumarray(c,1) accumarray(c,nomatch_negative(:,5))]

save nomatch_negative_FWT nomatch_negative

if 0
    %write analysis data to file
    fid=fopen('txtout/matching_number.txt','w')
    h=waitbar(0,'pleasewait');
    fprintf(fid,'number of FIREWATCH with associated BRIGHT, number of FIREWATCH no associated BRIGHT, number of total BRIGHT, number of total FIREWATCH, epoch\n')
    for i=1:length(count_nomatch)
        waitbar(i/length(count_nomatch),h,sprintf('matching number.txt %.2f%%',i*100/length(count_nomatch)))
        fprintf(fid,'%i,%i,%i,%i,%s\n',count_nomatch(i,5),count_nomatch(i,1),count_nomatch(i,2),count_nomatch(i,3),datestr(count_nomatch(i,4),'dd/mmm/yyyy HH:MM:SS'));
    end
    fclose(fid)
    close(h)
end


%sort by time of occurence and duration
%deletethis
sortedmat=sortrows(nomatch_negative,4);
counter=1;counter2=1;clear saved;
for i=1:length(sortedmat)-1
    if (sortedmat(i+1,4)-sortedmat(i,4))<=0.0416666666666667
        saved{counter}(counter2)=i;
        saved{counter}(counter2+1)=i+1;
        counter2=counter2+2;
        dothis=1;
    else
        if dothis
            counter2=1;
            saved{counter}=unique(saved{counter});
            counter=counter+1;
            dothis=0;
        end
    end
end

for i=1:length(saved)
    lengthsaved(i)=length(saved{i});
end

sortedlengthsaved=sort(lengthsaved,'descend');

% find the top 5 clusters
counter=1;
for i=1:5
    fprintf('\ncase number %i\n',i)
    k=find(lengthsaved==sortedlengthsaved(i));
    temp=sortedmat(saved{k},4);
    temp2=sortedmat(saved{k},5);
    for j=1:length(temp)
        plotthis(counter,1)=temp(j);
        plotthis(counter,2)=i;
        plotthis(counter,3)=temp2(j);
        counter=counter+1;
    end
end

%plot it
for i=1:length(dataFWT_epoch)
    anu1(i,1)=sum(dataFWT_epoch{i}.matches);
    anu1(i,2)=dataFWT_epoch{i}.epoch;
end

for i=1:length(dataBRI_epoch)
    anu2(i,1)=sum(dataBRI_epoch{i}.matches);
    anu2(i,2)=dataBRI_epoch{i}.epoch;
end
if 1
    %plot all figure with particular time
    for i=1:length(plotthis)
        k=find((anu1(:,2)==(plotthis(i,1))));
        m=find((anu2(:,2)==datenum(datestr(plotthis(i,1)))));
        
        figure
        load coast_i_aus.mat
        plot(long,lat)
        hold on
        h1=plot(dataFWT_epoch{k}.data(:,1),dataFWT_epoch{k}.data(:,2),'o','MarkerSize',5,'Color','blue');%,'MarkerFaceColor','blue');
        if ~isempty(m)
            h2=plot(dataBRI_epoch{m}.data(:,1),dataBRI_epoch{m}.data(:,2),'x','MarkerSize',7,'Color','red','MarkerFaceColor','red','LineWidth',1.25);
        end
        title(sprintf('CASE %2d - BRIGHT vs FIREWATCH %s',plotthis(i,2),datestr(dataFWT_epoch{k}.epoch,'HH:MM dd-mmm-yyyy')))
        legend([h2,h1],{'BRIGHT','FIREWATCH'})
        ratiofix
        if ~isempty(m)
        %put attribute
            pos = arrayfun(@plotboxpos, gca, 'uni', 0);
            dim = cellfun(@(x) x.*[1 1 0.5 0.5], pos, 'uni',0);
            str = {sprintf('number of FWT - BRI= %i',length(dataFWT_epoch{k}.data(:,1))-length(dataBRI_epoch{m}.data(:,1))),
                sprintf('number of BRI = %i',length(dataBRI_epoch{m}.data(:,1))),
                sprintf('number of FWT = %i',length(dataFWT_epoch{k}.data(:,1))),
                sprintf('matches = %i (%.2f%%) of BRI',anu2(m,1),anu2(m,1)*100/length(dataBRI_epoch{m}.data(:,1)))}
            annotation('textbox',dim{1},'String',str,'FitBoxToText','on','vert','bottom','EdgeColor','none')
        end
        saveas(gcf,sprintf('figures/nomatch_spatial_cases/CASE%2d_%04d.png',plotthis(i,2),i));
        close(gcf)
    end
end
