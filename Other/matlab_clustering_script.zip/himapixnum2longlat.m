%function to read pixel number of himawari and outputting transformed
%long lat
%can batch process
%nur - 13 May 2020
%
%usage
%[long,lat]=himapixnum2longlat(hx,hy)
%
%input:
%hx = himawari row x
%hy = himawari column y
%
%output:
%long: longitude in GDA94
%lat:latitude in GD94

function [long_out,lat_out]=himapixnum2longlat(hx,hy)
%load lookuptable data
load('D:\Research\2020\Hotspot\persistence\compare2\nativeVSnearest\gdal\lookuptable.mat');

long_out=zeros(size(hx));
lat_out=zeros(size(hy));
for i=1:length(hx)
    k1=find(A1(:,:,1)==hx(i)); %find occurences in row
    k2=find(A2(:,:,1)==hy(i)); %find occurences in col
    [k,~,~]=intersect(k1,k2); %find intersection in occ.
    if ~isempty(k)
        [I,J]=ind2sub(size(A1),k); %convert found indices into matrix index
        long_out(i)=lon(I,J);
        lat_out(i)=lat(I,J);
    else
        long_out(i)=NaN;
        lat_out(i)=NaN;
    end
end
end