%function to read pixel number of himawari and outputting transformed
%long lat
%can batch process
%nur - 13 May 2020
%update 16 August 2020
%
%usage
%[long,lat]=himapixnum2longlat(hx,hy)
%
%input:
%hx = himawari row x
%hy = himawari column y
%
%output:
%long: longitude in GDA94
%lat:latitude in GD94

function [long_out,lat_out]=himapixnum2longlat(hx,hy)
%load lookuptable data
load('D:\Research\2020\Hotspot\persistence\compare2\nativeVSnearest\gdal\lookuptable.mat');
h=waitbar(0,'please wait');
long_out=zeros(size(hx));
lat_out=zeros(size(hy));
counter=1;
doubleInc=0;
for i=1:length(hx)
    waitbar(i/length(hx),h,sprintf('%.2f%%',i*100/length(hx)));
    k1=find(A1(:,:,1)==hx(i)); %find occurences in row
    k2=find(A2(:,:,1)==hy(i)); %find occurences in col
    [k,~,~]=intersect(k1,k2); %find intersection in occ.
    if ~isempty(k)
        [I,J]=ind2sub(size(A1),k); %convert found indices into matrix index
        if length(I)>1
            doubleInc=doubleInc+1;
        end
        for z=1:length(I)
            long_out(counter)=lon(I(z),J(z));
            lat_out(counter)=lat(I(z),J(z));
            counter=counter+1;
        end
    else
        long_out(counter)=NaN;
        lat_out(counter)=NaN;
        counter=counter+1;
    end
end
close(h)

end