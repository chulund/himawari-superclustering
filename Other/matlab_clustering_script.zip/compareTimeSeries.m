%comparetimeS1eries
clc;clear;fclose('all');close('all');
FSA=load('../clustering_AHIFSA/matfile/AHIFSA_aus_daily.mat');
FWT=load('../clustering_FIREWATCH/matfile/FIREWATCH_aus_daily.mat');
day1=8;%for FSA
day2=9; %for FWT

timeS1=FSA.dailydata{day1}.hs_time;
minimumT=min(timeS1);
maximumT=max(timeS1);
fullT1=minimumT:1/8:maximumT+1; %4 hourly 
sumari1=tabulate(timeS1);
simpan=zeros(length(fullT1));

for i=1:length(fullT1)
    k=find(fullT1(i)==sumari1(:,1));
    if ~isempty(k);
        simpan(i,1)=i;
    end
end
fullT1(find(simpan))=[];

data1(:,1)=[fullT1';sumari1(:,1)];
data1(:,2)=[zeros(length(fullT1),1);sumari1(:,2)];
data1=sortrows(data1,1);

timeS2=FWT.dailydata{day2}.hs_time;
minimumT=min(timeS2);
maximumT=max(timeS2);
fullT2=minimumT:1/8:maximumT+1; %4 hourly 
sumari2=tabulate(timeS2);
simpan=zeros(length(fullT2));

for i=1:length(fullT2)
    k=find(fullT2(i)==sumari2(:,1));
    if ~isempty(k);
        simpan(i)=i;
    end
end
fullT2(find(simpan))=[];

data2(:,1)=[fullT2';sumari2(:,1)];
data2(:,2)=[zeros(length(fullT2),1);sumari2(:,2)];
data2=sortrows(data2,1);

figure
plot(data1(:,1),data1(:,2),'-b')
hold on
plot(data2(:,1),data2(:,2),'-r')
xlim([min(timeS1)-datenum([0 0 0 1 0 0]) max(timeS1)+datenum([0 0 0 1 0 0])])
title('Hotspot Time Series for 8 November 2019')
datetick('x','keeplimits')
ylabel('number of hotspot')
hold on
xlabel('time')
legend('RMIT (UTC)','FIREWATCH (???)')

%close('all')
figure
fireTime1=datenum([2019 11 8 10 50 0]);
fireTime2=datenum([2019 11 8 10 50 0]);
load coast_i_aus
plot(long,lat)
hold on
k1=find(FSA.dailydata{day1}.hs_time==fireTime1);
k2=find(FWT.dailydata{day2}.hs_time==fireTime2);
h1=plot(FSA.dailydata{day1}.hs_long(k1),FSA.dailydata{day1}.hs_lat(k1),'.r');
h2=plot(FWT.dailydata{day2}.hs_long(k2),FWT.dailydata{day2}.hs_lat(k2),'.b');
title(sprintf('Fire %s UTC',datestr(fireTime1)))
legend([h1 h2],{'RMIT','FIREWATCH'})
k3=FSA.dailydata{day1}.hs_time(FSA.dailydata{day1}.hs_long(k1)>151 & FSA.dailydata{day1}.hs_long(k1)<154 & FSA.dailydata{day1}.hs_lat(k1)>-32.5 & FSA.dailydata{day1}.hs_lat(k1) <-27.5);
k4=FWT.dailydata{day2}.hs_time(FWT.dailydata{day2}.hs_long(k2)>151 & FWT.dailydata{day2}.hs_long(k2)<154 & FWT.dailydata{day2}.hs_lat(k2)>-32.5 & FWT.dailydata{day2}.hs_lat(k2) <-27.5);
ylim([-32.5 -27.5])
xlim([151 154])
ratiofix
fprintf('RMIT hotspot %i\n',length(k3))
fprintf('FIREWATCH hotspot %i\n',length(k4))