% download AHI data from DEA
clc;clear;
outfolder='data/AHIDEA2/';
if ~exist(outfolder)
    mkdir(outfolder)
end

%minimum date available 01 February 2020
%maximum date available yesterday
%https://ga-sentinel.s3-ap-southeast-2.amazonaws.com/L3/hotspots/AHI/SRSS/2020-02-01/AHI20200201T235000Zhotspots.txt
%https://ga-sentinel.s3-ap-southeast-2.amazonaws.com/L3/hotspots/AHI/SRSS/2020-02-02/AHI20200202T000000Zhotspots.txt

datemin=[2019 11 01];
datemax=[2019 11 02]; 


%processing start
datenumST=datenum(datemin);
datenumED=datenum(datemax);
datenumTO=datenumST:datenumED;

for i=1:length(datenumTO)
    %urlbase='https://ga-sentinel.s3-ap-southeast-2.amazonaws.com/L3/hotspots/AHI/SRSS/';
    urlbase='https://dea-public-data.s3-ap-southeast-2.amazonaws.com/L3/hotspots/AHI/SRSS/';
    dateToday= datevec(datenumTO(i));
    
    %download for each 10 minutes
    timeStart=datenumTO(i);
    timeEnds=datenumTO(i)+datenum([0 0 0 23 50 0]);
    timeTotal=linspace(timeStart,timeEnds,144);
    for j=1:length(timeTotal)
        dT=datevec(timeTotal(j));
        frmt1=datestr(timeTotal(j),'YYYY-mm-DD');
        frmt2=datestr(timeTotal(j),'YYYYmmDD');
        frmt3=datestr(timeTotal(j),'HHMMSS');
        url2dwl=sprintf('%s%s/AHI%sT%sZhotspots.txt',urlbase,frmt1,frmt2,frmt3);
        filename=sprintf('%sAHI%sT%sZhotspots.txt',outfolder,frmt2,frmt3);
        fprintf('downloading %s\n',filename);   
        try
            websave(filename,url2dwl);
        catch
            delete(filename);
            continue
        end
        
    end
    
end