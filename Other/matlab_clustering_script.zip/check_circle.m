clc;clear
%create circle
r=2;
x=0;
y=0;
th = 0:pi/50:2*pi;
xv = r * cos(th) + x;
yv = r * sin(th) + y;
plot(xv, yv);

%define point
rng default
xq = randn(250,1);
yq = randn(250,1);

[in,on] = inpolygon(xq,yq,xv,yv);

figure

plot(xv,yv) % polygon
axis equal

hold on
plot(xq(in),yq(in),'r+') % points inside
plot(xq(~in),yq(~in),'bo') % points outside
hold off