clc;clear;
load matfile/dailydata dailydata

h1 = waitbar(0,'I waitbar Please wait...');
for i=1:length(dailydata)
    dailycluster{i}.date=dailydata{i}.date;
    h2=waitbar(0,'J waitbar Please wait...');
    pos_w1=get(h1,'position');
    pos_w2=[pos_w1(1) pos_w1(2)+pos_w1(4) pos_w1(3) pos_w1(4)];
    set(h2,'position',pos_w2,'doublebuffer','on')
    waitbar(i/length(dailydata),h1,sprintf('first waitbar %.2f%%',i/length(dailydata)*100))
    for j=1:length(dailydata{i}.clusterdata)
        waitbar(j/length(dailydata{i}.clusterdata),h2,sprintf('%.2f%%',j/length(dailydata{i}.clusterdata)*100))
        dailycluster{i}.clusterdata{j}.id=dailydata{i}.clusterdata{j}.id;
        dailycluster{i}.clusterdata{j}.polyshape=polyshape([dailydata{i}.clusterdata{j}.long' dailydata{i}.clusterdata{j}.lat']);
        dailycluster{i}.clusterdata{j}.startend=[datenum(dailydata{i}.date) datenum(dailydata{i}.date)];
    end
    close(h2)
end
close(h1)

save matfile/dailycluster dailycluster