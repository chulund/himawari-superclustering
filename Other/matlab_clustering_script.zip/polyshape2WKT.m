%function to convert polyshape to WKT polygon
%shapes=supercluster{1}.circle;
function S=polyshape2WKT(shapes)
%beginning
S=sprintf('Polygon((');
%define if polygon have hole
if sum(isnan(shapes.Vertices(:,1)))>0 %polygon have hole
    ktemp=find(isnan(shapes.Vertices(:,1)));
    %decide the outer rings
    k(1)=1;k(2:length(ktemp)+1)=ktemp;
    k(length(k)+1)=length(shapes.Vertices);
    verticenumber=diff(k);
    %find polygon with max number of vertices
    kstart=k(find(verticenumber==max(verticenumber)));
    kend=k(find(verticenumber==max(verticenumber))+1);
    %check if it is at the start or end 
    if ~(kstart==1)
        kstart=kstart+1;
    end
    if ~(kend==k(end))
        kend=kend-1;
    end
    for i=kstart:kend
        S=sprintf('%s%f %f,',S,shapes.Vertices(i,:));
    end
else %polygon doesn't have holes, proceed as usual
    for i=1:length(shapes.Vertices)
        S=sprintf('%s%f %f,',S,shapes.Vertices(i,:));
    end
end
%remove comma from the last point
S=S(1:end-1);
%ending
S=sprintf('%s))',S);

end