%transform BRIGHT coordinates from HX HY to LONG LAT old version (slow)
clc;clear;
%load aus clean data
if ~exist('BRI.mat')
    BRI=load('BRIGHT_aus_clean.mat');
    save BRI BRI
else
    load('BRI.mat')
end

counter=0;
for i=38%2:38
    fprintf('processing number %2i out of 39\n',i)
    %get the data
    if ~(i==38)
        k=((100000*i)+1):((i+1)*100000);
    else
        k=((100000*i)+1):length(BRI.hs_long);
    end
    dataBRIGHT.hs_long=BRI.hs_long(k);
    dataBRIGHT.hs_lat=BRI.hs_lat(k);
    dataBRIGHT.hs_time=BRI.hs_time(k);
    dataBRIGHT.hs_x=BRI.hs_x(k);
    dataBRIGHT.hs_y=BRI.hs_y(k);
    
    %convert hx hy pixel number to long lat
    hx=dataBRIGHT.hs_x+1; %add 1 pixel to the right
    hy=dataBRIGHT.hs_y+1;%add 1 pixel to the bottom
    [long_out,lat_out]=himapixnum2longlat(hx,hy);
    dataBRIGHT.hs_longT=long_out;
    dataBRIGHT.hs_latT=lat_out;
    
    save(sprintf('fileout/BRIGHT%2i',i),'dataBRIGHT')
end