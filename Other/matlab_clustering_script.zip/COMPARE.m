clc;clear
%COMPARE FWT and SRSS
FWT=load('FIREWATCH_clean.mat');
SRS=load('SRSS_clean.mat');

figure
load coast_i_aus.mat
plot(long,lat)
hold on
h1=plot(FWT.hs_long,FWT.hs_lat,'.b');
h2=plot(SRS.hs_long,SRS.hs_lat,'xr');
ratiofix
legend([h1,h2],{'FIREWATC','SRSS'})
title ('FIREWATCH vs SRSS 1 May 2019','FontSize',30)