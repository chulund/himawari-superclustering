%persistence AHIDEA
clc;clear;
load('AHIDEA.mat')
tic
% Data readme
%    latitude,longitude,temp_k,Sh,Sl,power,confidence,datetime,offset
%
%% spatio temporal cluster daily

%search radius in m
radius=3500;

%timing threshold in minutes
timeThres=0;

%plot the data?
plotData=0;

%load cleaned data
if ~exist('AHIDEA_clean.mat')
    %get long lat time
    for i=1:length(data)
        hs_id(i)=i;
        hs_long(i)=str2double(data{i,2});
        hs_lat(i) =str2double(data{i,1});
        timestr = sprintf('%i',str2double(data{i,8}(1:end-1)));
        hs_time(i) =datenum(str2num(timestr(1:4)),str2num(timestr(5:6)),str2num(timestr(7:8)),str2num(timestr(9:10)),str2num(timestr(11:12)),0);
        temp_k(i)=str2double(data{i,1});
    end
    save AHIDEA_clean hs_long hs_lat hs_time
else
    load('AHIDEA_clean.mat')
end

        figure
        load coast_i
        plot(long,lat)
        hold on
        plot(hs_long,hs_lat,'xr')
        if abs(max(hs_long)-min(hs_long))>abs(max(hs_lat)-min(hs_lat))
            range=(max(hs_long)-min(hs_long));
        else
            range=(max(hs_lat)-min(hs_lat));
        end
        xlim([mean(hs_long)-range*.2 mean(hs_long)+range*.2])
        ylim([mean(hs_lat)-range*.2 mean(hs_lat)+range*.2])
        %xlim([min(hs_long)-(max(hs_long)-min(hs_long))*.2 max(hs_long)+(max(hs_long)-min(hs_long))*.2])
        %ylim([min(hs_lat)-(max(hs_lat)-min(hs_lat))*.2 max(hs_lat)+(max(hs_lat)-min(hs_lat))*.2])
        title(sprintf('Himawari Hotspot DEA %s',datestr(floor(hs_time(1))))) 
        
        %for i=1:length(hs_long)
        %    text(hs_long(i)-0.01,hs_lat(i)-0.01,sprintf('%i',i));
        %end
return
%cut data to only eastern australia
save4cut=[];
for i=1:length(hs_long)
    if (hs_long(i)<135)||(hs_lat(i)>-11)
        save4cut=[save4cut;i];
    end
end
hs_long(save4cut)=[];hs_lat(save4cut)=[];hs_time(save4cut)=[];

%doing the process daily
days=floor(min(hs_time)):floor(max(hs_time));

%load daily data
if ~exist('AHIDEA_daily.mat')
    %separate data by date
    for i=1:length(days)
        today=find(~(floor(hs_time)-days(i)));
        dailydata{i}.hs_long=hs_long(today);
        dailydata{i}.hs_lat=hs_lat(today);
        dailydata{i}.hs_time=hs_time(today);
    end
    save AHIDEA_daily dailydata
else
    load('AHIDEA_daily.mat')
end

for k=1:length(dailydata)    
    
    %take todays data
    hs_long=dailydata{k}.hs_long;
    hs_lat=dailydata{k}.hs_lat;
    hs_time=dailydata{k}.hs_time;
    
    if isempty(hs_long)
        continue
    end
    fprintf('processing date %s\n',datestr(floor(hs_time(1))))
    
    %plotting
    if plotData
        figure
        fprintf('     1.plotting\n')
        load coast_i
        plot(long,lat)
        hold on
        plot(hs_long,hs_lat,'xr')
        if abs(max(hs_long)-min(hs_long))>abs(max(hs_lat)-min(hs_lat))
            range=(max(hs_long)-min(hs_long));
        else
            range=(max(hs_lat)-min(hs_lat));
        end
        xlim([mean(hs_long)-range*.2 mean(hs_long)+range*.2])
        ylim([mean(hs_lat)-range*.2 mean(hs_lat)+range*.2])
        %xlim([min(hs_long)-(max(hs_long)-min(hs_long))*.2 max(hs_long)+(max(hs_long)-min(hs_long))*.2])
        %ylim([min(hs_lat)-(max(hs_lat)-min(hs_lat))*.2 max(hs_lat)+(max(hs_lat)-min(hs_lat))*.2])
        title(sprintf('Himawari Hotspot DEA %s',datestr(floor(hs_time(1))))) 
        
        for i=1:length(hs_long)
            text(hs_long(i)-0.01,hs_lat(i)-0.01,sprintf('%i',i));
        end
    end
    
    cor=[];
    fprintf('     2.creating circle and check inside\n')
    for i=1:length(hs_long)

        %create circle to check radius
        [xv,yv] = createcircle(hs_long(i),hs_lat(i),radius,pi/5);
        
        if plotData
            plot(xv,yv,'-g')
        end

        [in,on] = inpolygon(hs_long,hs_lat,xv,yv);
        %create a corelation matrix
        cor(i,:)=in;
    end

    %update corelation matrix to also consider time difference
    fprintf('     3.considering time difference\n')
    for i=1:length(cor)
        for j=1:length(cor)
            %skip if self correlation
            if i==j
                continue
            end
            %skip if correlation is zero
            if cor(i,j)==0
                continue
            end
            %check if time difference > threshold
            timediff=hs_time(i)-hs_time(j);
            if (timediff*1440)>abs(timeThres)
                cor(i,j)=0; %set correlation to 0
            end
        end
    end

    %spatial clustering
    cor_check=cor;

    counter2=1; % for each cluster
    aggregate=[];
    fprintf('     4.spatial clustering\n')
    for i=1:length(cor_check)
        cor_process=cor_check(i,:);
        if sum(cor_process)==0
            continue
        end
        %remove self correlation
        cor_check(i,i)=0;

        member=[];
        looping=[];
        counter=1;
        member(counter)=i;
        cor_check(i,:)=0;

        index=[];index=find(cor_process);
        if isempty(index)
            aggregate{counter2}=member;
            counter2=counter2+1;
        end

        looping=[looping;index'];
        while ~isempty(looping)

            counter=counter+1;
            member(counter)=looping(1,1);

            index=[];
            index=find(cor_check(looping(1,1),:));        
            if ~isempty(index)
                looping=[looping;index'];
            end
            %remove visited row
            cor_check(looping(1,1),:)=0;
            looping(1)=[];

        end
        aggregate{counter2}=unique(member);
        counter2=counter2+1;

    end

    cluster_HS{k}=aggregate';
end
%save AHIDEA_cluster cluster_HS
toc