%analysis after compare bright firewatch buffer v1 script
if 1
    clc;clear
    
    %select method
    method=1;
    %1.exact matches
    %2.buffering
    
    if (method==1)
        load unmatching_BRI
        load unmatching_FWT
        load matching_BRI
        load matching_FWT
    else
        load unmatching_buffer_BRI
        load unmatching_buffer_FWT
        load matching_buffer_BRI
        load matching_buffer_FWT
    end
    
    if exist('dataBRIcomb.mat')
        load('dataBRIcomb.mat')
    end
    if ~exist('FWT.mat')
        FWT=load('FIREWATCH_aus_clean.mat');
        save FWT FWT
    else
        load('FWT.mat')
    end
    
    %fix BRIGHT + shift half pixel
        dataBRI(:,1)=dataBRIcomb.hs_timeT;
        dataBRI(:,2)=dataBRIcomb.hs_longT+0.01;
        dataBRI(:,3)=dataBRIcomb.hs_latT-0.01;
    
    

%     dataBRI(:,1)=dataBRIcomb.hs_timeT;
%     dataBRI(:,2)=round(dataBRIcomb.hs_longT,2);
%     dataBRI(:,3)=round(dataBRIcomb.hs_latT,2);

    %fix BRIGHT coordinates in souther Australia to match FWT grid

%     k=find(dataBRI(:,3)<-35);
%     dataBRI(k,3)=dataBRI(k,3)+0.01;

    dataFWT(:,1)=FWT.hs_time;
    dataFWT(:,2)=FWT.hs_long;
    dataFWT(:,3)=FWT.hs_lat;

    %remove dataFWT outside of time range
    datebegin=737516;
    dateendin=737881.993055556;
    k=find(dataFWT(:,1)<datebegin);
    dataFWT(k,:)=[];
    fprintf('removing %i data before %s\n',length(k),datestr(datebegin));
    k=find(dataFWT(:,1)>dateendin);
    dataFWT(k,:)=[];
    fprintf('removing %i data after %s\n',length(k),datestr(dateendin));
    
    fprintf('BRIGHT\n')
    fprintf('number of agreement = %i\n',length(matchingtotal_BRI))
    fprintf('out of = %i\n',length(dataBRI))
    fprintf('agreement percentage= %.2f\n',length(matchingtotal_BRI)/length(dataBRI)*100)
    fprintf('false positive  = %i\n',length(dataBRI)-length(matchingtotal_BRI))
    fprintf('out of = %i\n',length(dataBRI))
    fprintf('false positive percentage = %.2f\n',(length(dataBRI)-length(matchingtotal_BRI))/length(dataBRI)*100)
    fprintf('FIREWATCH\n')
    fprintf('number of agreement = %i\n',length(matchingtotal_FWT))
    fprintf('out of = %i\n',length(dataFWT))
    fprintf('agreement percentage= %.2f\n',length(matchingtotal_FWT)/length(dataFWT)*100)
    fprintf('false positive  = %i\n',length(dataFWT)-length(matchingtotal_FWT))
    fprintf('out of = %i\n',length(dataFWT))
    fprintf('false positive percentage = %.2f\n',(length(dataFWT)-length(matchingtotal_FWT))/length(dataFWT)*100)

end

if 0
    %write transformed BRIGHT data to txt
    fid=fopen('txtout/BRI_transformed.txt','w')
    h=waitbar(0,'pleasewait');
    for i=1:length(dataBRI)
        waitbar(i/length(dataBRI),h,sprintf('ALL BRI.txt %.2f%%',i*100/length(dataBRI)))
        fprintf(fid,'%f,%f,%s\n',dataBRI(i,2),dataBRI(i,3),datestr(dataBRI(i,1),'dd/mmm/yyyy HH:MM:SS'));
    end
    fclose(fid)
    close(h)
end

if 1
    %write matching to file
    fid=fopen('txtout/exact_matches.txt','W')
    h=waitbar(0,'pleasewait');
    for i=1:length(matchingtotal_FWT)
        waitbar(i/length(matchingtotal_FWT),h,sprintf('exact matches.txt %.2f%%',i*100/length(matchingtotal_FWT)))
        fprintf(fid,'%f,%f,%s\n',matchingtotal_FWT(i,2),matchingtotal_FWT(i,3),datestr(matchingtotal_FWT(i,1),'dd/mmm/yyyy HH:MM:SS'));
    end
    fclose(fid)
    close(h)
end
return


clc;clear;
load unmatching_FWT
load dataBRI_epoch
%remove overshoot data
datebegin=737516;
dateendin=737881.993055556;
unmatchingtotal_FWT=sortrows(unmatchingtotal_FWT,1);
k=find(unmatchingtotal_FWT(:,1)<datebegin);
fprintf('removing %i data before %s\n',length(k),datestr(datebegin));
unmatchingtotal_FWT(k,:)=[];
k=find(unmatchingtotal_FWT(:,1)>dateendin);
fprintf('removing %i data after %s\n',length(k),datestr(dateendin));
unmatchingtotal_FWT(k,:)=[];

if 0
    %write unmatching to file
    fid=fopen('txtout/exact_unmatches_FWT.txt','w')
    h=waitbar(0,'pleasewait');
    for i=1:length(unmatchingtotal_FWT)
        waitbar(i/length(unmatchingtotal_FWT),h,sprintf('exact unmatches FWT.txt %.2f%%',i*100/length(unmatchingtotal_FWT)))
        fprintf(fid,'%f,%f,%s\n',unmatchingtotal_FWT(i,2),unmatchingtotal_FWT(i,3),datestr(unmatchingtotal_FWT(i,1),'dd/mmm/yyyy HH:MM:SS'));
    end
    fclose(fid)
    close(h)
end
return
for i=1:length(unmatching_FWT)
    FWTunmatchcount(i,1)=unmatching_FWT{i}.count;
    FWTunmatchcount(i,2)=i;
end
k=27603;
figure
load coast_i_aus.mat
plot(long,lat)
hold on
h1=plot(unmatching_FWT{k}.data(:,1),unmatching_FWT{k}.data(:,2),'o','MarkerSize',5,'Color','blue')
%plot(unmatchingtotal_FWT(:,2),unmatchingtotal_FWT(:,3),'x')

for i=1:length(dataBRI_epoch)
    if dataFWT_epoch{k}.epoch==dataBRI_epoch{i}.epoch
        m=i;
        break
    end
end

h2=plot(dataBRI_epoch{m}.data(:,1),dataBRI_epoch{m}.data(:,2),'x','MarkerSize',7,'Color','red','MarkerFaceColor','red','LineWidth',1.25);
title(sprintf('BRIGHT vs FIREWATCH %s',datestr(dataBRI_epoch{m}.epoch,'HH:MM dd-mmm-yyyy')))
legend([h2,h1],{'BRIGHT','FIREWATCH'})
ratiofix

return



