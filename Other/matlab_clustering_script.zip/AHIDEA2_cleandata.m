%script to clean AHIDEA data and cut the data
clc;clear;  
% Data readme
%    latitude,longitude,temp_k,Sh,Sl,power,confidence,datetime,offset
%

%load cleaned data
if ~exist('matfile/AHIDEA_all_clean.mat')
    load('matfile/AHIDEA_all.mat')
    %get long lat time
    for i=1:length(data)
        hs_long(i)=str2double(data{i,2});
        hs_lat(i) =str2double(data{i,1});
        hs_temp(i) =str2double(data{i,3});
        timestr = sprintf('%i',str2double(data{i,8}(1:end-1)));
        hs_time(i) =datenum(str2num(timestr(1:4)),str2num(timestr(5:6)),str2num(timestr(7:8)),str2num(timestr(9:10)),str2num(timestr(11:12)),0);
    end
    save matfile/AHIDEA_all_clean hs_long hs_lat hs_time hs_temp
else
    load('matfile/AHIDEA_all_clean.mat')
end

%cut data to only australia
save4cut=[];
for i=1:length(hs_long)
    if (hs_lat(i)>-11)
        save4cut=[save4cut;i];
    end
end
hs_long(save4cut)=[];hs_lat(save4cut)=[];hs_time(save4cut)=[];hs_temp(save4cut)=[];
save matfile/AHIDEA_aus_clean hs_long hs_lat hs_temp hs_time 

return

%cut data to only 1 phenomenon
save4cut=[];
for i=1:length(hs_long)
    if (hs_lat(i)<-34)|(hs_lat(i)>-32)|(hs_long(i)<118.5)|(hs_long(i)>120.5)
        save4cut=[save4cut;i];
    end
end
hs_long(save4cut)=[];hs_lat(save4cut)=[];hs_time(save4cut)=[];hs_temp(save4cut)=[];
save matfile/AHIDEA_aus_clean hs_long hs_lat hs_temp hs_time 
return

