%comparing HIMAWARI TIFF
clc;clear;
t1=Tiff('nearest.tif','r');
nearest=read(t1);
t2=Tiff('native.tif','r');
native=read(t2);
%t3=Tiff('noresampling.tif','r');
%unmapped=read(t3);

[c1,n]=imhist(nearest);
[c2,n]=imhist(native);
%[c3,n]=imhist(unmapped);

d=pdist2(c1',c2')
%d2=pdist2(c1',c3')

t3=Tiff('FDSKnative.tif','r');
FDSKnative=read(t3);

