%create a monthly folder for WFABBA data

cd 'D:\Research\2020\Hotspot\persistence\data\WFABBA_YEAR\hotspot_split\result\daily'

files=dir('*.txt');
firstname=files(1).name;
lastname=files(end).name;

datenumstart=datenum([str2double(firstname(end-11:end-8)) str2double(firstname(end-7:end-6)) str2double(firstname(end-5:end-4)) 0 0 0])
datenumend=datenum([str2double(lastname(end-11:end-8)) str2double(lastname(end-7:end-6)) str2double(lastname(end-5:end-4)) 0 0 0])
datenumfull=datenumstart:datenumend;

monthstart=datetime(str2double(firstname(end-11:end-8)),str2double(firstname(end-7:end-6)),1);
monthend=datetime(str2double(lastname(end-11:end-8)),str2double(lastname(end-7:end-6)),1);
dt = calmonths(caldiff([monthstart monthend],'month'));
monthfull= dateshift(monthstart,'start','month',0:dt);
mkdir WFABBA

for i=1:length(monthfull)
    foldername=sprintf('WFABBA/%s',char(datetime(monthfull(i),'format','yyyyMM')));
    mkdir(foldername);
    movefile(sprintf('WFABBA_%s*.txt',char(datetime(monthfull(i),'format','yyyyMM'))),foldername);
end
    