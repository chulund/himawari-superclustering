%script to load sentinel hotspot
clc;clear;
filename="sentinel_19-02-2020.csv";

fid=fopen(filename);
line=fgetl(fid);
header=strsplit(line,',');
%for i=1:length(header)
%    eval(["data."+header{i}+"=zeros(1,1)"]);
%end
counter=1;
a{length(header),1}=[];
while ~feof(fid)
    line=fgetl(fid);
    linesplit=strsplit(line,',','CollapseDelimiters', false);
    for i=1:length(header)
        data{counter,i}=linesplit{i};
    end
    counter=counter+1;
end
fclose(fid);
save([filename+".mat"],'data');