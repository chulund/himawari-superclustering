%script to load AHI-DEA hotspot
clc;clear;
folder='D:/Research/2020/Hotspot Inter-comparison and validation/persistence/data/AHIDEA';

flist=dir([folder '/*.txt']);
counter=1;
for i=1:length(flist)
    filename=flist(i).name;
    fid=fopen([folder filename]);
    line=fgetl(fid);
    while ~feof(fid)
        line=fgetl(fid);
        linesplit=strsplit(line,',','CollapseDelimiters', false);
        for i=1:9
            data{counter,i}=linesplit{i};
        end
        counter=counter+1;
    end
    fclose(fid);

    
end
save('matfile/AHIDEA.mat','data');