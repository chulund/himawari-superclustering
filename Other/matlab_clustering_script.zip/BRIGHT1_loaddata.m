clc;clear;
filelist = dir('D:\Research\2020\Hotspot\persistence\pythonclustering\output');
h=waitbar(0,'please wait');
for i=3:length(filelist)
    waitbar(i/length(filelist),h,sprintf('read %i out of %i data (%.2f%%)',i,length(filelist),i/length(filelist)*100))
    fid=fopen([filelist(i).folder,'\',filelist(i).name]);
    temp=strsplit(filelist(i).name,'_');
    dailydata{i-2}.date=datestr([str2double(temp{2}(1:4)) str2double(temp{2}(5:6)) str2double(temp{2}(7:8)) 0 0 0]);
    counter_cluster=1;
    counter_coord=1;
    while ~feof(fid)
        line=fgetl(fid);
        if strcmp(line,'END')
            counter_coord=1;
            counter_cluster=counter_cluster+1;
        elseif length(line)<10
            clusterdata{counter_cluster}.id=str2double(line);
        else
            temp=strsplit(line,',');
            clusterdata{counter_cluster}.long(counter_coord)=str2double(temp{1});
            clusterdata{counter_cluster}.lat(counter_coord)=str2double(temp{2});
            counter_coord=counter_coord+1;
        end
    end
    fclose(fid);
    dailydata{i-2}.clusterdata=clusterdata;
end
close(h);
save matfile/dailydata dailydata