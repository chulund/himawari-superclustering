%compare BRIGHT and FIREWATCH using exact matches and tolerance with
%FIREWATCH refence and BRIGHT reference
clc;clear;

%select method
method=2;
%1.exact matches
%2.buffering

%count unmatch as well?
methodunmatch =1;

%which hotspot as reference
reference = 2;
%1.FIREWATCH as reference
%2.BRIGHT as reference

%part 1 loading data
fprintf('1. loading data\n')

if exist('dataBRIcomb.mat')
    load('dataBRIcomb.mat')
end
if ~exist('FWT.mat')
    FWT=load('FIREWATCH_aus_clean.mat');
    save FWT FWT
else
    load('FWT.mat')
end

%fix BRIGHT + shift half pixel
dataBRI(:,1)=dataBRIcomb.hs_timeT;
dataBRI(:,2)=dataBRIcomb.hs_longT+0.01;
dataBRI(:,3)=dataBRIcomb.hs_latT-0.01;

dataBRI_fix(:,1)=dataBRIcomb.hs_timeT;
dataBRI_fix(:,2)=fix(dataBRIcomb.hs_longT*100)/100;
dataBRI_fix(:,3)=fix(dataBRIcomb.hs_latT*100)/100;

dataBRI_round(:,1)=dataBRIcomb.hs_timeT;
dataBRI_round(:,2)=round(dataBRIcomb.hs_longT,2);
dataBRI_round(:,3)=round(dataBRIcomb.hs_latT,2);

% %fix BRIGHT coordinates in souther Australia to match FWT grid
% 
% k=find(dataBRI(:,3)<-35);
% dataBRI(k,3)=dataBRI(k,3)-0.01;

dataFWT(:,1)=FWT.hs_time;
dataFWT(:,2)=FWT.hs_long;
dataFWT(:,3)=FWT.hs_lat;

%remove dataFWT outside of time range
datebegin=737516;
dateendin=737881.993055556;
k=find(dataFWT(:,1)<datebegin);
dataFWT(k,:)=[];
fprintf('removing %i data before %s\n',length(k),datestr(datebegin));
k=find(dataFWT(:,1)>dateendin);
dataFWT(k,:)=[];
fprintf('removing %i data after %s\n',length(k),datestr(dateendin));

fprintf('2. split into epoch\n')
if ~exist('dataBRI_epoch.mat','file')
    dataBRI=sortrows(dataBRI,1);
    dataBRI(:,1)=datenum(datestr(dataBRI(:,1)));
    uniquetime=unique(dataBRI(:,1));
    dataBRI_epoch={};
    h2=waitbar(0,'please wait');
    for i=1:length(uniquetime)
        waitbar(i/length(uniquetime),h2,sprintf('splitting epoch %.2f%%',i*100/length(uniquetime)));
        k=find(uniquetime(i)==dataBRI(:,1));
        dataBRI_epoch{i}.epoch=uniquetime(i);
        dataBRI_epoch{i}.time=datestr(uniquetime(i));
        dataBRI_epoch{i}.data(:,1)=dataBRI(k,2);
        dataBRI_epoch{i}.data(:,2)=dataBRI(k,3);
    end
    close(h2)
    save dataBRI_epoch dataBRI_epoch
else
    load dataBRI_epoch
end
if ~exist('dataFWT_epoch.mat','file')
    dataFWT=sortrows(dataFWT,1);
    dataFWT(:,1)=datenum(datestr(dataFWT(:,1)));
    uniquetime=unique(dataFWT(:,1));
    dataFWT_epoch={};
    h2=waitbar(0,'please wait');
    for i=1:length(uniquetime)
        waitbar(i/length(uniquetime),h2,sprintf('splitting epoch %.2f%%',i*100/length(uniquetime)));
        k=find(uniquetime(i)==dataFWT(:,1));
        dataFWT_epoch{i}.epoch=uniquetime(i);
        dataFWT_epoch{i}.time=datestr(uniquetime(i));
        dataFWT_epoch{i}.data(:,1)=dataFWT(k,2);
        dataFWT_epoch{i}.data(:,2)=dataFWT(k,3);
    end
    close(h2)
    save dataFWT_epoch dataFWT_epoch
else
    load dataFWT_epoch
end

fprintf('3. comparing per epoch\n')
if reference==1
    %firewatch as reference
    dataFWT=sortrows(dataFWT,1);
    uniquetimeFWT=unique(dataFWT(:,1));
    uniquetimeFWT=datenum(datestr(uniquetimeFWT));
    h=waitbar(0,'pleasewait');
    counter=1;counter2=1;
    for i=1:length(dataBRI_epoch)
        waitbar(i/length(dataBRI_epoch),h,sprintf('%.2f%%',i*100/length(dataBRI_epoch)))

        %get the data
        j=find(datenum(datestr(dataBRI_epoch{i}.epoch))==uniquetimeFWT);
        BRIcompare=dataBRI_epoch{i}.data;
        if ~isempty(j)
            FWTcompare=dataFWT_epoch{j}.data;
        else
            if methodunmatch
                sizedata=size(dataBRI_epoch{i}.data);
                dataBRI_epoch{i}.matches=zeros(sizedata(1),1);
                countunmatches=size(BRIcompare);
                unmatching_BRI{counter2}.date=dataBRI_epoch{i}.epoch;
                unmatching_BRI{counter2}.count=countunmatches(1);
                unmatching_BRI{counter2}.data=BRIcompare;
                counter2=counter2+1;
            end
            continue
        end

        %comparing                
        switch method
            case 1
                %idx=ismember(BRIcompare, FWTcompare, 'rows');
                idx=ismembertol(BRIcompare, FWTcompare, 1e-10, 'ByRows',1,'DataScale', [1,1]);
                %idx=ismembertol(BRIcompare, FWTcompare, 0.01, 'ByRows',1,'DataScale', [1,1]);
            case 2
                idx=ismembertol(BRIcompare, FWTcompare, 0.02, 'ByRows',1,'DataScale', [1,1]);
        end
        c = 1:length(BRIcompare(:,1));
        d = c(idx);
        e = c(~idx);
        if ~isempty(d)
            matches=BRIcompare(d,:);
            countmatches=size(matches);
            if methodunmatch
                unmatches=BRIcompare(e,:);
                countunmatches=size(unmatches); 
            end
            if methodunmatch
                dataBRI_epoch{i}.matches=double(idx);
            end
        else
            matches=[];
            countmatches=0;
            if methodunmatch
                unmatches=BRIcompare(e,:);
                countunmatches=size(unmatches);
                dataBRI_epoch{i}.matches=double(idx);
            end
        end

        %create cell
        if ~(countmatches==0)
            matching_BRI{counter}.date=dataBRI_epoch{i}.epoch;
            matching_BRI{counter}.count=countmatches(1);
            matching_BRI{counter}.data=matches;
            counter=counter+1;
        end
        if methodunmatch
            unmatching_BRI{counter2}.date=dataBRI_epoch{i}.epoch;
            unmatching_BRI{counter2}.count=countunmatches(1);
            unmatching_BRI{counter2}.data=unmatches;
            counter2=counter2+1;
        end
    end
    close(h)

elseif reference==2
    %FWTght as reference
    dataBRI=sortrows(dataBRI,1);
    uniquetimeBRI=unique(dataBRI(:,1));
    uniquetimeBRI=datenum(datestr(uniquetimeBRI));
    h=waitbar(0,'pleasewait');
    counter=1;counter2=1;
    for i=1:length(dataFWT_epoch)
        waitbar(i/length(dataFWT_epoch),h,sprintf('%.2f%%',i*100/length(dataFWT_epoch)))

        %get the data
        j=find(datenum(datestr(dataFWT_epoch{i}.epoch))==uniquetimeBRI);
        FWTcompare=dataFWT_epoch{i}.data;
        if ~isempty(j)
            BRIcompare=dataBRI_epoch{j}.data;
        else
            if methodunmatch
                sizedata=size(dataFWT_epoch{i}.data);
                dataFWT_epoch{i}.matches=zeros(sizedata(1),1);
                countunmatches=size(FWTcompare);
                unmatching_FWT{counter2}.date=dataFWT_epoch{i}.epoch;
                unmatching_FWT{counter2}.count=countunmatches(1);
                unmatching_FWT{counter2}.data=FWTcompare;
                counter2=counter2+1;
            end
            continue
        end

        %comparing                
        switch method
            case 1
                %idx=ismember(FWTcompare, BRIcompare, 'rows');
                idx=ismembertol(FWTcompare, BRIcompare, 1e-10, 'ByRows',1,'DataScale', [1,1]);
            case 2
                idx=ismembertol(FWTcompare, BRIcompare, 0.02, 'ByRows',1,'DataScale', [1,1]);
        end
        c = 1:length(FWTcompare(:,1));
        d = c(idx);
        e = c(~idx);
        if ~isempty(d)
            matches=FWTcompare(d,:);
            countmatches=size(matches);
            if methodunmatch
                unmatches=FWTcompare(e,:);
                countunmatches=size(unmatches);
            end
            if methodunmatch
                dataFWT_epoch{i}.matches=double(idx);
            end
        else
            matches=[];
            countmatches=0;
            if methodunmatch
                unmatches=FWTcompare(e,:);
                countunmatches=size(unmatches);
                dataFWT_epoch{i}.matches=double(idx);
            end
        end

        %create cell
        if ~(countmatches==0)
            matching_FWT{counter}.date=dataFWT_epoch{i}.epoch;
            matching_FWT{counter}.count=countmatches(1);
            matching_FWT{counter}.data=matches;
            counter=counter+1;
        end
        if methodunmatch
            unmatching_FWT{counter2}.date=dataFWT_epoch{i}.epoch;
            unmatching_FWT{counter2}.count=countunmatches(1);
            unmatching_FWT{counter2}.data=unmatches;
            counter2=counter2+1;
        end
    end
    close(h)
end

fprintf('4. congregating matches \n')

%congregate


if reference==1
    matchingtotal_BRI=[0,0,0];
    for i=1:length(matching_BRI)
        sizetotal=size(matchingtotal_BRI);
        sizeplus=size(matching_BRI{i}.data);
        matchingtotal_BRI(sizetotal(1)+1:sizeplus(1)+sizetotal(1),1)=matching_BRI{i}.date;
        matchingtotal_BRI(sizetotal(1)+1:sizeplus(1)+sizetotal(1),2:3)=matching_BRI{i}.data;
    end
    matchingtotal_BRI(1,:)=[];
elseif reference==2
    matchingtotal_FWT=[0,0,0];
    for i=1:length(matching_FWT)
        sizetotal=size(matchingtotal_FWT);
        sizeplus=size(matching_FWT{i}.data);
        matchingtotal_FWT(sizetotal(1)+1:sizeplus(1)+sizetotal(1),1)=matching_FWT{i}.date;
        matchingtotal_FWT(sizetotal(1)+1:sizeplus(1)+sizetotal(1),2:3)=matching_FWT{i}.data;
    end
    matchingtotal_FWT(1,:)=[];
end


if method==1
    if reference==1
        save matching_BRI matching_BRI matchingtotal_BRI 
    elseif reference==2
        save matching_FWT matching_FWT matchingtotal_FWT
    end
elseif method==2
    if reference==1
        save matching_buffer_BRI matching_BRI matchingtotal_BRI 
    elseif reference==2
        save matching_buffer_FWT matching_FWT matchingtotal_FWT
    end
end

if methodunmatch
    fprintf('5. congregating unmatches \n')
    if reference==1
        unmatchingtotal_BRI=[0,0,0];
        for i=1:length(unmatching_BRI)
            sizetotal=size(unmatchingtotal_BRI);
            sizeplus=size(unmatching_BRI{i}.data);
            unmatchingtotal_BRI(sizetotal(1)+1:sizeplus(1)+sizetotal(1),1)=unmatching_BRI{i}.date;
            unmatchingtotal_BRI(sizetotal(1)+1:sizeplus(1)+sizetotal(1),2:3)=unmatching_BRI{i}.data;
        end
        unmatchingtotal_BRI(1,:)=[];
    elseif reference==2
        unmatchingtotal_FWT=[0,0,0];
        for i=1:length(unmatching_FWT)
            sizetotal=size(unmatchingtotal_FWT);
            sizeplus=size(unmatching_FWT{i}.data);
            unmatchingtotal_FWT(sizetotal(1)+1:sizeplus(1)+sizetotal(1),1)=unmatching_FWT{i}.date;
            unmatchingtotal_FWT(sizetotal(1)+1:sizeplus(1)+sizetotal(1),2:3)=unmatching_FWT{i}.data;
        end
        unmatchingtotal_FWT(1,:)=[];
    end

    if method==1
        if reference==1
            save unmatching_BRI unmatching_BRI unmatchingtotal_BRI dataBRI_epoch
        elseif reference==2
            save unmatching_FWT unmatching_FWT unmatchingtotal_FWT dataFWT_epoch
        end
    elseif method==2
        if reference==1
            save unmatching_buffer_BRI unmatching_BRI unmatchingtotal_BRI dataBRI_epoch
        elseif reference==2
            save unmatching_buffer_FWT unmatching_FWT unmatchingtotal_FWT dataFWT_epoch
        end
    end
end

load gong.mat;
sound(y);
