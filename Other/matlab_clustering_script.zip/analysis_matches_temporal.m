% matches temporal analysis

