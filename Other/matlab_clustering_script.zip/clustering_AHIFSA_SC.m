%persistence AHIFSA
clc;clear;
load('201906170410_201906170412_28_2968_3186_4239_4404.txt.mat')

% Data readme
%    A 'GY', 'GN', 'PY' or 'PN' flag.  
%         G indicates a geostationary (Himawari-8 STAG-FA) hotspot.
%         P indicates a polar-orbiting (in this case MODIS-AQUA) hotspot.
%         Y indicates a common detection.
%         N indicates an unmatched detection.
%     longitude
%     latitude
%     date/time in YYYYMMDDhhmmss format
%     MIR
%     TIR
%     FRP. (note sometimes the FRP field for STAG-FA will be 999.0 
%         I have used 999.0 as a missing value in this processing.  I used to use -999.0 so it was easily separable from an actual FRP but I had to use this positive value in the interim due to my processing.
%         Be careful when interpreting the value I will find a way around it in the future.

%% spatial cluster

%search radius in m
radius=4000;

%get long lat
for i=1:length(data)
    hs_long(i)=str2double(data{i,2});
    hs_lat(i) =str2double(data{i,3});
end

%datetime


%plotting
load coast_i
plot(long,lat)
hold on
plot(hs_long,hs_lat,'xr')
xlim([min(hs_long)-(max(hs_long)-min(hs_long))*.2 max(hs_long)+(max(hs_long)-min(hs_long))*.2])
ylim([min(hs_lat)-(max(hs_lat)-min(hs_lat))*.2 max(hs_lat)+(max(hs_lat)-min(hs_lat))*.2])

for i=1:length(data)
    %create circle to check radius
    [xv,yv] = createcircle(hs_long(i),hs_lat(i),radius);
        plot(xv,yv,'-g')
        
    [in,on] = inpolygon(hs_long,hs_lat,xv,yv);
    %create a corelation matrix
    cor(i,:)=in;
end

for i=1:length(data)
    text(hs_long(i)-0.01,hs_lat(i)-0.01,sprintf('%i',i))
end

%spatial clustering
cor_check=cor;

counter2=1; % for each cluster
aggregate=[]; %array to save result
for i=1:length(cor_check)
    cor_process=cor_check(i,:);
    if sum(cor_process)==0
        continue
    end
    %remove self correlation
    cor_check(i,i)=0;
    
    member=[];
    looping=[];
    counter=1;
    member(counter)=i;
    cor_check(i,:)=0;
    
    index=[];index=find(cor_process);
    if isempty(index)
        aggregate{counter2}=member;
        counter2=counter2+1;
    end
    
    looping=[looping;index'];
    while ~isempty(looping)
        
        counter=counter+1;
        member(counter)=looping(1,1);
        
        index=[];
        index=find(cor_check(looping(1,1),:));        
        if ~isempty(index)
            looping=[looping;index'];
        end
        %remove visited row
        cor_check(looping(1,1),:)=0;
        looping(1)=[];
        
    end
    aggregate{counter2}=unique(member);
    counter2=counter2+1;
    
end

aggregate=aggregate';