%new comparison method
%14 August 2020
clc;clear;

%create long lat list of FWT
[A1,R1] = readgeoraster('layer63_202005140610_HI8_AHI_TKY_b7.tif');
[AX, AY]= size (A1);
lon1 = zeros(size(A1));
lat1 = zeros(size(A1));
[rows,cols] = meshgrid(1:AY,1:AX);
[lat1,lon1]=pix2latlon(R1,cols+0.5,rows+0.5); %make it pixel center

%create long lat list of NATIVE
[A2ori,R2] = readgeoraster('layer63_202005140610_HI8_AHI_TKY_b7b.tif');
A2=A2ori(:,:,1);
[AX2, AY2]= size (A2);
lon2 = zeros(size(A2));
lat2 = zeros(size(A2));
[rows,cols] = meshgrid(1:AY2,1:AX2);
[lat2,lon2]=pix2latlon(R2,cols+0.5,rows+0.5); %make it pixel center

lookuptable=load('lookuptable.mat');

if 1
    load coast_i_aus.mat
    figure
    plot(long,lat)
    hold on
    plot(lon1,lat1,'xr')
    plot(lookuptable.lon,lookuptable.lat,'xb')
end


% fid=fopen('xyhima.txt','w');
% h=waitbar(0,'please wait');
% counter=0;
% for i=1:AX2
%     for j=1:AY2
%         waitbar(counter/(AX2*AY2),h,sprintf('%.2f',counter/(AX2*AY2)*100))
%         counter=counter+1;
%         fprintf(fid,'%f %f\n',lon2(i),lat2(j));
%     end
% end
% close(h)
% fclose(fid);
        