    %comparing BRIGHT hotspot and FIREWATCH hotspot
%update 10 08 2020 : add pixel number converter

clc;clear;
%load aus clean data
if ~exist('BRI.mat')
    BRI=load('BRIGHT_aus_clean.mat');
    save BRI BRI
else
    load('BRI.mat')
end
if ~exist('FWT.mat')
    FWT=load('FIREWATCH_aus_clean.mat');
    save FWT FWT
else
    load('FWT.mat')
end

%specify date to compare
date2comp='1-May-2019';
fprintf('date2compare = %s\n',date2comp);
%get the data
k=find(floor(BRI.hs_time)==datenum(date2comp));
dataBRIGHT.hs_long=BRI.hs_long(k);
dataBRIGHT.hs_lat=BRI.hs_lat(k);
dataBRIGHT.hs_time=BRI.hs_time(k);
dataBRIGHT.hs_x=BRI.hs_x(k);
dataBRIGHT.hs_y=BRI.hs_y(k);

k=find(floor(FWT.hs_time)==datenum(date2comp));
dataFWT.hs_long=FWT.hs_long(k);
dataFWT.hs_lat=FWT.hs_lat(k);
dataFWT.hs_time=FWT.hs_time(k);

%plot
if 0
    figure
    load coast_i_aus.mat
    plot(long,lat)
    hold on
    h1 = plot(dataBRIGHT.hs_long,dataBRIGHT.hs_lat,'.r')
    h2 = plot(dataFWT.hs_long,dataFWT.hs_lat,'.b')
    ratiofix
end

%convert hx hy pixel number to long lat
hx=dataBRIGHT.hs_x+1; %add 1 pixel to the right
hy=dataBRIGHT.hs_y+1;%add 1 pixel to the bottom
[long_out,lat_out]=himapixnum2longlat(hx,hy);
dataBRIGHT.hs_longT=long_out;
dataBRIGHT.hs_latT=lat_out;

save dataa_1Feb19 dataBRIGHT dataFWT date2comp


load dataa_1Feb19

figure
load coast_i_aus.mat
plot(long,lat)
hold on
%h1 = plot(floor(dataBRIGHT.hs_longT*100)/100,floor(dataBRIGHT.hs_latT*100)/100,'Xr')
h1 = plot(round(dataBRIGHT.hs_longT,2),round(dataBRIGHT.hs_latT,2),'Xr')
h2 = plot(dataFWT.hs_long,dataFWT.hs_lat,'ob')
h3 = plot(dataBRIGHT.hs_long,dataBRIGHT.hs_lat,'Xg')
ratiofix
legend([h3,h1,h2],{'BRIGHT','BRIGHT Transformed','FIREWATCH'})


title(sprintf('BRIGHT vs FIREWATCH %s',date2comp))


return



%cut FWT data to only shows the extent of NSW and VIC
save4cut=[];counter=1;
%k=find(dataFWT.hs_long<140.9987378 | dataFSA.hs_lat>-28.9991148);
for i=1:length(dataFWT.hs_long)
    if (dataFWT.hs_long(i)<140.9987378) | (dataFWT.hs_lat(i)>-28.9991148)
        save4cut(counter)=i;
        counter=counter+1;
    end
end
dataFWT.hs_id(save4cut)=[];
dataFWT.hs_long(save4cut)=[];
dataFWT.hs_lat(save4cut)=[];
dataFWT.hs_temp(save4cut)=[];
dataFWT.hs_time(save4cut)=[];

save dataFSA
save dataFWT



