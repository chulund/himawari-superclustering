clc;clear;
load('matfile/dailycluster.mat')

%difference in day threshold (in day)
threshold=1;

fprintf('superclustering daily superclusterdata\n')
%checking the superclusters day by day
supercluster=dailycluster{1}.clusterdata;
for i=2:6%:length(dailycluster)
    cluster2check=dailycluster{i}.clusterdata;
    cor=zeros(length(supercluster),length(cluster2check));
    fprintf('   processing day %i out of %i\n',i,length(dailycluster));
    for j=1:length(supercluster)
        for k=1:length(cluster2check)
            %check if there's intersection and day difference < threshold
            polyout=intersect(supercluster{j}.polyshape,cluster2check{k}.polyshape);
            if supercluster{j}.startend(1)>cluster2check{k}.startend(1)&& supercluster{j}.startend(2)<cluster2check{k}.startend(2)
                did=0; % j is inside k
            elseif cluster2check{k}.startend(1)>supercluster{j}.startend(1)&& supercluster{j}.startend(2)>cluster2check{k}.startend(2)
                did=0; % k is inside j
            elseif supercluster{j}.startend(1)<cluster2check{k}.startend(2)&& supercluster{j}.startend(2)>cluster2check{k}.startend(1)
                did=0; % j intersect k, j precede
            elseif cluster2check{k}.startend(1)<supercluster{j}.startend(2)&& cluster2check{k}.startend(2)>supercluster{j}.startend(1)
                did=0; % j intersect k, k precede
            elseif cluster2check{k}.startend(1)>supercluster{j}.startend(2)
                did=abs(cluster2check{k}.startend(1)-supercluster{j}.startend(2)); % j & k not intersecting, j precede
            elseif supercluster{j}.startend(1)>cluster2check{k}.startend(2)
                did=abs(supercluster{j}.startend(1)-cluster2check{k}.startend(2)); % j & k not intersecting, k precede
            else
                did=[];                
            end
            if ~isempty(polyout.Vertices)&&(did<=threshold)
                cor(j,k)=1;
            end
        end
    end
    
    visitedcheck=[];
    visitcounter=0;
    
    %joining the rest into supercluster
    for j=1:length(supercluster)
        %joining matching clusters
        if sum(cor(j,:))>0
            tru=find(cor(j,:));
            %check if the cluster2check ever been visited
            cont=0;
            saved=[];
            for k=1:length(tru)
                if visitcounter>0
                    if sum(tru(k)==visitedcheck(:,1))>=1
                        cont=cont+1;
                        saved(cont)=k;                        
                    end
                end
            end
            if cont
                tru(saved)=[];
            end
            if isempty(tru)
                continue
            end            
            
            %update cluster id into supercluster
            if ~isfield(supercluster{j},'clusterid')
                supercluster{j}.clusterid{1}=supercluster{j}.id;
            end
            supercluster{j}.id=sprintf('SC');
            %declare new supercluster circle
            newcircle=supercluster{j}.polyshape;

            for k=1:length(tru)
                %store visitation
                visitcounter=visitcounter+1;
                visitedcheck(visitcounter,1)=tru(k);
                visitedcheck(visitcounter,2)=j;
                
                newcircle = union(newcircle, cluster2check{tru(k)}.polyshape);
                %update supercluster endtime
                if supercluster{j}.startend(2)<cluster2check{tru(k)}.startend(2)
                   supercluster{j}.startend(2)=cluster2check{tru(k)}.startend(2);
                end
             
            end
            %update circle
            supercluster{j}.polyshape=newcircle;
        end
    end
    %add unmatched to supercluster variable
    counter=length(supercluster);
    for j=1:length(cluster2check) 
        if sum(cor(:,j))>0
            %fprintf('\ngoes here in %i at %i',j,i)
            continue
        end
        if strcmp(cluster2check{j}.id,'SC')
            supercluster{counter+1}.id=cluster2check{j}.id;
            supercluster{counter+1}.startend=cluster2check{j}.startend;
        else
            supercluster{counter+1}.id='cluster';
            supercluster{counter+1}.startend=cluster2check{j}.startend;
            supercluster{counter+1}.polyshape=cluster2check{j}.polyshape;
        end
        counter=counter+1;
    end
    if exist('tru')
        clear tru;
    end
end