% new cluster method
clc;clear
load('AHIFSA_aus_clean.mat')

% compute pairwise distances between all points
XY=([hs_long;hs_lat]');
