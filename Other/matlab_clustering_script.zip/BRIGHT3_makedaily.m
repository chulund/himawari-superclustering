%script to compile BRIGHT data daily and make it a structure (original, not
%transformed)
clc;clear;
load('matfile/BRIGHT_aus_clean.mat')

%doing the process daily
days=floor(min(hs_time)):floor(max(hs_time));

%load daily data
if ~exist('matfile/BRIGHT_aus_daily.mat')
    %separate data by date
    for i=1:length(days)
        today=find(~(floor(hs_time)-days(i)));
        doy = day(datetime(datevec(days(i))),'dayofyear');
        year=datevec(days(1));
        yy=year(1)-2000;
        dailydata{i}.date=datestr(days(i));
        dailydata{i}.hs_id=['']; %initiate to prevent empty field
        for j=1:length(today)
            dailydata{i}.hs_id(j,:)=sprintf('HS%02d%03d_%05i',yy,doy,j);
        end
        dailydata{i}.hs_long=hs_long(today)';
        dailydata{i}.hs_lat=hs_lat(today)';
        dailydata{i}.hs_time=hs_time(today)';
    end
    save matfile/BRIGHT_aus_daily.mat dailydata
else
    load('matfile/BRIGHT_aus_daily.mat')
end

load chirp
sound(y,Fs)