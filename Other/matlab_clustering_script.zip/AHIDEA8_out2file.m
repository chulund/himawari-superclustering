%script to save supercluster data to file
clc;clear

load('matfile/AHIDEA_aus_supercluster.mat')

fid=fopen('fileout/AHIDEA_aus_supercluster.csv','w');
fprintf(fid,'id,name,time start,time end,no of hotspot,no of cluster\n');
SC_count=0;
for i=1:length(supercluster)
    if strcmp(supercluster{i}.id,'SC')
        fprintf(fid,'%i,%s,%s,%s,%i,%i,\n',i,supercluster{i}.id,datestr(supercluster{i}.startend(1)),datestr(supercluster{i}.startend(2)),supercluster{i}.numHS,supercluster{i}.clusternum);
    else
        fprintf(fid,'%i,%s,%s,%s,%i,%i,\n',i,supercluster{i}.id,datestr(supercluster{i}.startend(1)),datestr(supercluster{i}.startend(2)),supercluster{i}.numHS,1);
    end
end
fclose(fid);