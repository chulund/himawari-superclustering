%script to clean FIREWATCH data and cut the data for 2 or more MATFILEs
clc;clear;  
% Data readme
%    WKT,ID,Longitude,Latitude,Descriptio,Satellite,Orbit,Time,Date,SatZenith,Confidence,Intensity,Location
%

%load cleaned data
load FIREWATCH.mat
counter=1;
for i=1:length(data)
    if ~isempty(data{i,3})&&~isempty(data{i,4})     
        hs_long(counter)=str2double(data{i,3}(2:end-1));
        hs_lat(counter) =str2double(data{i,4}(2:end-1));
        hs_temp(counter) =str2double(data{i,12}(2:end-1));
        time=strsplit(data{i,8},':');
        date = sprintf('%i',str2double(data{i,9}(2:end-1)));
        hs_time(counter) =datenum(str2double(date(1:4)),str2double(date(5:6)),str2double(date(7:8)),str2double(time{1}),str2double(time{2}),0) ...
            - datenum([0 0 0 8 0 0]); %plus 8 hour time to convert to UTC
        counter=counter+1;
    end
end

save FIREWATCH_clean hs_long hs_lat hs_time hs_temp