%plot after convert from hx hy
clc;clear;
load('dataBRIcomb.mat')
load('FWT.mat')
load('matching_BRI.mat')

dataBRI(:,1)=dataBRIcomb.hs_timeT;
dataBRI(:,2)=round(dataBRIcomb.hs_longT,2);
dataBRI(:,3)=round(dataBRIcomb.hs_latT,2);

%fix BRIGHT coordinates in souther Australia to match FWT grid

k=find(dataBRI(:,3)<-35);
dataBRI(k,3)=dataBRI(k,3)+0.01;

dataFWT(:,1)=FWT.hs_time;
dataFWT(:,2)=FWT.hs_long;
dataFWT(:,3)=FWT.hs_lat;

load coast_i_aus.mat
figure
plot(long,lat,'-k')
hold on
cmap=distinguishable_colors(3);
go=.1;
h1=plot(dataBRI(:,2),dataBRI(:,3),'X','Color',cmap(2,:),'MarkerFaceColor',cmap(2,:));
h2=plot(dataFWT(:,2),dataFWT(:,3),'o','Color',[go go go],'MarkerFaceColor',cmap(3,:),'MarkerSize',2);
h3=plot(matchingtotal_BRI(:,2),matchingtotal_BRI(:,3),'d','Color',[go go go],'MarkerFaceColor',cmap(1,:),'MarkerSize',2);
title(' BRIGHT and FIREWATCH Comparison','FontSize',30)
legend([h1,h2,h3],{'BRIGHT','Firewatch','Matching'})
xlim([min(dataBRI(:,2))-3 max(dataBRI(:,2))+3])
ylim([min(dataBRI(:,3))-3 max(dataBRI(:,3))+3])
set(gcf, 'Position', get(0, 'Screensize'));
ratiofix
saveas(gcf,'figures/RMIT_FIREWATCH_MATCH_all.png')

return
load coast_i_aus.mat
figure
plot(long,lat,'-k')
hold on
cmap=distinguishable_colors(3);
go=.1;
h2=plot(dataFWT(:,2),dataFWT(:,3),'o','Color',[go go go],'MarkerFaceColor',cmap(3,:),'MarkerSize',2);
title(' FIREWATCH hotspot 1 March 2019 - 31 April 2020','FontSize',20)
legend([h2],{'Firewatch'})
xlim([min(dataFWT(:,2))-3 max(dataFWT(:,2))+3])
ylim([min(dataFWT(:,3))-3 max(dataFWT(:,3))+3])
set(gcf, 'Position', get(0, 'Screensize'));
ratiofix
saveas(gcf,'figures/FIREWATCH_all.png')

return
load coast_i_aus.mat
figure
plot(long,lat,'-k')
hold on
cmap=distinguishable_colors(3);
go=.1;
h1=plot(dataBRI(:,2),dataBRI(:,3),'X','Color',cmap(2,:),'MarkerFaceColor',cmap(2,:));
h2=plot(dataFWT(:,2),dataFWT(:,3),'o','Color',[go go go],'MarkerFaceColor',cmap(3,:),'MarkerSize',2);
title(' BRIGHT and FIREWATCH Comparison','FontSize',30)
legend([h1,h2],{'BRIGHT','Firewatch'})
xlim([min(dataBRI(:,2))-3 max(dataBRI(:,2))+3])
ylim([min(dataBRI(:,3))-3 max(dataBRI(:,3))+3])
set(gcf, 'Position', get(0, 'Screensize'));
ratiofix
saveas(gcf,'figures/RMIT_FIREWATCH_all.png')