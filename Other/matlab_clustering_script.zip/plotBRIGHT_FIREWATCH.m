%plot after convert from hx hy
clc;clear;
load('dataBRIcomb.mat')
load('FWT.mat')

load coast_i_aus.mat
figure
plot(long,lat,'-k')
hold on
cmap=distinguishable_colors(3);
go=.1;
h1=plot(round(dataBRIcomb.hs_longT,2),round(dataBRIcomb.hs_latT,2),'X','Color',cmap(2,:),'MarkerFaceColor',cmap(2,:));
h2=plot(FWT.hs_long,FWT.hs_lat,'o','Color',[go go go],'MarkerFaceColor',cmap(3,:),'MarkerSize',2);
title(' BRIGHT and FIREWATCH Comparison','FontSize',30)
legend([h1,h2],{'BRIGHT','Firewatch'})
xlim([min(dataBRIcomb.hs_longT)-3 max(dataBRIcomb.hs_longT)+3])
ylim([min(dataBRIcomb.hs_lat)-3 max(dataBRIcomb.hs_lat)+3])
set(gcf, 'Position', get(0, 'Screensize'))cd
ratiofix
%saveas(gcf,'figures/RMIT_FIREWATCH_all.png')