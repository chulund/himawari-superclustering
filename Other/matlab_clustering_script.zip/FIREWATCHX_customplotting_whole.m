clc;clear
load('D:\Research\2020\Hotspot\persistence\clustering_FIREWATCH\matfile\FIREWATCH_all_clean.mat')
k=find(hs_lat>-10.5);
hs_long(k)=[];hs_lat(k)=[];
load coast_i_aus.mat
figure
%subplot(2,1,1)
plot(long,lat,'-k')
hold on
plot(hs_long,hs_lat,'o','MarkerSize',2.5,...
    'MarkerEdgeColor',[0.2 0.2 0.2],...
    'MarkerFaceColor','green')
rectangle('Position',[148.568011911822 -37.6863409504583 0.410358974086989 0.657522018898803],'EdgeColor','blue','LineWidth',2)
title('FIREWATCH Hotspot detection','FontSize',15)
ratiofix
saveas(gcf,'figures/FIREWATCH_all.png')

figure
%subplot(2,1,2)
plot(long,lat,'-k')
hold on
plot(hs_long,hs_lat,'o','MarkerSize',2.5,...
    'MarkerEdgeColor',[0.2 0.2 0.2],...
    'MarkerFaceColor','green')
xlim([148.568011911822 148.978370885909])
ylim([-37.6863409504583 -37.0288189315595])
ratiofix
saveas(gcf,'figures/FIREWATCH_all_zoom.png')