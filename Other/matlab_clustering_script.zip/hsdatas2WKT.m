%function to convert hs_datas to WKT
%hs_datas=supercluster{1}.hs_datas;
function S=hsdatas2WKT(hs_datas)
%beginning
S=sprintf('MultiPoint(');
for i=1:length(hs_datas)
    for j=1:length(hs_datas{i}.hs_long)
        S=sprintf('%s(%f %f),',S,hs_datas{i}.hs_long(j),hs_datas{i}.hs_lat(j));
    end
end
%remove comma from the last point
S=S(1:end-1);
%ending
S=sprintf('%s)',S);
end