%comparing daily AHIFSA hotspot and FIREWATCH hotspot
%update 13 May 2020 : add pixel number converter

clc;clear;
%load daily data
if ~exist('FSAd.mat')
    FSAd=load('..\clustering_AHIFSA\matfile\AHIFSA_aus_daily.mat');
    save FSAd FSAd
else
    load('FSAd.mat')
end
if ~exist('FWTd.mat')
    FWTd=load('..\clustering_FIREWATCH\matfile\FIREWATCH_aus_daily.mat');
    save FWTd FWTd
else
    load('FWTd.mat')
end

%specify date to compare
date2comp='11-Apr-2019';

%find data
for j=1:length(FSAd.dailydata)
    if strcmp(FSAd.dailydata{j}.date,date2comp)
        dataFSA=FSAd.dailydata{j};
        %%{
        %convert hx hy pixel number to long lat
        hx=dataFSA.hs_hx+1; %add 1 pixel to the right
        hy=dataFSA.hs_hy+1;%add 1 pixel to the bottom
        load('D:\Research\2020\Hotspot\persistence\compare2\nativeVSnearest\gdal\lookuptable.mat');
        long_out=zeros(size(hx));
        lat_out=zeros(size(hy));
        h=waitbar(0,'please wait');
        counter=1;
        doubleInc=0;
        for i=1:length(hx)
            waitbar(i/length(hx),h,sprintf('%.2f%%',i*100/length(hx)));
            k1=find(A1(:,:,1)==hx(i)); %find occurences in row
            k2=find(A2(:,:,1)==hy(i)); %find occurences in col
            [k,~,~]=intersect(k1,k2); %find intersection in occ.
            if ~isempty(k)
                [I,J]=ind2sub(size(A1),k); %convert found indices into matrix index
                if length(I)>1
                    doubleInc=doubleInc+1;
                end
                for z=1:length(I)
                    long_out(counter)=lon(I(z),J(z));
                    lat_out(counter)=lat(I(z),J(z));
                    counter=counter+1;
                end
            else
                long_out(counter)=NaN;
                lat_out(counter)=NaN;
                counter=counter+1;
            end
        end
        close(h)
        dataFSA.hs_longT=long_out;
        dataFSA.hs_latT=lat_out;
        break
        %}
    end
end

for i=1:length(FWTd.dailydata)
    if strcmp(FWTd.dailydata{i}.date,date2comp)
        dataFWT=FWTd.dailydata{i};
        break
    end
end


%cut FWT data to only shows the extent of NSW and VIC
save4cut=[];counter=1;
%k=find(dataFWT.hs_long<140.9987378 | dataFSA.hs_lat>-28.9991148);
for i=1:length(dataFWT.hs_long)
    if (dataFWT.hs_long(i)<140.9987378) | (dataFWT.hs_lat(i)>-28.9991148)
        save4cut(counter)=i;
        counter=counter+1;
    end
end
dataFWT.hs_id(save4cut)=[];
dataFWT.hs_long(save4cut)=[];
dataFWT.hs_lat(save4cut)=[];
dataFWT.hs_temp(save4cut)=[];
dataFWT.hs_time(save4cut)=[];

save dataFSA
save dataFWT



