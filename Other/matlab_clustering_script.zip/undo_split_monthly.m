%script to undo moving files
clc;clear
rootdir = 'D:\Research\2020\Hotspot\persistence\data\WFABBA_YEAR\hotspot_split\result\daily\WFABBA';
filelist = dir(fullfile(rootdir, '**\*.*'));  %get list of files and folders in any subfolder
filelist = filelist(~[filelist.isdir]);  %remove folders from list

for i=1:length(filelist)
    movefile(sprintf('%s\\%s',filelist(i).folder,filelist(i).name),'D:\Research\2020\Hotspot\persistence\data\WFABBA_YEAR\hotspot_split\result\daily');
end
    
