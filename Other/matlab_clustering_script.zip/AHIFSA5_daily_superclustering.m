%script to supercluster the dailydata cluster
clc;clear;
load('matfile/AHIFSA_aus_daily_cluster.mat')

% re-checking clusters in a day
fprintf('superclustering daily\n');
supercluster={};
for i=1:length(dailyaggregate)
    if isempty(dailyaggregate{i})%to prevent processing empty field
        fprintf('   warning data day %i empty\n',i)
        continue
    end    

    fprintf('   processing day %i out of %i\n',i,length(dailyaggregate));
    
    %finding intersection between clusters in a day
    cor=zeros(length(dailyaggregate{i}.clusters),length(dailyaggregate{i}.clusters));
    for j=1:length(cor)
        for k=1:length(cor)
            polyout=intersect(dailyaggregate{i}.clusters{j}.circle,dailyaggregate{i}.clusters{k}.circle);
            if ~isempty(polyout.Vertices)
                cor(j,k)=1;
            end
        end
    end
    %spatial superclusters
    cor_check=cor;

    counter2=1; % for each cluster
    aggregate=[];
    for j=1:length(cor_check)
        cor_process=cor_check(j,:);
        if sum(cor_process)==0
            continue
        end
        
        %remove self correlation
        cor_check(j,j)=0;
        
        member=[];
        looping=[];
        counter=1;
        member(counter)=j;
        cor_check(j,:)=0;

        index=find(cor_process);
        if isempty(index)
            aggregate{counter2}=member;
            counter2=counter2+1;
        end

        looping=[looping;index'];
        while ~isempty(looping)

            counter=counter+1;
            member(counter)=looping(1,1);

            index=find(cor_check(looping(1,1),:));        
            if ~isempty(index)
                looping=[looping;index'];
            end
            %remove visited row
            cor_check(looping(1,1),:)=0;
            looping(1)=[];

        end
        aggregate{counter2}=unique(member);
        counter2=counter2+1;

    end

    %creating daily supercluster structure
    for j=1:length(aggregate)
        if length(aggregate{j})==1 %still a cluster
            dailysupercluster{i}.clusters{j}.id=dailyaggregate{i}.clusters{aggregate{j}}.id;
            dailysupercluster{i}.clusters{j}.startend=dailyaggregate{i}.clusters{aggregate{j}}.startend;
            dailysupercluster{i}.clusters{j}.numHS=dailyaggregate{i}.clusters{aggregate{j}}.numHS;
            dailysupercluster{i}.clusters{j}.circle=dailyaggregate{i}.clusters{aggregate{j}}.circle;
            dailysupercluster{i}.clusters{j}.hs_data=dailyaggregate{i}.clusters{aggregate{j}}.hs_data;
        else %super cluster
            %supercluster id
            dailysupercluster{i}.clusters{j}.id=sprintf('SC');
            %supercluster cluster number
            dailysupercluster{i}.clusters{j}.clusternum=length(aggregate{j});
            %declare supercluster start and endtime
            dailysupercluster{i}.clusters{j}.startend=[0 0];
            %declare supercluster number of hotspot
            dailysupercluster{i}.clusters{j}.numHS=0;
            %declare supercluter cluster's id
            dailysupercluster{i}.clusters{j}.clusterid=[];
            %declare new supercluster circle
            newcircle=polyshape;
            for k=1:length(aggregate{j})
                newcircle = union(newcircle, dailyaggregate{i}.clusters{aggregate{j}(k)}.circle);
                %update supercluster endtime
                if (dailysupercluster{i}.clusters{j}.startend(1)==0)|(dailysupercluster{i}.clusters{j}.startend(1)>dailyaggregate{i}.clusters{aggregate{j}(k)}.startend(1));
                   dailysupercluster{i}.clusters{j}.startend(1)=dailyaggregate{i}.clusters{aggregate{j}(k)}.startend(1);
                end
                if dailysupercluster{i}.clusters{j}.startend(2)<dailyaggregate{i}.clusters{aggregate{j}(k)}.startend(2);
                   dailysupercluster{i}.clusters{j}.startend(2)=dailyaggregate{i}.clusters{aggregate{j}(k)}.startend(2);
                end
                %update supercluster hsnumber
                dailysupercluster{i}.clusters{j}.numHS=dailysupercluster{i}.clusters{j}.numHS+dailyaggregate{i}.clusters{aggregate{j}(k)}.numHS;
                %add supercluster hs data  
                dailysupercluster{i}.clusters{j}.hs_datas{k}=dailyaggregate{i}.clusters{aggregate{j}(k)}.hs_data;
                %add cluster id 
                dailysupercluster{i}.clusters{j}.clusterid{length(dailysupercluster{i}.clusters{j}.clusterid)+1}=dailyaggregate{i}.clusters{aggregate{j}(k)}.id;
            end
            %update circle
            dailysupercluster{i}.clusters{j}.circle=newcircle;
        end
    end
end

save matfile/AHIFSA_aus_dailysupercluster.mat dailysupercluster