%produce fileoutput, run after customplotting2
fid=fopen('fileout/HStime_3.csv','w');
for i=1:length(timeS)
    %fprintf(fid,'%s\n',datestr(timeS(i),'DD/mm/YYYY HH:MM:SS'));
    fprintf(fid,'%s\n',(timeS(i)-737827)*1000000000);
end
fclose(fid)

return
clc;clear;
%import summarize
a=load('fileout/HStime_Statistics_3.csv');
time=a(:,2)/1000000000+737827;
frequency=a(:,3);
plot(time,frequency,'x')
title('Fire Intensity of Fire Cluster 3')
xlabel('Date/Time')
ylabel('Number of Hotspots')