%persistence
load('sentinel_19-02-2020.csv.mat')
data_size=size(data);


%convert dms to degrees for long and lat
for i=1:data_size(1)
    %convert long
    long=data{i,1};
    Key1 = "�";
    Key2 = "'";
    Key3 = '"';
    Index1 = strfind(long, Key1);
    Index2 = strfind(long, Key2);
    Index3 = strfind(long, Key3);
    longd(i)=str2double(long(1:Index1-1))+str2double(long(Index1+1:Index2-1))/60+str2double(long(Index2+1:Index3-1))/3600;
    if long(end)=="W"
        longd=-longd
    end
    %convert lat
    lat=data{i,2};
    Key1 = "�";
    Key2 = "'";
    Key3 = '"';
    Index1 = strfind(lat, Key1);
    Index2 = strfind(lat, Key2);
    Index3 = strfind(lat, Key3);
    latd(i)=str2double(lat(1:Index1-1))+str2double(lat(Index1+1:Index2-1))/60+str2double(lat(Index2+1:Index3-1))/3600;
    if lat(end)=="S"
        latd=-latd;
    end
end

%Sentinel Header
%LONGITUDE LATITUDE KML_FOLDER,australian_state,confidence,
... datetime,filename,hours_since_hotspot,id,latitude,load_dt,
... longitude,orbit,power,process_algorithm,process_algorithm_version,
... process_dt,product,satellite,satellite_nssdc_id, 
... satellite_operating_agency,sensor,start_dt,stop_dt,temp_kelvin