%comparing AHIDEA hotspot and FIREWATCH hotspot
clc;clear;
%load data
if ~exist('DEA.mat')
    DEA=load('..\clustering_AHIDEA\matfile\AHIDEA_aus_clean.mat');
    addendum=-10 ; %hour
    DEA.hs_time=DEA.hs_time+datenum([0 0 0 addendum 0 0]);
    save DEA DEA
else
    load('DEA.mat')
end
if ~exist('FWT.mat')
    FWT=load('..\clustering_FIREWATCH\matfile\FIREWATCH_aus_clean.mat');
    %manipulate time
    addendum=0 ; %hour
    FWT.hs_time=FWT.hs_time+datenum([0 0 0 addendum 0 0]);
    save FWT FWT
else
    load('FWT.mat')
end

%exclude some date
deletedate=1;
if deletedate
    date2delete=datenum([2020 02 01]);
    k=find(date2delete==floor(DEA.hs_time));
    DEA.hs_time(k)=[];
    DEA.hs_long(k)=[];
    DEA.hs_lat(k)=[];
    DEA.hs_temp(k)=[];
    k=find(date2delete==floor(FWT.hs_time));
    FWT.hs_time(k)=[];
    FWT.hs_long(k)=[];
    FWT.hs_lat(k)=[];
    FWT.hs_temp(k)=[];
end

%figuring out number of HS per day
datestart=datenum([2020 02 01]);
dateend=datenum([2020 02 29]);
datefull=datestart:dateend;
number=zeros(length(datefull),2);
for i=1:length(datefull)
    k1=find(datefull(i)==floor(DEA.hs_time));
    number(i,1)=length(k1);
    k2=find(datefull(i)==floor(FWT.hs_time));
    number(i,2)=length(k2);
end


%AHIDEA as variable, FIREWATCH as reference
%finding matching hotspot (True Positive) and false positive
count_TP=1;count_FP=1;
h=waitbar(0,'please wait');
for i=1:length(DEA.hs_long)
    waitbar(i/length(DEA.hs_long),h,sprintf('First Phase: %.2f%%',i/length(DEA.hs_long)*100));
    agreement=zeros(length(FWT.hs_long),3);
    agreement(:,1)=((DEA.hs_long(i))==(FWT.hs_long));
    agreement(:,2)=((DEA.hs_lat(i))==(FWT.hs_lat));
    agreement(:,3)=((DEA.hs_time(i))==(FWT.hs_time));
    k=find(sum(agreement,2)==3);
    if sum(k)>0
        DEA_TP.hs_long(count_TP)=DEA.hs_long(i);
        DEA_TP.hs_lat(count_TP)=DEA.hs_lat(i);
        DEA_TP.hs_time(count_TP)=DEA.hs_time(i);
        count_TP=count_TP+1;   
    else
        DEA_FP.hs_long(count_FP)=DEA.hs_long(i);
        DEA_FP.hs_lat(count_FP)=DEA.hs_lat(i);
        DEA_FP.hs_time(count_FP)=DEA.hs_time(i);
        count_FP=count_FP+1;
    end       
end
fprintf('FWT as REFERENCE\n')
fprintf('number of DEA TP = %i\n',length(DEA_TP.hs_long))
fprintf('number of DEA FP = %i\n',length(DEA_FP.hs_long))
close(h)
if ~exist(DEA_TP)
    fprintf('No Match found\n')
    return
end
%FIREWATCH as variable, AHIDEA as reference
%finding matching hotspot (True Positive) and false positive
count_TP=1;count_FP=1;
h=waitbar(0,'please wait');
for i=1:length(FWT.hs_long)
    waitbar(i/length(FWT.hs_long),h,sprintf('Second Phase: %.2f%%',i/length(FWT.hs_long)*100));
    agreement=zeros(length(DEA.hs_long),3);
    agreement(:,1)=((FWT.hs_long(i))==(DEA.hs_long));
    agreement(:,2)=((FWT.hs_lat(i))==(DEA.hs_lat));
    agreement(:,3)=((FWT.hs_time(i))==(DEA.hs_time));
    k=find(sum(agreement,2)==3);
    if sum(k)>0
        FWT_TP.hs_long(count_TP)=FWT.hs_long(i);
        FWT_TP.hs_lat(count_TP)=FWT.hs_lat(i);
        FWT_TP.hs_time(count_TP)=FWT.hs_time(i);
        count_TP=count_TP+1;   
    else
        FWT_FP.hs_long(count_FP)=FWT.hs_long(i);
        FWT_FP.hs_lat(count_FP)=FWT.hs_lat(i);
        FWT_FP.hs_time(count_FP)=FWT.hs_time(i);
        count_FP=count_FP+1;
    end       
end
close(h)
fprintf('DEA as REFERENCE\n')
fprintf('number of FWT TP = %i\n',length(FWT_TP.hs_long))
fprintf('number of FWT FP = %i\n',length(FWT_FP.hs_long))
fprintf('TOTAL\n')
fprintf('total DEA hotspot= %i\n',length(DEA.hs_long))
fprintf('total FIREWATCH hotspot = %i\n',length(FWT.hs_long))
fprintf('total ALL hotpost = %i\n',length(DEA_TP.hs_long)+length(DEA_FP.hs_long)+length(FWT_FP.hs_long))

%plot
load coast_i_aus.mat
figure
plot(long,lat,'-k')
hold on
cmap=distinguishable_colors(3);
go=.2;
h3=plot(FWT_FP.hs_long,FWT_FP.hs_lat,'o','Color',[go go go],'MarkerFaceColor',cmap(3,:));
h2=plot(DEA_FP.hs_long,DEA_FP.hs_lat,'o','Color',[go go go],'MarkerFaceColor',cmap(2,:));
h1=plot(DEA_TP.hs_long,DEA_TP.hs_lat,'o','Color',[go go go],'MarkerFaceColor',cmap(1,:));
title(' WF-ABBA and FIREWATCH Comparison','FontSize',30)
legend([h1,h2,h3],{'Agreement','WF-ABBA only','Firewatch only'})
set(gcf, 'Position', get(0, 'Screensize'));
xlimit=xlim;ylimit=ylim;
pbaspect([xlimit(2)-xlimit(1) ylimit(2)-ylimit(1) 1])
saveas(gcf,'AHIDEA-FIREWATCH.eps')
return
%=========================================================================
%FASTER ALGORITHM BELOW, BUT ONLY COUNT AGREEMENT   
%=========================================================================
%AHIDEA as variable, FIREWATCH as reference
%finding matching hotspot (True Positive) and false positive
count_TP=1;
for i=1:length(DEA.hs_long)
    long_agreement=find((FWT.hs_long)==(DEA.hs_long(i)));
    if sum(long_agreement)>0
        for j=1:length(long_agreement)
            if (FWT.hs_lat(long_agreement(j))==DEA.hs_lat(i))&&(FWT.hs_time(long_agreement(j))==DEA.hs_time(i))
                DEA_TP.hs_long(count_TP)=DEA.hs_long(i);
                DEA_TP.hs_lat(count_TP)=DEA.hs_lat(i);
                DEA_TP.hs_time(count_TP)=DEA.hs_time(i);
                count_TP=count_TP+1;
                break
            end
        end
    end
end

fprintf('FWT as REFERENCE\n')
fprintf('number of DEA TP = %i\n',length(DEA_TP.hs_long))

%AHIDEA as variable, FIREWATCH as reference
%finding matching hotspot (True Positive) and false positive
count_TP=1;
for i=1:length(FWT.hs_long)
    long_agreement=find((DEA.hs_long)==(FWT.hs_long(i)));
    if sum(long_agreement)>0
        for j=1:length(long_agreement)
            if (DEA.hs_lat(long_agreement(j))==FWT.hs_lat(i))&&(DEA.hs_time(long_agreement(j))==FWT.hs_time(i))
                FWT_TP.hs_long(count_TP)=FWT.hs_long(i);
                FWT_TP.hs_lat(count_TP)=FWT.hs_lat(i);
                FWT_TP.hs_time(count_TP)=FWT.hs_time(i);
                count_TP=count_TP+1;
                break
            end
        end
    end
end

fprintf('DEA as REFERENCE\n')
fprintf('number of FWT TP = %i\n',length(FWT_TP.hs_long))

