%script to write supercluster data to file (only shapes)
clc;clear

load('matfile/AHIFSA_aus_supercluster_att.mat')

fid=fopen('fileout/AHIFSA_aus_supercluster_WKT.csv','w');
SC_count=0;
for i=1:length(supercluster)
    if strcmp(supercluster{i}.id,'SC')
        %write WKT supercluster
        S=polyshape2WKT(supercluster{i}.circle);
        fprintf(fid,'%s\n',S);
    else
        %write WKT supercluster
        S=polyshape2WKT(supercluster{i}.circle);
        fprintf(fid,'%s\n',S);

    end
end
fclose(fid);