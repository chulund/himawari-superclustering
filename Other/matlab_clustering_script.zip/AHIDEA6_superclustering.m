%script to supercluster the daily supercluster
clc;clear;close('all');
load('matfile/AHIDEA_aus_dailysupercluster.mat')
tic
%difference in day threshold (in day)
threshold=3;

%plotting each day
plotting=0;

fprintf('superclustering daily superclusterdata\n')
%checking the superclusters day by day
supercluster=dailysupercluster{1}.clusters;
for i=2:length(dailysupercluster)
    if isempty(dailysupercluster{i})%to prevent processing empty field
        fprintf('   warning data day %i empty\n',i)
        continue
    end

    fprintf('   processing day %i out of %i\n',i,length(dailysupercluster));
    %finding intersection between supercluster and next day
    cluster2check=dailysupercluster{i}.clusters;
    cor=zeros(length(supercluster),length(cluster2check));
    for j=1:length(supercluster)
        for k=1:length(cluster2check)
            %check if there's intersection and day difference < threshold
            polyout=intersect(supercluster{j}.circle,cluster2check{k}.circle);
            if supercluster{j}.startend(1)>cluster2check{k}.startend(1)&& supercluster{j}.startend(2)<cluster2check{k}.startend(2)
                did=0; % j is inside k
            elseif cluster2check{k}.startend(1)>supercluster{j}.startend(1)&& supercluster{j}.startend(2)>cluster2check{k}.startend(2)
                did=0; % k is inside j
            elseif supercluster{j}.startend(1)<cluster2check{k}.startend(2)&& supercluster{j}.startend(2)>cluster2check{k}.startend(1)
                did=0; % j intersect k, j precede
            elseif cluster2check{k}.startend(1)<supercluster{j}.startend(2)&& cluster2check{k}.startend(2)>supercluster{j}.startend(1)
                did=0; % j intersect k, k precede
            elseif cluster2check{k}.startend(1)>supercluster{j}.startend(2)
                did=abs(cluster2check{k}.startend(1)-supercluster{j}.startend(2)); % j & k not intersecting, j precede
            elseif supercluster{j}.startend(1)>cluster2check{k}.startend(2)
                did=abs(supercluster{j}.startend(1)-cluster2check{k}.startend(2)); % j & k not intersecting, k precede
            else
                did=[];                
            end
            if ~isempty(polyout.Vertices)&&(did<=threshold)
                cor(j,k)=1;
            end
        end
    end
    
    visitedcheck=[];
    visitcounter=0;
    
    %joining the rest into supercluster
    for j=1:length(supercluster)
        %joining matching clusters
        if sum(cor(j,:))>0
            tru=find(cor(j,:));
            %check if the cluster2check ever been visited
            cont=0;
            saved=[];
            for k=1:length(tru)
                if visitcounter>0
                    if sum(tru(k)==visitedcheck(:,1))>=1
                        cont=cont+1;
                        saved(cont)=k;                        
                    end
                end
            end
            if cont
                tru(saved)=[];
            end
            if isempty(tru)
                continue
            end            
            
            %update cluster id into supercluster
            if ~isfield(supercluster{j},'clusterid')
                supercluster{j}.clusterid{1}=supercluster{j}.id;
            end
            supercluster{j}.id=sprintf('SC');
            %declare new supercluster circle
            newcircle=supercluster{j}.circle;
            %update supercluster hs data
            if ~isfield(supercluster{j},'hs_datas')
                supercluster{j}.hs_datas{1}=supercluster{j}.hs_data;
                supercluster{j}=rmfield(supercluster{j},'hs_data');
            end
            %create new field clusternum
            if ~isfield(supercluster{j},'clusternum')
                supercluster{j}.clusternum=1;
            end

            for k=1:length(tru)
                %store visitation
                visitcounter=visitcounter+1;
                visitedcheck(visitcounter,1)=tru(k);
                visitedcheck(visitcounter,2)=j;
                
                newcircle = union(newcircle, cluster2check{tru(k)}.circle);
                %update supercluster endtime
                if supercluster{j}.startend(2)<cluster2check{tru(k)}.startend(2)
                   supercluster{j}.startend(2)=cluster2check{tru(k)}.startend(2);
                end
                %update supercluster hsnumber
                supercluster{j}.numHS=supercluster{j}.numHS+cluster2check{tru(k)}.numHS;
                %add supercluster hs data and cluster id and cluster num
                if strcmp(cluster2check{tru(k)}.id,'SC')
                    for m=1:length(cluster2check{tru(k)}.hs_datas)
                         supercluster{j}.hs_datas{1+length(supercluster{j}.hs_datas)}=cluster2check{tru(k)}.hs_datas{m};
                    end
                    for m=1:length(cluster2check{tru(k)}.clusterid)
                        supercluster{j}.clusterid{1+length(supercluster{j}.clusterid)}=cluster2check{tru(k)}.clusterid{m};
                    end
                    supercluster{j}.clusternum=supercluster{j}.clusternum+cluster2check{tru(k)}.clusternum;
                else
                    supercluster{j}.hs_datas{1+length(supercluster{j}.hs_datas)}=cluster2check{tru(k)}.hs_data;
                    supercluster{j}.clusterid{length(supercluster{j}.clusterid)+1}=cluster2check{tru(k)}.id;
                    supercluster{j}.clusternum=supercluster{j}.clusternum+1;
                end                
            end
            %update circle
            supercluster{j}.circle=newcircle;
            %add new attributes counter or add 1 to counter
            if ~isfield(supercluster{j},'updcounter')
                supercluster{j}.updcounter=1;
            else
                supercluster{j}.updcounter=supercluster{j}.updcounter+1;
            end
        end
    end
    %add unmatched to supercluster variable
    counter=length(supercluster);
    
    for j=1:length(cluster2check) 
        if sum(cor(:,j))>0
            %fprintf('\ngoes here in %i at %i',j,i)
            continue
        end
        if strcmp(cluster2check{j}.id,'SC')
            supercluster{counter+1}.id=cluster2check{j}.id;
            supercluster{counter+1}.startend=cluster2check{j}.startend;
            supercluster{counter+1}.numHS=cluster2check{j}.numHS;
            supercluster{counter+1}.circle=cluster2check{j}.circle;
            supercluster{counter+1}.hs_datas=cluster2check{j}.hs_datas;
            supercluster{counter+1}.clusterid=cluster2check{j}.clusterid;
            supercluster{counter+1}.clusternum=cluster2check{j}.clusternum;
        else
            supercluster{counter+1}.id=cluster2check{j}.id;
            supercluster{counter+1}.startend=cluster2check{j}.startend;
            supercluster{counter+1}.numHS=cluster2check{j}.numHS;
            supercluster{counter+1}.circle=cluster2check{j}.circle;
            supercluster{counter+1}.hs_data=cluster2check{j}.hs_data;
        end
        counter=counter+1;
    end
    if exist('tru')
        clear tru;
    end
    
    %=====================================================================%
    %START OF JANKY HACK 
    %rechecking intersection between supercluster
    %finding intersection between clusters in a day
    cor=zeros(length(supercluster),length(supercluster));
    for j=1:length(cor)
        for k=1:length(cor)
            %intersection
            polyout=intersect(supercluster{j}.circle,supercluster{k}.circle);
            %difference in day
            if supercluster{j}.startend(1)>supercluster{k}.startend(1)&& supercluster{j}.startend(2)<supercluster{k}.startend(2)
                did=0; % j is inside k
            elseif supercluster{k}.startend(1)>supercluster{j}.startend(1)&& supercluster{j}.startend(2)>supercluster{k}.startend(2)
                did=0; % k is inside j
            elseif supercluster{j}.startend(1)<supercluster{k}.startend(2)&& supercluster{j}.startend(2)>supercluster{k}.startend(1)
                did=0; % j intersect k, j precede
            elseif supercluster{k}.startend(1)<supercluster{j}.startend(2)&& supercluster{k}.startend(2)>supercluster{j}.startend(1)
                did=0; % j intersect k, k precede
            elseif supercluster{k}.startend(1)>supercluster{j}.startend(2)
                did=abs(supercluster{k}.startend(1)-supercluster{j}.startend(2)); % j & k not intersecting, j precede
            elseif supercluster{j}.startend(1)>supercluster{k}.startend(2)
                did=abs(supercluster{j}.startend(1)-supercluster{k}.startend(2)); % j & k not intersecting, k precede
            elseif sum(supercluster{j}.startend==supercluster{k}.startend)==2
                did=0; % j == k 
            else
                did=[];                
            end
            if ~isempty(polyout.Vertices)&&(did<=threshold)
                cor(j,k)=1;
            end          
        end
    end
    %spatial superclusters
    cor_check=cor;

    counter2=1; % for each cluster
    aggregate=[];
    for j=1:length(cor_check)
        cor_process=cor_check(j,:);
        if sum(cor_process)==0
            continue
        end
        
        %remove self correlation
        cor_check(j,j)=0;
        
        member=[];
        looping=[];
        counter3=1;
        member(counter3)=j;
        cor_check(j,:)=0;

        index=find(cor_process);
        if isempty(index)
            aggregate{counter2}=member;
            counter2=counter2+1;
        end

        looping=[looping;index'];
        while ~isempty(looping)

            counter3=counter3+1;
            member(counter3)=looping(1,1);

            index=find(cor_check(looping(1,1),:));        
            if ~isempty(index)
                looping=[looping;index'];
            end
            %remove visited row
            cor_check(looping(1,1),:)=0;
            looping(1)=[];

        end
        aggregate{counter2}=unique(member);
        counter2=counter2+1;

    end
    
    %creating new supercluster variable
    superclusterold=supercluster;
    supercluster={};
    for j=1:length(aggregate)
        if length(aggregate{j})==1
            supercluster{aggregate{j}}=superclusterold{aggregate{j}};
        else
            %combining instersecting supercluster
            nextSCcounter=length(supercluster)+1;
            supercluster{nextSCcounter}=superclusterold{aggregate{j}(1)};
            %update cluster id into supercluster
            if ~isfield(supercluster{nextSCcounter},'clusterid')
                supercluster{nextSCcounter}.clusterid{1}=supercluster{nextSCcounter}.id;
            end
            supercluster{nextSCcounter}.id=sprintf('SC');
            %declare new supercluster circle
            newcircle=supercluster{nextSCcounter}.circle;
            %update supercluster hs data
            if ~isfield(supercluster{nextSCcounter},'hs_datas')
                supercluster{nextSCcounter}.hs_datas{1}=supercluster{nextSCcounter}.hs_data;
                supercluster{nextSCcounter}=rmfield(supercluster{nextSCcounter},'hs_data');
            end
            %create new field clusternum
            if ~isfield(supercluster{nextSCcounter},'clusternum')
                supercluster{nextSCcounter}.clusternum=1;
            end
            for k=2:length(aggregate{j})
                newcircle = union(newcircle, superclusterold{aggregate{j}(k)}.circle);
                %update supercluster endtime %%UPDAte THIS
                if supercluster{nextSCcounter}.startend(1)>superclusterold{aggregate{j}(k)}.startend(1)
                   supercluster{nextSCcounter}.startend(1)=superclusterold{aggregate{j}(k)}.startend(1);
                end
                if supercluster{nextSCcounter}.startend(2)<superclusterold{aggregate{j}(k)}.startend(2)
                   supercluster{nextSCcounter}.startend(2)=superclusterold{aggregate{j}(k)}.startend(2);
                end
                %update supercluster hsnumber
                supercluster{nextSCcounter}.numHS=supercluster{j}.numHS+superclusterold{aggregate{j}(k)}.numHS;
                %add supercluster hs data and cluster id and cluster num
                if strcmp(superclusterold{aggregate{j}(k)}.id,'SC')
                    for m=1:length(superclusterold{aggregate{j}(k)}.hs_datas)
                         supercluster{nextSCcounter}.hs_datas{1+length(supercluster{nextSCcounter}.hs_datas)}=superclusterold{aggregate{j}(k)}.hs_datas{m};
                    end
                    for m=1:length(superclusterold{aggregate{j}(k)}.clusterid)
                        supercluster{nextSCcounter}.clusterid{1+length(supercluster{nextSCcounter}.clusterid)}=superclusterold{aggregate{j}(k)}.clusterid{m};
                    end
                    supercluster{nextSCcounter}.clusternum=supercluster{nextSCcounter}.clusternum+superclusterold{aggregate{j}(k)}.clusternum;
                else
                    supercluster{nextSCcounter}.hs_datas{1+length(supercluster{nextSCcounter}.hs_datas)}=superclusterold{aggregate{j}(k)}.hs_data;
                    supercluster{nextSCcounter}.clusterid{length(supercluster{nextSCcounter}.clusterid)+1}=superclusterold{aggregate{j}(k)}.id;
                    supercluster{nextSCcounter}.clusternum=supercluster{nextSCcounter}.clusternum+1;
                end
            end
            %update circle
            supercluster{nextSCcounter}.circle=newcircle;
            %add new attributes counter or add 1 to counter
            if ~isfield(supercluster{nextSCcounter},'updcounter')
                supercluster{nextSCcounter}.updcounter=1;
            else
                supercluster{nextSCcounter}.updcounter=supercluster{nextSCcounter}.updcounter+1;
            end
            
        end
    end
    %END OF JANKY HACK
    %=====================================================================%    
    
    %check and remove empty super cluster
    emptycounter=0;
    emptyvar=[];
    for j=1:length(supercluster)
        if isempty(supercluster{j})
            emptycounter=emptycounter+1;
            emptyvar(emptycounter)=j;
        end
    end
    supercluster(emptyvar)=[];
    
    %plotting
    if plotting
        figure
        load coast_i_aus
        plot(long,lat)
        hold on

        cmap=distinguishable_colors(length(supercluster));
        for j=1:length(supercluster)
            if isempty(supercluster{j})
                continue
            end
            plot(supercluster{j}.circle,'FaceColor',cmap(j,:),'HoleEdgeAlpha',0.1,'FaceAlpha',0.4)
            [x,y]=centroid(supercluster{j}.circle);
            text(x,y,sprintf('%i',j),'Color',cmap(j,:))
        end
        title(sprintf('Super Cluster %s to %s',datestr(floor(supercluster{1}.startend(1))),datestr(floor(supercluster{end}.startend(2)))))
        xlim([117.778902759457 121.21139855943])
        ylim([-34.1418807677157 -31.4721618121808]) 
        saveas(gcf,sprintf('figures/superclustering%02i.png',i-1))
    end

    close(gcf)
end

save matfile/AHIDEA_aus_supercluster.mat supercluster
toc