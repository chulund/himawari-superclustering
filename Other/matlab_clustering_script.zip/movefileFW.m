%move all txt file into 1 folder
clc;clear;
fdir=dir('*');
dirFlag=[fdir.isdir];
subFolders = fdir(dirFlag);
subFolders([1,2,end])=[];
for i=1:length(subFolders)
    movefile([subFolders(i).name,'/*.txt'],['ALL/.']);
end