%% calculating attribute for each supercluster
clc;clear;
load('matfile/AHIDEA_aus_supercluster.mat')
superclusterUTM=supercluster;
for i=1:length(supercluster)
    supercluster{i}.duration=(supercluster{i}.startend(2)-supercluster{i}.startend(1))*24; %in hour
    startend(i,:)=supercluster{i}.startend;
    duration(i)=supercluster{i}.duration;
    xys=[];
    firstlong=supercluster{i}.circle.Vertices(1,1); %determining reference longitude
    for m=1:length(supercluster{i}.circle.Vertices)
        longitude=supercluster{i}.circle.Vertices(m,1);
        latitude=supercluster{i}.circle.Vertices(m,2);
        %xy=ell2utm([latitude;longitude;0],getUTMzone(longitude,'d'),2,'d');
        %xy=ell2utm([latitude;longitude;0],123,2,'d');
        xy=ell2utm([latitude;longitude;0],getUTMzone(firstlong,'d'),2,'d');
        xys(m,1)=xy(1)+500000;xys(m,2)=xy(2)+10000000;                
    end
    superclusterUTM{i}.circle.Vertices=xys;
    supercluster{i}.area=area(superclusterUTM{i}.circle)/1000000; %in km2
    if strcmp(supercluster{i}.id,'SC')       
        for j=1:length(supercluster{i}.hs_datas)
            for m=1:length(supercluster{i}.hs_datas{j}.hs_time)
                supercluster{i}.timeS(counter)=supercluster{i}.hs_datas{j}.hs_time(m);
                counter=counter+1;
            end
            for m=1:length(supercluster{i}.hs_datas{j}.hs_temp)
                supercluster{i}.tempS(counter2)=supercluster{i}.hs_datas{j}.hs_temp(m);
                counter2=counter2+1;
            end
        end
    elseif strcmp(supercluster{i}.id(1:2),'CS')
        counter=1;counter2=1;
        for m=1:length(supercluster{i}.hs_data.hs_time)
            supercluster{i}.timeS(counter)=supercluster{i}.hs_data.hs_time(m);
            counter=counter+1;
        end
        for m=1:length(supercluster{i}.hs_data.hs_temp)
            supercluster{i}.tempS(counter2)=supercluster{i}.hs_data.hs_temp(m);
            counter2=counter2+1;
        end
    end
end

save matfile/AHIDEA_aus_supercluster_att.mat supercluster 