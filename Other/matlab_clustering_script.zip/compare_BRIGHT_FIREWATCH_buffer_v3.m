%compare BRIGHT and FIREWATCH using circle buffer
clc;clear;

%select method
method=1;
%1.buffering

%which hotspot as reference
reference = 2;
%1.FIREWATCH as reference
%2.BRIGHT as reference

%radius of buffer (in km)
buffsize(1)=1.5;
buffsize(2)=buffsize(1)/111;

%part 1 loading data
fprintf('1. loading data\n')

if ~exist('BRI.mat')
    BRI=load('BRIGHT_aus_clean.mat');
    save BRI BRI
else
    load('BRI.mat')
end
if ~exist('FWT.mat')
    FWT=load('FIREWATCH_aus_clean.mat');
    save FWT FWT
else
    load('FWT.mat')
end

dataBRI(:,1)=BRI.hs_time;
dataBRI(:,2)=BRI.hs_long;
dataBRI(:,3)=BRI.hs_lat;

%fix FWT coordinates in souther Australia to match FWT grid

dataFWT(:,1)=FWT.hs_time;
dataFWT(:,2)=FWT.hs_long;
dataFWT(:,3)=FWT.hs_lat;

%remove dataFWT outside of time range
datebegin=737516;
dateendin=737881.993055556;
k=find(dataFWT(:,1)<datebegin);
dataFWT(k,:)=[];
fprintf('removing %i data before %s\n',length(k),datestr(datebegin));
k=find(dataFWT(:,1)>dateendin);
dataFWT(k,:)=[];
fprintf('removing %i data after %s\n',length(k),datestr(dateendin));

% k=find(dataFWT(:,3)<-35);
% dataFWT(k,3)=dataFWT(k,3)+0.01;

fprintf('2. split into epoch\n') %faster mode
if ~exist('dataBRI_epoch_v3.mat','file')
    dataBRI=sortrows(dataBRI,1);
    [uniquetime,~,uniquetimearr]=unique(dataBRI(:,1));
    dataBRI_epoch={};
    h2=waitbar(0,'please wait');
    for i=1:length(uniquetime)
        waitbar(i/length(uniquetime),h2,sprintf('splitting epoch %.2f%%',i*100/length(uniquetime)));
        k=find(uniquetimearr==i);
        dataBRI_epoch{i}.epoch=uniquetime(i);
        dataBRI_epoch{i}.time=datestr(uniquetime(i));
        dataBRI_epoch{i}.data(:,1)=dataBRI(k,2);
        dataBRI_epoch{i}.data(:,2)=dataBRI(k,3);
    end
    close(h2)
    save dataBRI_epoch_v3 dataBRI_epoch
else
    load dataBRI_epoch_v3
end
if ~exist('dataFWT_epoch_v3.mat','file')
    dataFWT=sortrows(dataFWT,1);
    [uniquetime,~,uniquetimearr]=unique(dataFWT(:,1));
    dataFWT_epoch={};
    h2=waitbar(0,'please wait');
    for i=1:length(uniquetime)
        waitbar(i/length(uniquetime),h2,sprintf('splitting epoch %.2f%%',i*100/length(uniquetime)));
        k=find(uniquetimearr==i);
        dataFWT_epoch{i}.epoch=uniquetime(i);
        dataFWT_epoch{i}.time=datestr(uniquetime(i));
        dataFWT_epoch{i}.data(:,1)=dataFWT(k,2);
        dataFWT_epoch{i}.data(:,2)=dataFWT(k,3);
    end
    close(h2)
    save dataFWT_epoch_v3 dataFWT_epoch
else
    load dataFWT_epoch_v3
end

fprintf('3. comparing per epoch\n')
%firewatch as reference
if reference==1
    dataFWT=sortrows(dataFWT,1);
    uniquetimeFWT=unique(dataFWT(:,1));
    h=waitbar(0,'calculate unique time');
    uniquetimeFWT=datenum(datestr(uniquetimeFWT));
    counter=1;counter2=1;
    for i=1:length(dataBRI_epoch)
        waitbar(i/length(dataBRI_epoch),h,sprintf('%.2f%%',i*100/length(dataBRI_epoch)))

        %get the data
        j=find(datenum(datestr(dataBRI_epoch{i}.epoch))==uniquetimeFWT);
        BRIcompare=dataBRI_epoch{i}.data;
        if ~isempty(j)
            FWTcompare=dataFWT_epoch{j}.data;
        else
            ukuran=size(dataBRI_epoch{i}.data);
            dataBRI_epoch{i}.matches=zeros(ukuran(1),1);
            continue
        end
        
        %check distance between points
        if 1
            sizeBRI=size(BRIcompare);
            TFin_total=zeros(sizeBRI(1),1);
            sizeFWT=size(FWTcompare);
            for j=1:sizeBRI(1)
                BRIcompare_lat=linspace(BRIcompare(j,2),BRIcompare(j,2),sizeFWT(1));
                BRIcompare_long=linspace(BRIcompare(j,1),BRIcompare(j,1),sizeFWT(1));
                S=vdist(BRIcompare_lat',BRIcompare_long',FWTcompare(:,2),FWTcompare(:,1))./1000;
                k=find(S<buffsize(1));
                if ~isempty(k)
                    TFin_total(j)=1;
                    %fprintf('found matches in %i\n',j)
                end
            end
            dataBRI_epoch{i}.matches=double(TFin_total);
        end
        
        %create buffer and check point in polygon (WARNING: SLOW)
        if 0 %slower but not very accurate
            sizeBRI=size(BRIcompare);
            polyout = polybuffer(FWTcompare,'points',buffsize(2));
            TFin = isinterior(polyout,BRIcompare(:,1),BRIcompare(:,2));
            dataBRI_epoch{i}.matches=double(TFin);
        end
        if 0 %super slow but very accurate
            sizeBRI=size(BRIcompare);
            TFin_total=zeros(sizeBRI(1),1);
            for j=1:sizeBRI(1)
                polyout = polybuffer(BRIcompare(j,:),'points',buffsize(2));
                TFin = isinterior(polyout,FWTcompare(:,1),FWTcompare(:,2));
                if sum(TFin)>0
                    TFin_total(j)=1;
                end                
            end
            dataBRI_epoch{i}.matches=double(TFin_total);
        end
    end
    close(h)
elseif reference==2
    dataBRI=sortrows(dataBRI,1);
    uniquetimeBRI=unique(dataBRI(:,1));
    h=waitbar(0,'calculate unique time');
    uniquetimeBRI=datenum(datestr(uniquetimeBRI));
    counter=1;counter2=1;
    for i=1:length(dataFWT_epoch)
        waitbar(i/length(dataFWT_epoch),h,sprintf('%.2f%%',i*100/length(dataFWT_epoch)))

        %get the data
        j=find(datenum(datestr(dataFWT_epoch{i}.epoch))==uniquetimeBRI);
        FWTcompare=dataFWT_epoch{i}.data;
        if ~isempty(j)
            BRIcompare=dataBRI_epoch{j}.data;
        else
            ukuran=size(dataFWT_epoch{i}.data);
            dataFWT_epoch{i}.matches=zeros(ukuran(1),1);
            continue
        end
        
        %check distance between points
        if 1
            sizeFWT=size(FWTcompare);
            TFin_total=zeros(sizeFWT(1),1);
            sizeBRI=size(BRIcompare);
            for j=1:sizeFWT(1)
                FWTcompare_lat=linspace(FWTcompare(j,2),FWTcompare(j,2),sizeBRI(1));
                FWTcompare_long=linspace(FWTcompare(j,1),FWTcompare(j,1),sizeBRI(1));
                S=vdist(FWTcompare_lat',FWTcompare_long',BRIcompare(:,2),BRIcompare(:,1))./1000;
                k=find(S<buffsize(1));
                if ~isempty(k)
                    TFin_total(j)=1;
                    %fprintf('found matches in %i\n',j)
                end
            end
            dataFWT_epoch{i}.matches=double(TFin_total);
        end
        
        %create buffer and check point in polygon (WARNING: SLOW)
        if 0 %slower but not very accurate
            sizeFWT=size(FWTcompare);
            polyout = polybuffer(BRIcompare,'points',buffsize(2));
            TFin = isinterior(polyout,FWTcompare(:,1),FWTcompare(:,2));
            dataFWT_epoch{i}.matches=double(TFin);
        end
        if 0 %super slow but very accurate
            sizeFWT=size(FWTcompare);
            TFin_total=zeros(sizeFWT(1),1);
            for j=1:sizeFWT(1)
                polyout = polybuffer(FWTcompare(j,:),'points',buffsize(2));
                TFin = isinterior(polyout,BRIcompare(:,1),BRIcompare(:,2));
                if sum(TFin)>0
                    TFin_total(j)=1;
                end                
            end
            dataFWT_epoch{i}.matches=double(TFin_total);
        end
    end
    close(h)
end

fprintf('4. congregating matches \n')

if reference==1
    sumasi_BRI=0;total_BRI=0;
    for i=1:length(dataBRI_epoch)
        sumasi_BRI=sumasi_BRI+sum(dataBRI_epoch{i}.matches);
        total_BRI=total_BRI+length(dataBRI_epoch{i}.matches);
    end
elseif reference==2
    sumasi_FWT=0;total_FWT=0;
    for i=1:length(dataFWT_epoch)
        sumasi_FWT=sumasi_FWT+sum(dataFWT_epoch{i}.matches);
        total_FWT=total_FWT+length(dataFWT_epoch{i}.matches);
    end
end

% %congregate
% matchingtotal=[0,0,0];
% for i=1:length(dataBRI_epoch)
%     sizetotal=size(matchingtotal);
%     sizeplus=size(matching{i}.data);
%     matchingtotal(sizetotal(1)+1:sizeplus(1)+sizetotal(1),1)=matching{i}.date;
%     matchingtotal(sizetotal(1)+1:sizeplus(1)+sizetotal(1),2:3)=matching{i}.data;
%     matchingtotal(sizetotal(1)+1:sizeplus(1)+sizetotal(1),4)=matching{i}.id;
% end
% matchingtotal(1,:)=[];
%sumasi_BRI/total_BRI*100

if reference==1
    save matching_BRI_v3 sumasi_BRI total_BRI dataBRI_epoch
elseif reference==2
    save matching_FWT_v3 sumasi_FWT total_FWT dataFWT_epoch
end

load gong.mat;
sound(y);

return
%% Post analysis

fprintf('plus plus\n')
fprintf('1.5 km\n')
load matching_BRI_v3
fprintf('BRIGHT: %i out of %i (%.2f%%)\n',sumasi_BRI,3810657,sumasi_BRI/3810657*100)
load matching_FWT_v3
fprintf('FIREWATCH: %i out of %i (%.2f%%)\n',sumasi_FWT,total_FWT-60142,sumasi_FWT/(total_FWT-60142)*100)

fprintf('3.0km\n')
load matching_BRI_v3b
fprintf('BRIGHT: %i out of %i (%.2f%%)\n',sumasi_BRI,total_BRI,sumasi_BRI/total_BRI*100)
load matching_FWT_v3b
fprintf('FIREWATCH: %i out of %i (%.2f%%)\n',sumasi_FWT,total_FWT-60142,sumasi_FWT/(total_FWT-60142)*100)

fprintf('plus negatif\n')
fprintf('1.5 km\n')
load matching_BRI_v3
fprintf('BRIGHT: %i out of %i (%.2f%%)\n',3810657-sumasi_BRI,3810657,(3810657-sumasi_BRI)/3810657*100)
load matching_FWT_v3
fprintf('FIREWATCH: %i out of %i (%.2f%%)\n',(total_FWT-60142)-sumasi_FWT,total_FWT-60142,((total_FWT-60142)-sumasi_FWT)/(total_FWT-60142)*100)

fprintf('3.0km\n')
load matching_BRI_v3b
fprintf('BRIGHT: %i out of %i (%.2f%%)\n',total_BRI-sumasi_BRI,total_BRI,(total_BRI-sumasi_BRI)/total_BRI*100)
load matching_FWT_v3b
fprintf('FIREWATCH: %i out of %i (%.2f%%)\n',(total_FWT-60142)-sumasi_FWT,total_FWT-60142,((total_FWT-60142)-sumasi_FWT)/(total_FWT-60142)*100)

load gong.mat;
sound(y);