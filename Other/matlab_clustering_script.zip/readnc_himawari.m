%readnc himawari
clc;clear;
anu=ncinfo('NC_H08_20191108_1050_R21_FLDK.06001_06001.nc');
waktu1=ncread('NC_H08_20191108_1050_R21_FLDK.06001_06001.nc','start_time');
waktu2=ncread('NC_H08_20191108_1050_R21_FLDK.06001_06001.nc','end_time');
longitude=ncread('NC_H08_20191108_1050_R21_FLDK.06001_06001.nc','longitude');
latitude=ncread('NC_H08_20191108_1050_R21_FLDK.06001_06001.nc','latitude');
tbb13=ncread('NC_H08_20191108_1050_R21_FLDK.06001_06001.nc','tbb_13');
%latarr=(linspace(min(latitude),max_latitude,5500));
%lonarr=linspace(59.695419,221.60837,5500);
imagesc(longitude,latitude,tbb13)
set(gca,'YDir','normal')