%readnc himawari
clc;clear;
filename='20191108105000-P1S-ABOM_OBS_B13-PRJ_GEOS141_2000-HIMAWARI8-AHI.nc';
anu=ncinfo(filename);
waktu=ncread(filename,'time');
x=ncread(filename,'x');
y=ncread(filename,'y');
geostationary=ncread(filename,'geostationary');
data=ncread(filename,'channel_0013_brightness_temperature');
latarr=(linspace(-79.623398,79.263672,5500));
lonarr=linspace(59.695419,221.60837,5500);
imagesc(lonarr,latarr,data)
set(gca,'YDir','normal')

