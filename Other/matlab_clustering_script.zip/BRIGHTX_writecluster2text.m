%script to write supercluster data to file (including shapes
clc;clear

load('matfile/BRIGHT_aus_supercluster_att.mat')

fid=fopen('fileout/BRIGHT_aus_supercluster.csv','w');
%fprintf(fid,'fid,supercluster name,time start,time end,no of hotspots,fire duration(hours),fire area(km2),WKT supercluster,WKT hotspot\n');
fprintf(fid,'fid,name,time start,time end,no of hotspots,duration(hours),area(km2)\n');
for i=1:length(supercluster)
    if strcmp(supercluster{i}.id,'SC')
        %if it is supercluster
        %write supercluster id,supercluster name,time start,time end,no of hotspot
        fprintf(fid,'%i,%s,%s,%s,%i,',i-1,supercluster{i}.id,datestr(supercluster{i}.startend(1),'DD-mm-YYYY HH:MM:SS'),datestr(supercluster{i}.startend(2),'DD-mm-YYYY HH:MM:SS'),supercluster{i}.numHS);
        %write fire duration(hours),fire area(km2)
        fprintf(fid,'%.3f,%.3f',supercluster{i}.duration,supercluster{i}.area);
        fprintf(fid,'\n');
    else
        %if it is just a cluster
        %write supercluster id,supercluster name,time start,time end,no of hotspot
        fprintf(fid,'%i,%s,%s,%s,%i,%i,\n',i-1,supercluster{i}.id,datestr(supercluster{i}.startend(1),'DD-mm-YYYY HH:MM:SS'),datestr(supercluster{i}.startend(2),'DD-mm-YYYY HH:MM:SS'),supercluster{i}.numHS);
        %write fire duration(hours),fire area(km2)
        fprintf(fid,'%.3f,%.3f',supercluster{i}.duration,supercluster{i}.area);
        fprintf(fid,'\n');
    end
end
fclose(fid);

fid=fopen('fileout/BRIGHT_aus_supercluster_WKT.csv','w');
SC_count=0;
for i=1:length(supercluster)
    if strcmp(supercluster{i}.id,'SC')
        %write WKT supercluster
        S=polyshape2WKT(supercluster{i}.circle);
        fprintf(fid,'%s\n',S);
    else
        %write WKT supercluster
        S=polyshape2WKT(supercluster{i}.circle);
        fprintf(fid,'%s\n',S);

    end
end

fclose(fid);