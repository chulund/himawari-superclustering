%transform BRIGHT coordinates from HX HY to LONG LAT with new lookup table
%(faster)
clc;clear;
%load aus clean data
if ~exist('BRI.mat')
    BRI=load('BRIGHT_aus_clean.mat');
    save BRI BRI
else
    load('BRI.mat')
end

if 1 % don't forget to redo the lookup table
    % by running the temp.m
end

load BRI_hxhy.mat
load longlatT_noshift.mat

ultimateid=1;
for i=0:38
    fprintf('processing number %2i out of 38\n',i)
    %get the data
    if ~(i==38)
        k=((100000*i)+1):((i+1)*100000);
    else
        k=((100000*i)+1):length(BRI.hs_long);
    end
    dataBRIGHT.hs_long=BRI.hs_long(k);
    dataBRIGHT.hs_lat=BRI.hs_lat(k);
    dataBRIGHT.hs_time=BRI.hs_time(k);
    dataBRIGHT.hs_x=BRI.hs_x(k);
    dataBRIGHT.hs_y=BRI.hs_y(k);
    
    %convert hx hy pixel number to long lat
    hs_hx=dataBRIGHT.hs_x; %add 1 pixel to the right
    hs_hy=dataBRIGHT.hs_y;%add 1 pixel to the bottom
    hs_time=BRI.hs_time(k);
    
    long_out=[];lat_out=[];time_out=[];extras=0;id_out=[];
    h=waitbar(0,'please wait');
    for j=1:length(hs_hx)
        waitbar(j/length(hs_hx),h,sprintf('%.2f%%',j*100/length(hs_hx)));
        %find matching 
        n=find(hs_hx(j)==hx & hs_hy(j)==hy);
        if ~isempty(n)
            counter=length(long_out);
            time_out(counter+1:counter+length(longT{n}))=hs_time(j);
            long_out(counter+1:counter+length(longT{n}))=longT{n};
            lat_out(counter+1:counter+length(longT{n}))=latT{n};
            id_out(counter+1:counter+length(longT{n}))=ultimateid;
            ultimateid=ultimateid+1;
            if ~(length(longT{n})==1)
                extras=extras+length(longT{n})-1;
            end
        else
            fprintf('hs_hx %i is empty\n',j)
        end
    end
    close(h)
    
    dataBRIGHT.id=id_out;
    dataBRIGHT.hs_longT=long_out;
    dataBRIGHT.hs_latT=lat_out;
    dataBRIGHT.hs_timeT=time_out;
    dataBRIGHT.extraCoord=extras;
    
    save(sprintf('fileout/BRIGHT%02i',i),'dataBRIGHT')
end

return

%combine all mat output
clc;clear;
fdir=dir('fileout/*.mat');
%initializing

dataBRIcomb.hs_long=[];
dataBRIcomb.hs_lat=[];
dataBRIcomb.hs_time=[];
dataBRIcomb.hs_x=[];
dataBRIcomb.hs_y=[];
dataBRIcomb.id=[];
dataBRIcomb.hs_longT=[];
dataBRIcomb.hs_latT=[];
dataBRIcomb.hs_timeT=[];
dataBRIcomb.extraCoord=0;

for i=1:length(fdir)
    fprintf(['processing fileout/',fdir(i).name,'\n'])
    load(['fileout/',fdir(i).name])
    %get regular coordinates
    oldLength=length(dataBRIcomb.hs_long);
    newLength=length(dataBRIGHT.hs_long);
    dataBRIcomb.hs_long(oldLength+1:oldLength+newLength)=dataBRIGHT.hs_long(:);
    dataBRIcomb.hs_lat(oldLength+1:oldLength+newLength)=dataBRIGHT.hs_lat(:);
    dataBRIcomb.hs_time(oldLength+1:oldLength+newLength)=dataBRIGHT.hs_time(:);
    dataBRIcomb.hs_x(oldLength+1:oldLength+newLength)=dataBRIGHT.hs_x(:);
    dataBRIcomb.hs_y(oldLength+1:oldLength+newLength)=dataBRIGHT.hs_y(:);
    dataBRIcomb.extraCoord=dataBRIcomb.extraCoord+dataBRIGHT.extraCoord;
    %get transformed coordinates
    oldLength=length(dataBRIcomb.hs_longT);
    newLength=length(dataBRIGHT.hs_longT);
    dataBRIcomb.id(oldLength+1:oldLength+newLength)=dataBRIGHT.id(:);
    dataBRIcomb.hs_longT(oldLength+1:oldLength+newLength)=dataBRIGHT.hs_longT(:);
    dataBRIcomb.hs_latT(oldLength+1:oldLength+newLength)=dataBRIGHT.hs_latT(:);
    dataBRIcomb.hs_timeT(oldLength+1:oldLength+newLength)=dataBRIGHT.hs_timeT(:);
    m=find(isnan(dataBRIGHT.hs_longT));
    msaved(i)=length(m);
    newlengthsaved(i)=length(dataBRIGHT.hs_longT);
    n=find(dataBRIGHT.hs_longT==0);
    fprintf('   therewas %i NaN and %i zeroes\n',length(m),length(n))
end

%remove nan and zeroes
k=find(isnan(dataBRIcomb.hs_longT));
dataBRIcomb.id(k)=[];
dataBRIcomb.hs_longT(k)=[];
dataBRIcomb.hs_latT(k)=[];
dataBRIcomb.hs_timeT(k)=[];
k=find((dataBRIcomb.hs_longT==0));
dataBRIcomb.id(k)=[];
dataBRIcomb.hs_longT(k)=[];
dataBRIcomb.hs_latT(k)=[];
dataBRIcomb.hs_timeT(k)=[];
m=find(isnan(dataBRIcomb.hs_longT));
n=find(dataBRIcomb.hs_longT==0);
fprintf('now there are %i NaN and %i zeroes\n',length(m),length(n))
save dataBRIcomb dataBRIcomb