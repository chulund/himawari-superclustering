%next step after clustering
clc;clear;fclose('all');
load('AHIDEA_daily.mat')
load('AHIDEA_cluster.mat')

%from day 1-29(day 23 empty)
select_day=24;
radius=3500;

%get data
hs_long=dailydata{select_day}.hs_long;
hs_lat=dailydata{select_day}.hs_lat;
hs_time=dailydata{select_day}.hs_time;

if isempty(hs_long)
    return
end

figure
load coast_i
plot(long,lat)
hold on
plot(hs_long,hs_lat,'xr')
if abs(max(hs_long)-min(hs_long))>abs(max(hs_lat)-min(hs_lat))
    range=(max(hs_long)-min(hs_long));
else
    range=(max(hs_lat)-min(hs_lat));
end
xlim([mean(hs_long)-range*.2 mean(hs_long)+range*.2])
ylim([mean(hs_lat)-range*.2 mean(hs_lat)+range*.2])
%xlim([min(hs_long)-(max(hs_long)-min(hs_long))*.2 max(hs_long)+(max(hs_long)-min(hs_long))*.2])
%ylim([min(hs_lat)-(max(hs_lat)-min(hs_lat))*.2 max(hs_lat)+(max(hs_lat)-min(hs_lat))*.2])
title(sprintf('Himawari Hotspot DEA %s',datestr(floor(hs_time(1))))) 

for i=1:length(hs_long)
    text(hs_long(i)-0.01,hs_lat(i)-0.01,sprintf('%i',i));
end

for i=1:length(hs_long)

    %create circle to check radius
    [xv,yv] = createcircle(hs_long(i),hs_lat(i),radius,pi/5);
    plot(xv,yv,'-g')
end

cluster_HS{select_day}
