%function to convert hs_data to WKT
%hs_datas=supercluster{1}.hs_data;
function S=hsdata2WKT(hs_data)
%beginning
S=sprintf('MultiPoint(');
for j=1:length(hs_data.hs_long)
    S=sprintf('%s(%f %f),',S,hs_data.hs_long(j),hs_data.hs_lat(j));
end
%remove comma from the last point
S=S(1:end-1);
%ending
S=sprintf('%s)',S);
end