%function to convert polyshape to WKT polygon
%shapes=supercluster{1}.circle;
function S=polyshape2WKTv2(shapes)
%beginning
S=sprintf('Polygon((');
for i=1:length(shapes.Vertices)
    S=sprintf('%s%f %f,',S,shapes.Vertices(i,:));
end
%remove comma from the last point
S=S(1:end-1);
%ending
S=sprintf('%s))',S);

end