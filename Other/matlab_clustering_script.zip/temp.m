    cor=zeros(length(supercluster),length(supercluster));
    for j=1:length(cor)
        for k=1:length(cor)
            %intersection
            polyout=intersect(supercluster{j}.circle,supercluster{k}.circle);
            %difference in day
            %6 intersection possibilities
            if supercluster{k}.startend(2)>supercluster{j}.startend(2)
                did=abs(supercluster{k}.startend(1)-supercluster{j}.startend(2));
            else
                did=abs(supercluster{j}.startend(1)-supercluster{k}.startend(2));
            end
            if ~isempty(polyout.Vertices)&&(did<=threshold)
                cor(j,k)=1;
            end
            %if self
            if j==k
                cor(j,k)=1;
            end            
        end
    end