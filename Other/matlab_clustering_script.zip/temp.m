for i=1:length(aggregate)
    fprintf('aggregate i:')
    for j=1:length(aggregate{i})
        fprintf('%i ',aggregate{i}(j))
    end
    fprintf('\n')
end
return
counterNumHS=0;
counterdaily(1)=0;
for i=1:length(dailysupercluster)
    counterNumHS=0;
    for j=1:length(dailysupercluster{i}.clusters)
        if strcmp(dailysupercluster{i}.clusters{j}.id,'SC')
            for k=1:length(dailysupercluster{i}.clusters{j}.hs_datas)
                counterNumHS=counterNumHS+length(dailysupercluster{i}.clusters{j}.hs_datas{k}.hs_long);
            end
        else
            counterNumHS=counterNumHS+length(dailysupercluster{i}.clusters{j}.hs_data.hs_long);
        end
    end
    counterdaily(i)=counterNumHS;    
end
return
counterNumHS=0;
for i=1:length(dailysupercluster)
    for j=1:length(dailysupercluster{i}.clusters)
        if strcmp(dailysupercluster{i}.clusters{j}.id,'SC')
            for k=1:length(dailysupercluster{i}.clusters{j}.hs_datas)
                counterNumHS=counterNumHS+length(dailysupercluster{i}.clusters{j}.hs_datas{k}.hs_long);
            end
        else
            counterNumHS=counterNumHS+length(dailysupercluster{i}.clusters{j}.hs_data.hs_long);
        end
    end
end
%result 24294
return


counterNumHS=0;
counterdaily(1)=0;
for i=1:length(dailyaggregate)
    counterNumHS=0;
    for j=1:length(dailyaggregate{i}.clusters)
            counterNumHS=counterNumHS+length(dailyaggregate{i}.clusters{j}.hs_data.hs_long)
    end
    counterdaily(i)=counterNumHS;
end
return
counterNumHS=0;

for i=1:length(dailyaggregate)
    for j=1:length(dailyaggregate{i}.clusters)

            counterNumHS=counterNumHS+length(dailyaggregate{i}.clusters{j}.hs_data.hs_long)
    end
end
%result 24647
return
counterNumHS=0;
for i=1:length(supercluster)
    if strcmp(supercluster{i}.id,'SC')
       for j=1:length(supercluster{i}.hs_datas)
           counterNumHS=counterNumHS+length(supercluster{i}.hs_datas{j}.hs_long);
       end
    else
        counterNumHS=counterNumHS+length(supercluster{i}.hs_data.hs_long);
    end
end