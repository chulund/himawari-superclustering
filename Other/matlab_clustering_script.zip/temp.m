%find unique combination in bot FWT and BRI

clc;clear;
%load aus clean data
if ~exist('BRI.mat')
    BRI=load('BRIGHT_aus_clean.mat');
    save BRI BRI
else
    load('BRI.mat')
end
if ~exist('FWT.mat')
    FWT=load('FIREWATCH_aus_clean.mat');
    save FWT FWT
else
    load('FWT.mat')
end

%finding unique hx hy from BRIGHT datasaset
if ~exist('BRI_unique.mat')
    h=waitbar(0,'please wait');
    for i=1:length(BRI.hs_x)
        waitbar(i/length(BRI.hs_x),h,sprintf('%.2f%%',i*100/length(BRI.hs_x)));
        BRI_table(i,:)=sprintf('%i%i',BRI.hs_x(i),BRI.hs_y(i));
    end
    close(h)
    fprintf('find unique\n')
    BRI_unique=unique(BRI_table,'rows');
else
    load 'BRI_unique.mat'
    %FWT_table=array2table([FWT.hs_long;FWT.hs_lat]);
    %FWT_unique=unique(FWT_table,'rows');
end

%separate unique string back into hx and hy
if ~exist('BRI_hxhy.mat')
    hx=zeros(length(BRI_unique),1);
    hy=zeros(length(BRI_unique),1);
    h=waitbar(0,'please wait');
    for i=1:length(BRI_unique)
        waitbar(i/length(BRI_unique),h,sprintf('%.2f%%',i*100/length(BRI_unique)));
        hx(i,1)=str2double(BRI_unique(i,1:4));
        hy(i,1)=str2double(BRI_unique(i,5:8));
    end
    close(h)
    save BRI_hxhy hx hy
else
    load 'BRI_hxhy.mat'
end

%convert hx hy pixel number to long lat
hx=hx; %add 1 pixel to the right
hy=hy;%add 1 pixel to the bottomc
load('D:\Research\2020\Hotspot\persistence\compare2\nativeVSnearest\gdal\lookuptable.mat');
h=waitbar(0,'please wait');
longT=cell(size(hx));
latT=cell(size(hy));
doubleInc=0;
for i=1:length(hx)
    waitbar(i/length(hx),h,sprintf('%.2f%%',i*100/length(hx)));
    k1=find(A1(:,:,1)==hx(i)); %find occurences in row
    k2=find(A2(:,:,1)==hy(i)); %find occurences in col
    [k,~,~]=intersect(k1,k2); %find intersection in occ.
    counter=1;
    long_out=NaN;
    lat_out=NaN;
    if ~isempty(k)
        [I,J]=ind2sub(size(A1),k); %convert found indices into matrix index
        if length(I)>1
            doubleInc=doubleInc+1;
        end
        for z=1:length(I)
            long_out(counter)=lon(I(z),J(z));
            lat_out(counter)=lat(I(z),J(z));
            counter=counter+1;
        end
    end
    longT{i}=long_out;
    latT{i}=lat_out;
end
close(h)

save all_mat
