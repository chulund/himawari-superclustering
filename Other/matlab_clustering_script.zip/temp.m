clc;clear;
%load data
if ~exist('FSA.mat')
    FSA=load('..\clustering_AHIFSA\matfile\AHIFSA_aus_clean.mat');
    save FSA FSA
else
    load('FSA.mat')
end
if ~exist('FWT.mat')
    FWT=load('..\clustering_FIREWATCH\matfile\FIREWATCH_aus_clean.mat');
    save FWT FWT
else
    load('FWT.mat')
end

%load('FWT_new.mat')

counter=1;
for i=1:length(FSA.hs_long)
    if (FSA.hs_long(i)>150.14)&&(FSA.hs_long(i)<150.26)&&(FSA.hs_lat(i)>-30.44)&&(FSA.hs_lat(i)<-30.34)
        FSA_cut(counter,1)=FSA.hs_long(i);
        FSA_cut(counter,2)=FSA.hs_lat(i);
        FSA_cut(counter,3)=FSA.hs_time(i);
        counter=counter+1;
    end
end

timemin=-8; %in hour
counter=1;
for i=1:length(FWT.hs_long)
    if (FWT.hs_long(i)>150.14)&&(FWT.hs_long(i)<150.26)&&(FWT.hs_lat(i)>-30.44)&&(FWT.hs_lat(i)<-30.34)
        FWT_cut(counter,1)=FWT.hs_long(i);
        FWT_cut(counter,2)=FWT.hs_lat(i);
        FWT_cut(counter,3)=FWT.hs_time(i)-datenum([0 0 0 11 00 0]);
        counter=counter+1;
    end
end

% counter=1;
% for i=1:length(FWTn.hs_long)
%     if (FWTn.hs_long(i)>150.14)&&(FWTn.hs_long(i)<150.26)&&(FWTn.hs_lat(i)>-30.44)&&(FWTn.hs_lat(i)<-30.34)
%         FWTn_cut(counter,1)=FWTn.hs_long(i);
%         FWTn_cut(counter,2)=FWTn.hs_lat(i);
%         FWTn_cut(counter,3)=FWTn.hs_time(i);
%         counter=counter+1;
%     end
% end

waktu1=unique(FWT_cut(:,3));
waktu2=unique(FSA_cut(:,3));
waktu=unique([waktu1;waktu2]);

%look for matching time
matchingtime={};
matchingall={};counter=1;
for i=1:length(waktu)
    k1=find(waktu(i)==FWT_cut(:,3));
    k2=find(waktu(i)==FSA_cut(:,3));
    matchingtime{i}.time=waktu(i);
    if ~isempty(k1)
        matchingtime{i}.FWT=FWT_cut(k1,:);
    end
    if ~isempty(k2)
        matchingtime{i}.FSA=FSA_cut(k2,:);
    end
    if ~isempty(k1)&&~isempty(k2)
        matchingall{counter}.time=waktu(i);
        matchingall{counter}.FWT=FWT_cut(k1,:);
        matchingall{counter}.FSA=FSA_cut(k2,:);
        counter=counter+1;
    end
    
end

load coast_i_aus.mat
figure
plot(long,lat,'-k')
hold on
cmap=distinguishable_colors(4);
skipthis=[0];
if 0 
    for i=1:length(matchingall)
        if sum(i==skipthis)>0
            continue
        end
        h1=plot(matchingall{i}.FWT(1,1),matchingall{i}.FWT(1,2),'o','Color',cmap(1,:),'MarkerFaceColor',cmap(1,:));
        %text(matchingall{i}.FWT(1,1),matchingall{i}.FWT(1,2),sprintf('%i',i))
        h2=plot(matchingall{i}.FSA(1,1),matchingall{i}.FSA(1,2),'o','Color',cmap(2,:),'MarkerFaceColor',cmap(2,:));
        %text(matchingall{i}.FSA(1,1),matchingall{i}.FSA(1,2),sprintf('%i',i))
        %create a line
        h5=line([matchingall{i}.FWT(1,1);matchingall{i}.FSA(1,1)],[matchingall{i}.FWT(1,2);matchingall{i}.FSA(1,2)],'LineStyle','--')
        jarak(i)=vdist(matchingall{i}.FWT(1,2),matchingall{i}.FWT(1,1),matchingall{i}.FSA(1,2),matchingall{i}.FSA(1,1));
    end
end
for i=1:length(FSA_cut)
    h3=plot(FSA_cut(i,1),FSA_cut(i,2),'^','Color',cmap(3,:));
    %text(FSA_cut(i,1),FSA_cut(i,2),sprintf('%i',i),'Color',cmap(1,:))
end
for i=1:length(FWT_cut)
    h4=plot(FWT_cut(i,1),FWT_cut(i,2),'^','Color',cmap(4,:));
    %text(FWT_cut(i,1),FWT_cut(i,2),sprintf('%i',i),'Color',cmap(2,:))
end



legend([h1,h2,h3,h4,h5],{'RMIT match','Firewatch match','RMIT with no match','Firewatch with no match','Same time'})
title(sprintf('Hotspot RMIT vs Firewatch (%ih)',3+timemin))
set(gca,'FontSize',12)
xlim([150.14 150.26])
ylim([-30.44 -30.34])
ratiofix

%put attribute
pos = arrayfun(@plotboxpos, gca, 'uni', 0);
dim = cellfun(@(x) x.*[1 1 0.5 0.5], pos, 'uni',0);
str = {sprintf('Matches = %i hotspots',length(matchingall)),sprintf('Average distance =%.2f meters',mean(jarak))}
annotation('textbox',dim{1},'String',str,'FitBoxToText','on','vert','bottom','EdgeColor','none')
return
saveas(gcf,sprintf('compare%i.png',3+timemin))

return
load coast_i_aus.mat
figure
plot(long,lat,'-k')
hold on
cmap=distinguishable_colors(3);
for i=1:length(FSA_cut)
    h1=plot(FSA_cut(i,1),FSA_cut(i,2),'o','Color',cmap(1,:),'MarkerFaceColor',cmap(1,:));
    %text(FSA_cut(i,1),FSA_cut(i,2),sprintf('%i',i),'Color',cmap(1,:))
end
for i=1:length(FWT_cut)
    h2=plot(FWT_cut(i,1),FWT_cut(i,2),'o','Color',cmap(2,:),'MarkerFaceColor',cmap(2,:));
    %text(FWT_cut(i,1),FWT_cut(i,2),sprintf('%i',i),'Color',cmap(2,:))
end
%h3=plot(FWTn_cut(:,1),FWTn_cut(:,2),'o','Color',cmap(3,:),'MarkerFaceColor',cmap(3,:));
title('Firewatch vs RMIT Hotspot','FontSize',20)
%title('Firewatch GDA94 vs Firewatch GDA2020','FontSize',20)
%legend([h2,h3],{'Firewatch pre transform (GDA94)','Firewatch post transform (GDA2020)'})
%legend([h1,h2,h3],{'RMIT','Firewatch pre transform','Firewatch post transform'})
legend([h1,h2],{'RMIT','Firewatch'})
set(gca,'FontSize',12)
xlim([150.14 150.26])
ylim([-30.44 -30.34])
ratiofix
