%transform coordinate
clc;clear;
data(:,1)=dms2degrees([152	40	4.16;
152	41	20.05;
152	49	29.88;
152	50	46.83]);
data(:,2)=dms2degrees([-31	39	27.68
-31	47	52.53
-31	39	40.63
-31	48	5.58]);