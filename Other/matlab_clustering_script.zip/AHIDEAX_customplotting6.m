%% plotting heat map plus FRP for each hotspot for a super cluster
clc;clear;
load('matfile/AHIDEA_aus_supercluster.mat')

superclusternumber=3;

%calculate supercluster attribute
for i=1:length(supercluster)
    supercluster{i}.duration=(supercluster{i}.startend(2)-supercluster{i}.startend(1))*24;
    startend(i,:)=supercluster{i}.startend;
    duration(i)=supercluster{i}.duration;
end

superclusterUTM=supercluster;
for i=superclusternumber
    for m=1:length(supercluster{i}.circle.Vertices)
        longitude=supercluster{i}.circle.Vertices(m,1);
        latitude=supercluster{i}.circle.Vertices(m,2);
        xy=ell2utm([latitude;longitude;0],getUTMzone(longitude,'d'),2,'d');
        xys(m,1)=xy(1)+500000;xys(m,2)=xy(2)+10000000;                
    end
    superclusterUTM{i}.circle.Vertices=xys;
    supercluster{i}.area=area(superclusterUTM{i}.circle);
end

%get all hotspot member 
counter=1;
for i=superclusternumber
    for j=1:length(supercluster{i}.hs_datas)
        if length(supercluster{i}.hs_datas{j}.hs_long)==1
            hs_datas{counter}.hs_id=supercluster{i}.hs_datas{j}.hs_id;
            hs_datas{counter}.hs_long=supercluster{i}.hs_datas{j}.hs_long;
            hs_datas{counter}.hs_lat=supercluster{i}.hs_datas{j}.hs_lat;
            hs_datas{counter}.hs_temp=supercluster{i}.hs_datas{j}.hs_temp;
            hs_datas{counter}.hs_time=supercluster{i}.hs_datas{j}.hs_time;
            hs_datas{counter}.hs_circle=supercluster{i}.hs_datas{j}.hs_circle;
            counter=counter+1;
        else
            for k=1:length(supercluster{i}.hs_datas{j}.hs_long)
                hs_datas{counter}.hs_id=supercluster{i}.hs_datas{j}.hs_id(k,:);
                hs_datas{counter}.hs_long=supercluster{i}.hs_datas{j}.hs_long(k);
                hs_datas{counter}.hs_lat=supercluster{i}.hs_datas{j}.hs_lat(k);
                hs_datas{counter}.hs_temp=supercluster{i}.hs_datas{j}.hs_temp(k);
                hs_datas{counter}.hs_time=supercluster{i}.hs_datas{j}.hs_time(k);
                hs_datas{counter}.hs_circle=supercluster{i}.hs_datas{j}.hs_circle{k};
                counter=counter+1;
            end
        end
    end
end
    
%grouping based on position

for i=1:length(hs_datas)
    hs_long(i)=hs_datas{i}.hs_long;
    hs_lat(i)=hs_datas{i}.hs_lat;
end

G=findgroups(hs_long,hs_lat);
hs_grouping{max(G)}=[];
for i=1:length(hs_datas)
    hs_grouping{G(i)}{length(hs_grouping{G(i)})+1}=hs_datas{i};
end

%get group attribute
frp_group(max(G),1)=0;
for i=1:length(frp_group)
    frp_total=0;
    for j=1:length(hs_grouping{i})
        %get sum of frp
        frp_total=frp_total+hs_grouping{i}{j}.hs_temp;
    end
    frp_group(i,1)=hs_grouping{i}{1}.hs_long;
    frp_group(i,2)=hs_grouping{i}{1}.hs_lat;
    frp_group(i,3)=frp_total; %frp total
    frp_group(i,4)=length(hs_grouping{i});
    if isa(hs_grouping{i}{1}.hs_circle,'polyshape')
        frp_circle{i}.hs_circle=hs_grouping{i}{1}.hs_circle;
    else
        frp_circle{i}.hs_circle=hs_grouping{i}{1}.hs_circle{1};
    end
end

frp_group(:,5)=normalize(frp_group(:,3),'range');
frp_group(:,6)=normalize(frp_group(:,3)./frp_group(:,4),'range');
                            
figure
load coast_i_aus
plot(long,lat)
hold on
cmap=flipud(brighten(autumn(6),0.2));
if superclusternumber==2
    xlim([118.18800457784 120.766889476392])
    ylim([-33.3592251556771 -31.3534257901363]) 
elseif superclusternumber==3
    xlim([118.98800548836 121.332446305225])
    ylim([-34.0400884654838 -32.2166344968102])
else
    xlim([117.94748836483 120.526373263382])
    ylim([-33.7006864104863 -31.6948870449454])
end
counter=1;counter2=1;
for i=superclusternumber
    plot(supercluster{i}.circle,'FaceColor','none','LineStyle','--')
    for j=1:length(frp_group)
        %plot(frp_circle{j}.hs_circle,'FaceColor',[1-frp_group(j,5) 1 1],'FaceAlpha',1,'LineStyle','none')
        plot(frp_circle{j}.hs_circle,'FaceColor',[1 0 0],'FaceAlpha',frp_group(j,6),'LineStyle','none')
    end    
end

%put attribute
pos = arrayfun(@plotboxpos, gca, 'uni', 0);
dim = cellfun(@(x) x.*[1 1 0.5 0.5], pos, 'uni',0);
str = {sprintf('Duration = %i hours',round(supercluster{superclusternumber}.duration)),
    sprintf('Date = %s to %s',datestr(floor(supercluster{superclusternumber}.startend(1))),datestr(floor(supercluster{superclusternumber}.startend(2)))),
    sprintf('Area = %0.3f km2',supercluster{superclusternumber}.area/1000000)}
annotation('textbox',dim{1},'String',str,'FitBoxToText','on','vert','bottom','EdgeColor','none')

title(sprintf('Hotspot Heatmap Super Cluster %i (Fire Severity MEAN FRP)',superclusternumber))
saveas(gcf,sprintf('figures/Super Cluster %i Hotspot Heatmap + FRP MEAN.png',superclusternumber))

return

%plot number of group vs total FRP
figure
bar(frp_group(:,3))
xlabel('Number of group')
ylabel('Total FRP')
title('Total FRP vs number of group')
%put attribute
pos = arrayfun(@plotboxpos, gca, 'uni', 0);
dim = cellfun(@(x) x.*[1 1 0.5 0.5], pos, 'uni',0);
str = {sprintf('number of group = %i',length(frp_group(:,3))),
    sprintf('minimum FRP = %0.3f',min(frp_group(:,3))),
    sprintf('maximum FRP = %0.3f',max(frp_group(:,3))),
    sprintf('average FRP = %0.3f',mean(frp_group(:,3)./frp_group(:,4)))}
annotation('textbox',dim{1},'String',str,'FitBoxToText','on','vert','bottom','EdgeColor','none')
saveas(gcf,sprintf('figures/FRP Statistics for Super Cluster %i.png',superclusternumber))

return

%plot number of group vs total FRP
figure
bar(frp_group(:,4))
xlabel('Number of group')
ylabel('Number of hotspot')
title('Number of hotspot vs number of group')
%put attribute
pos = arrayfun(@plotboxpos, gca, 'uni', 0);
dim = cellfun(@(x) x.*[1 1 0.5 0.5], pos, 'uni',0);
str = {sprintf('number of group = %i',length(frp_group(:,3))),
    sprintf('minimum FRP = %0.3f',min(frp_group(:,3))),
    sprintf('maximum FRP = %0.3f',max(frp_group(:,3))),
    sprintf('average FRP = %0.3f',mean(frp_group(:,3)./frp_group(:,4)))}
annotation('textbox',dim{1},'String',str,'FitBoxToText','on','vert','bottom','EdgeColor','none')
saveas(gcf,sprintf('figures/FRP Statistics for Super Cluster %i (2).png',superclusternumber))