%plotting, run the previous script first
%plot dailysupercluster
for n=0:length(dailysupercluster)-1
    figure
    load coast_i_aus
    plot(long,lat)
    hold on
    cmap=flipud(autumn(length(dailysupercluster)));
    for i=1:length(dailysupercluster)-n
        for j=1:length(dailysupercluster{i}.clusters)
            %plot(supercluster{j}.circle,'FaceColor',[(1-timeofday) 0.1 0.1],'HoleEdgeAlpha',0.1,'FaceAlpha',0.8,'LineStyle','none')
            plot(dailysupercluster{i}.clusters{j}.circle,'FaceColor',cmap(i,:),'HoleEdgeAlpha',0.1,'FaceAlpha',0.8,'LineStyle','none')
        end
    end
    supercluster=supercluster_steps{i-1};
    for j=1:length(supercluster)
         if isempty(supercluster{j})
            continue
         end
         [x,y]=centroid(supercluster{j}.circle);
         text(x,y,sprintf('%i',j),'Color','black')
         for z=1:length(supercluster)
            superclustercount(z,1:2)=supercluster{z}.startend;
         end
         title(sprintf('Super Cluster %s %s',datestr(floor(supercluster{1}.startend(1))),datestr(max(superclustercount(:,2)),'HH:MM')))
    end

%     xlim([148 150.18])
%     ylim([-38.1 -36.6]) 
%k=find((hs_lat>=-37.4)&(hs_lat<=-36.5)&(hs_long>=146)&(hs_long<=147.7));
    xlim([146.118838806517 148.3])
    ylim([-38.0924940373008 -35.8861147352058]) 
    ratiofix
    saveas(gcf,sprintf('figures/10minutessuperclustering%03i.png',i-1))
    close(gcf)
end
return
%plot supercluster
figure
load coast_i_aus
plot(long,lat)
hold on
for i=length(supercluster_steps):-1:1
    supercluster=supercluster_steps{i};
    cmap=distinguishable_colors(length(supercluster));
    superclustercount=zeros(1,length(supercluster));
    for z=1:length(supercluster)
        superclustercount(z,1:2)=supercluster{z}.startend;
    end
    for j=1:length(supercluster)
        if isempty(supercluster{j})
            continue
        end
        %plot(supercluster{j}.circle,'FaceColor',cmap(j,:),'HoleEdgeAlpha',0.1,'FaceAlpha',0.4)
        timeofday=supercluster{j}.startend(2)-floor(supercluster{j}.startend(2));
        plot(supercluster{j}.circle,'FaceColor',[(1-timeofday) 0.1 0.1],'HoleEdgeAlpha',0.1,'FaceAlpha',0.8,'LineStyle','none')
        [x,y]=centroid(supercluster{j}.circle);
        %check the end cluster number
        if includeanim
            cnumber=0;
            if strcmp(supercluster{j}.id,'SC')
                for a=1:length(superclusternumber)
                    for b=2:length(superclusternumber{a})-1
                        if strcmp(supercluster{j}.clusterid{1},superclusternumber{a}{b})
                            cnumber=str2double(superclusternumber{a}{1});
                            break
                        end
                    end
                end
            else
                for a=1:length(superclusternumber)
                    for b=2:length(superclusternumber{a})-1
                        if strcmp(supercluster{j}.id,superclusternumber{a}{b})
                            cnumber=str2double(superclusternumber{a}{1});
                            break
                        end
                    end
                end
            end
            text(x,y,sprintf('%i',cnumber),'Color',cmap(j,:))
        else
            text(x,y,sprintf('%i',j),'Color','black')
        end
    end
    title(sprintf('Super Cluster %s %s',datestr(floor(supercluster{1}.startend(1))),datestr(max(superclustercount(:,2)),'HH:MM')))
%         xlim([146.118838806517 148.3])
%         ylim([-38.0924940373008 -35.8861147352058]) 
    xlim([148 150.18])
    ylim([-38.1 -36.6]) 
    ratiofix
    


end
saveas(gcf,sprintf('figures/10minutessuperclustering%03i.png',i))