%readFakeHimawari for matlab 2020
clc;clear
%read geotiff
[A1,R] = readgeoraster('himawarifakeX_transformed_4326.tif');
info=georasterinfo('himawarifakeX_transformed_4326.tif');
[A2,R] = readgeoraster('himawarifakeY_transformed_4326.tif');
A1=A1(:,:,1);
A2=A2(:,:,1);

%test upper left coordinate
[UL_lat,UL_lon] = pix2latlon(R,1.5,1.5);

%test lower right coordinate
[LR_lat,LR_lon] = pix2latlon(R,4499.5,2299.5);

%read geotiff asli
[Aasli,Rasli] = readgeoraster('layer63_202005140610_HI8_AHI_TKY_b7.tif');
[UL_asli_lat,UL_asli_lon] = pix2latlon(Rasli,0.5,0.5);

%translate pixel coordinates to lon and lat 

[AX, AY]= size (A1);
lon_old = zeros(size(A1));
lat_old = zeros(size(A1));
[rows,cols] = meshgrid(1:AY,1:AX);
[lat_old,lon_old]=pix2latlon(R,cols+0.5,rows+0.5); %make it pixel center

%fabricated
lat_f=9.98:-0.02:9.98-(2998*0.02);
lon_f=89.02:0.02:89.02+(4498*0.02);
[lon,lat]=meshgrid(lon_f,lat_f);

%latc=lat(:,1);
%lonc=lon(1,:)+180; %shifting into correct position

%center is 2778,2723

%check new transformed coordinate based on pixel number
indicesX=2995;
indicesY=4344;
k1=find(A1(:,:,1)==indicesX);
k2=find(A2(:,:,1)==indicesY);
[k,ia,ib]=intersect(k1,k2);
[I,J]=ind2sub(size(A1),k);
save lookuptable A1 A2 lat lon

[long_out,lat_out]=himapixnum2longlat(2995,4344)


