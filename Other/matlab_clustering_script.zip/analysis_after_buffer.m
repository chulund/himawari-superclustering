%analysis after compare bright firewatch buffer v1 script

%remove overshoot data
dataBRI=sortrows(dataBRI,1);
k=find(dataFWT(:,1)<dataBRI(1,1));
dataFWT(k,:)=[];
k=find(dataFWT(:,1)>dataBRI(end,1));
dataFWT(k,:)=[];

fprintf('number of BRIGHT = %i\n',length(dataBRI))
fprintf('number of FIREWATCH = %i\n',length(dataFWT))
fprintf('number of agreement = %i\n',length(matchingtotal))
fprintf('agreement percentage by BRI= %.2f\n',length(matchingtotal)/length(dataBRI)*100)
fprintf('agreement percentage by FWT= %.2f\n',length(matchingtotal)/length(dataFWT)*100)
fprintf('false positive for BRI = %i\n',length(dataBRI)-length(matchingtotal))
fprintf('false positive for FWT = %i\n',length(dataFWT)-length(matchingtotal))

return

%write matching to file
fid=fopen('txtout/exact_matches.txt','W')
h=waitbar(0,'pleasewait');
for i=1:length(matchingtotal)
    waitbar(i/length(matchingtotal),h,sprintf('exact matches.txt %.2f%%',i*100/length(matchingtotal)))
    fprintf(fid,'%f,%f,%s\n',matchingtotal(i,2),matchingtotal(i,3),datestr(matchingtotal(i,1),'dd/mmm/yyyy HH:MM:SS'));
end
fclose(fid)
close(h)

%write unmatching to file
fid=fopen('txtout/exact_unmatches.txt','w')
h=waitbar(0,'pleasewait');
for i=1:length(unmatchingtotal)
    waitbar(i/length(unmatchingtotal),h,sprintf('exact unmatches.txt %.2f%%',i*100/length(matchingtotal)))
    fprintf(fid,'%f,%f,%s\n',unmatchingtotal(i,2),unmatchingtotal(i,3),datestr(unmatchingtotal(i,1),'dd/mmm/yyyy HH:MM:SS'));
end
fclose(fid)
close(h)


