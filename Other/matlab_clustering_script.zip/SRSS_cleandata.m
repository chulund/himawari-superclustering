%script to clean AHIDEA data and cut the data
clc;clear;  
% Data readme
%    latitude,longitude,temp_k,Sh,Sl,power,confidence,datetime,offset
%

%load cleaned data

load('SRSS.mat')
%get long lat time
counter=1;
for i=1:length(data)
    if ~isempty(data{i,14})&&~isempty(data{i,15})     
        hs_long(counter)=str2double(data{i,15});
        hs_lat(counter) =str2double(data{i,14});
        hs_temp(counter) =str2double(data{i,16});
        %UTC
        hs_time(counter) =datenum(data{1,7}(1:end-3),'YYYY/mm/DD HH:MM:SS');
        counter=counter+1;
    end
end

save SRSS_clean hs_long hs_lat hs_time hs_temp



