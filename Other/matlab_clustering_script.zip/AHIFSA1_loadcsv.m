%script to load AHI-FSA hotspot
clc;clear;
filename='D:\Research\2020\Hotspot\persistence\data\AHIFSA\BRIGHT_H8IBRA_data.txt';
fid=fopen(filename);
line=fgetl(fid); %skip 1st line (header)
counter=1;
while ~feof(fid)
    line=fgetl(fid);
    linesplit=strsplit(line,',','CollapseDelimiters', false);
    for i=1:7%9 %march or november
        data{counter,i}=linesplit{i};
    end
    counter=counter+1;
end
fclose(fid);
save("matfile/AHIFSA_all.mat",'data');