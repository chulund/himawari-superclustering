%function to read pixel number of himawari and outputting transformed
%long lat
%can batch process
%nur - 13 May 2020
%
%usage
%[long,lat]=himapixnum2longlat(hx,hy)
%
%input:
%hx = himawari row x
%hy = himawari column y
%
%output:
%long: longitude in GDA94
%lat:latitude in GD94
clc;clear
tic
load('matfile/AHIFSA_all_clean.mat')
%load lookuptable data
load('D:\Research\2020\Hotspot\persistence\compare2\nativeVSnearest\gdal\lookuptable.mat');

hx=hs_hx+1;
hy=hs_hy+1;

long_out=zeros(size(hx));
lat_out=zeros(size(hy));
h=waitbar(0,'please wait');
counter=1;
doubleInc=0;
for i=1:length(hx)
    waitbar(i/length(hx),h,sprintf('%.2f%%',i*100/length(hx)));
    k1=find(A1(:,:,1)==hx(i)); %find occurences in row
    k2=find(A2(:,:,1)==hy(i)); %find occurences in col
    [k,~,~]=intersect(k1,k2); %find intersection in occ.
    if ~isempty(k)
        [I,J]=ind2sub(size(A1),k); %convert found indices into matrix index
        if length(I)>1
            doubleInc=doubleInc+1;
        end
        for z=1:length(I)
            long_out(counter)=lon(I(z),J(z));
            lat_out(counter)=lat(I(z),J(z));
            counter=counter+1;
        end
    else
        long_out(counter)=NaN;
        lat_out(counter)=NaN;
        counter=counter+1;
    end
end
close(h)

hs_longT=long_out;
hs_latT=lat_out;

save matfile/AHIFSA_aus_clean hs_* 
toc