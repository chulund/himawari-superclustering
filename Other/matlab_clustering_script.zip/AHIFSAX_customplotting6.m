%% plotting heat map for each hotspot for a supercluster
clc;clear;
load('matfile/AHIFSA_aus_supercluster.mat')

superclusternumber=12;

statistics=3;
% fire severity statistic choice
% 1=SUM FRP
% 2=MEAN FRP (SUM FRP/number of hotspots)
% 3=FIRE DURATION (in hours)
% 4=NMBER OF HOTSPOTS

%calculate supercluster attribute
for i=1:length(supercluster)
    supercluster{i}.duration=(supercluster{i}.startend(2)-supercluster{i}.startend(1))*24;
    startend(i,:)=supercluster{i}.startend;
    duration(i)=supercluster{i}.duration;
end

superclusterUTM=supercluster;
for i=superclusternumber
    for m=1:length(supercluster{i}.circle.Vertices)
        longitude=supercluster{i}.circle.Vertices(m,1);
        latitude=supercluster{i}.circle.Vertices(m,2);
        xy=ell2utm([latitude;longitude;0],getUTMzone(longitude,'d'),2,'d');
        xys(m,1)=xy(1)+500000;xys(m,2)=xy(2)+10000000;                
    end
    superclusterUTM{i}.circle.Vertices=xys;
    supercluster{i}.area=area(superclusterUTM{i}.circle);
end

%get all hotspot member 
counter=1;
for i=superclusternumber
    for j=1:length(supercluster{i}.hs_datas)
        if length(supercluster{i}.hs_datas{j}.hs_long)==1
            hs_datas{counter}.hs_id=supercluster{i}.hs_datas{j}.hs_id;
            hs_datas{counter}.hs_long=supercluster{i}.hs_datas{j}.hs_long;
            hs_datas{counter}.hs_lat=supercluster{i}.hs_datas{j}.hs_lat;
            hs_datas{counter}.hs_frp=supercluster{i}.hs_datas{j}.hs_frp;
            hs_datas{counter}.hs_time=supercluster{i}.hs_datas{j}.hs_time;
            hs_datas{counter}.hs_circle=supercluster{i}.hs_datas{j}.hs_circle;
            counter=counter+1;
        else
            for k=1:length(supercluster{i}.hs_datas{j}.hs_long)
                hs_datas{counter}.hs_id=supercluster{i}.hs_datas{j}.hs_id(k,:);
                hs_datas{counter}.hs_long=supercluster{i}.hs_datas{j}.hs_long(k);
                hs_datas{counter}.hs_lat=supercluster{i}.hs_datas{j}.hs_lat(k);
                hs_datas{counter}.hs_frp=supercluster{i}.hs_datas{j}.hs_frp(k);
                hs_datas{counter}.hs_time=supercluster{i}.hs_datas{j}.hs_time(k);
                hs_datas{counter}.hs_circle=supercluster{i}.hs_datas{j}.hs_circle{k};
                counter=counter+1;
            end
        end
    end
end
    
%grouping based on position

for i=1:length(hs_datas)
    hs_long(i)=hs_datas{i}.hs_long;
    hs_lat(i)=hs_datas{i}.hs_lat;
end

G=findgroups(hs_long,hs_lat);
hs_grouping{max(G)}=[];
for i=1:length(hs_datas)
    hs_grouping{G(i)}{length(hs_grouping{G(i)})+1}=hs_datas{i};
end

%get group attribute
frp_group(max(G),1)=0;
for i=1:length(frp_group)
    frp_total=0;
    number_of_miss=0;
    for j=1:length(hs_grouping{i})
        %get time vector
            hs_time(j)=hs_grouping{i}{j}.hs_time;
        %get sum of frp
        if ~(hs_grouping{i}{j}.hs_frp==-999);
            frp_total=frp_total+hs_grouping{i}{j}.hs_frp;
        else
            number_of_miss=number_of_miss+1;
        end
    end
    frp_group(i,1)=hs_grouping{i}{1}.hs_long; %longitude per point
    frp_group(i,2)=hs_grouping{i}{1}.hs_lat; %latitude per point
    frp_group(i,3)=frp_total; %frp sum per point
    frp_group(i,4)=length(hs_grouping{i}); % number of points
    frp_group(i,5)=number_of_miss; % number of missing frp
    frp_group(i,6)=(max(hs_time)-min(hs_time))*24; % fire duration (in hours)
    if isa(hs_grouping{i}{1}.hs_circle,'polyshape')
        frp_circle{i}.hs_circle=hs_grouping{i}{1}.hs_circle;
    else
        frp_circle{i}.hs_circle=hs_grouping{i}{1}.hs_circle{1};
    end

end

frp_plot(:,1)=normalize(frp_group(:,3),'range');  %normalized sum frp 
%make normalized value +0.01 for visibility
for i=1:length(frp_group)
    if ~(frp_plot(i,1)>=0.9999999999)
        frp_plot(i,1)=frp_plot(i,1)+0.01;
    end
end
frp_plot(:,2)=normalize(frp_group(:,3)./frp_group(:,4),'range'); %normalized mean frp
frp_plot(:,3)=normalize(frp_group(:,6),'range');  %normalized fire duration
frp_plot(:,4)=normalize(frp_group(:,4),'range');  %normalized number of points
                            
figure
load coast_i_aus
plot(long,lat)
hold on
cmap=flipud(brighten(autumn(6),0.2));
xlim([min(supercluster{superclusternumber}.circle.Vertices(:,1))-0.3
    max(supercluster{superclusternumber}.circle.Vertices(:,1))+0.3])
ylim([min(supercluster{superclusternumber}.circle.Vertices(:,2))-0.3
    max(supercluster{superclusternumber}.circle.Vertices(:,2))+0.3])

counter=1;counter2=1;
for i=superclusternumber
    plot(supercluster{i}.circle,'FaceColor','none','LineStyle','--')
    for j=1:length(frp_plot)
        switch statistics
            case 1
                plot(frp_circle{j}.hs_circle,'FaceColor',[1 0 0],'FaceAlpha',frp_plot(j,1),'LineStyle','none') %sum
            case 2
                plot(frp_circle{j}.hs_circle,'FaceColor',[1 0 0],'FaceAlpha',frp_plot(j,2),'LineStyle','none') %mean
            case 3
                plot(frp_circle{j}.hs_circle,'FaceColor',[1 0 0],'FaceAlpha',frp_plot(j,3),'LineStyle','none') %duration
            case 4
                plot(frp_circle{j}.hs_circle,'FaceColor',[1 0 0],'FaceAlpha',frp_plot(j,4),'LineStyle','none') %number
        end
    end    
end

%put attribute
pos = arrayfun(@plotboxpos, gca, 'uni', 0);
dim = cellfun(@(x) x.*[1 1 0.5 0.5], pos, 'uni',0);
str = {,
    sprintf('Date = %s to %s',datestr(floor(supercluster{superclusternumber}.startend(1))),datestr(floor(supercluster{superclusternumber}.startend(2)))),
    sprintf('Area = %0.3f km2',supercluster{superclusternumber}.area/1000000),
    sprintf('Duration (hrs) = min %0.1f, mean %0.1f, max %0.1f',min(frp_group(:,6)),mean(frp_group(:,6)),max(frp_group(:,6))),
    sprintf('FRP = min %0.1f, mean %0.1f, max %0.1f',min(frp_group(:,3)),mean(frp_group(:,3)./frp_group(:,4)),max(frp_group(:,3))),
    sprintf('Num. Data = min %i, mean %0.1f, max %i',min(frp_group(:,4)),mean(frp_group(:,4)),max(frp_group(:,4))),
    sprintf('no FRP data = %i',sum(sum(frp_group(:,5))))}
annotation('textbox',dim{1},'String',str,'FitBoxToText','on','vert','bottom','EdgeColor','none')

switch statistics
    case 1
        title(sprintf('Fire Severity Supercluster %i (SUM FRP)',superclusternumber))
        saveas(gcf,sprintf('figures/Supercluster %i Fire Severity (FRP SUM).png',superclusternumber))
    case 2
        title(sprintf('Fire Severity Supercluster %i (MEAN FRP)',superclusternumber))
        saveas(gcf,sprintf('figures/Supercluster %i Fire Severity (FRP MEAN).png',superclusternumber))
    case 3
        title(sprintf('Fire Severity Supercluster %i (Fire Duration in hours)',superclusternumber))
        saveas(gcf,sprintf('figures/Supercluster %i Fire Severity (Fire Duration).png',superclusternumber))
    case 4
        title(sprintf('Fire Persitence Supercluster %i (Number of Hotspots)',superclusternumber))
        saveas(gcf,sprintf('figures/Supercluster %i Fire Persitence.png',superclusternumber))
end

return

%plot number of group vs total FRP
figure
bar(frp_group(:,3))
xlabel('Number of group')
ylabel('Total FRP')
title('Total FRP vs number of group')
%put attribute
pos = arrayfun(@plotboxpos, gca, 'uni', 0);
dim = cellfun(@(x) x.*[1 1 0.5 0.5], pos, 'uni',0);
str = {sprintf('number of group = %i',length(frp_group(:,3))),
    sprintf('minimum FRP = %0.3f',min(frp_group(:,3))),
    sprintf('maximum FRP = %0.3f',max(frp_group(:,3))),
    sprintf('average FRP = %0.3f',mean(frp_group(:,3)./frp_group(:,4)))}
annotation('textbox',dim{1},'String',str,'FitBoxToText','on','vert','bottom','EdgeColor','none')
saveas(gcf,sprintf('figures/FRP Statistics for Super Cluster %i.png',superclusternumber))

return

%plot number of group vs total FRP
figure
bar(frp_group(:,4))
xlabel('Number of group')
ylabel('Number of hotspot')
title('Number of hotspot vs number of group')
%put attribute
pos = arrayfun(@plotboxpos, gca, 'uni', 0);
dim = cellfun(@(x) x.*[1 1 0.5 0.5], pos, 'uni',0);
str = {sprintf('number of group = %i',length(frp_group(:,3))),
    sprintf('minimum FRP = %0.3f',min(frp_group(:,3))),
    sprintf('maximum FRP = %0.3f',max(frp_group(:,3))),
    sprintf('average FRP = %0.3f',mean(frp_group(:,3)./frp_group(:,4)))}
annotation('textbox',dim{1},'String',str,'FitBoxToText','on','vert','bottom','EdgeColor','none')
saveas(gcf,sprintf('figures/FRP Statistics for Super Cluster %i (2).png',superclusternumber))