%script to load AHI-FSA hotspot
clc;clear;
filename='D:/Research/2020/Hotspot Inter-comparison and validation/persistence/data/temp/201910312100AHI_TKY_FHS_gda2020.csv';

fid=fopen(filename);
counter=1;
line=fgetl(fid);
while ~feof(fid)
    line=fgetl(fid);
    linesplit=strsplit(line,',','CollapseDelimiters', false);
    for i=1:19
        data{counter,i}=linesplit{i};
    end
    counter=counter+1;
end
fclose(fid);

counter=1;
for i=1:length(data)
        if ~isempty(data{i,17})&&~isempty(data{i,18})     
            FWTn.hs_long(counter)=str2double(data{i,17});
            FWTn.hs_lat(counter) =str2double(data{i,18});
            time=strsplit(data{i,8},':');
            date = sprintf('%i',str2double(data{i,9}));
            FWTn.hs_time(counter) =datenum(str2double(date(1:4)),str2double(date(5:6)),str2double(date(7:8)),str2double(time{1}),str2double(time{2}),0) ...
                + datenum([0 0 0 3 0 0]); %plus 3 hour time difference between tokyo and local time
            counter=counter+1;
        end
end
    
save("FWT_new.mat",'FWTn');