%analysis after compare bright firewatch buffer v4 script
if 1
    clc;clear
    
    %select method
    method=1;
    %1.exact matches
    %2.buffering
    
    if (method==1)
        load unmatching_BRI_v4
        load unmatching_FWT_v4
        load matching_BRI_v4
        load matching_FWT_v4
    else
        load unmatching_buffer_BRI
        load unmatching_buffer_FWT
        load matching_buffer_BRI
        load matching_buffer_FWT
    end
    
    matchBRI=0;totalBRI=0;
    for i=1:length(dataBRI_epoch)
        matchBRI=matchBRI+sum(dataBRI_epoch{i}.matches);
        totalBRI=totalBRI+length(dataBRI_epoch{i}.matches);
    end
    
    matchFWT=0;totalFWT=0;
    for i=1:length(dataFWT_epoch)
        matchFWT=matchFWT+sum(dataFWT_epoch{i}.matches);
        totalFWT=totalFWT+length(dataFWT_epoch{i}.matches);
    end
    
    fprintf('BRIGHT\n')
    fprintf('number of agreement = %i\n',(matchBRI))
    fprintf('out of = %i\n',(totalBRI))
    fprintf('agreement percentage= %.2f\n',(matchBRI)/(totalBRI)*100)
    fprintf('false positive  = %i\n',(totalBRI)-(matchBRI))
    fprintf('out of = %i\n',(totalBRI))
    fprintf('false positive percentage = %.2f\n',((totalBRI)-(matchBRI))/(totalBRI)*100)
    fprintf('FIREWATCH\n')
    fprintf('number of agreement = %i\n',(matchFWT))
    fprintf('out of = %i\n',(totalFWT))
    fprintf('agreement percentage= %.2f\n',(matchFWT)/(totalFWT)*100)
    fprintf('false positive  = %i\n',(totalFWT)-(matchFWT))
    fprintf('out of = %i\n',(totalFWT))
    fprintf('false positive percentage = %.2f\n',((totalFWT)-(matchFWT))/(totalFWT)*100)

end

if 0
    %write unmatching to file
    fid=fopen('txtout/exact_unmatches_FWT.txt','w')
    h=waitbar(0,'pleasewait');
    for i=1:length(unmatchingtotal)
        waitbar(i/length(unmatchingtotal),h,sprintf('exact unmatches.txt %.2f%%',i*100/length(unmatchingtotal)))
        fprintf(fid,'%f,%f,%s\n',unmatchingtotal(i,2),unmatchingtotal(i,3),datestr(unmatchingtotal(i,1),'dd/mmm/yyyy HH:MM:SS'));
    end
    fclose(fid)
    close(h)

    %write matching to file
    fid=fopen('txtout/exact_matches.txt','W')
    h=waitbar(0,'pleasewait');
    for i=1:length(matchingtotal)
        waitbar(i/length(matchingtotal),h,sprintf('exact matches.txt %.2f%%',i*100/length(matchingtotal)))
        fprintf(fid,'%f,%f,%s\n',matchingtotal(i,2),matchingtotal(i,3),datestr(matchingtotal(i,1),'dd/mmm/yyyy HH:MM:SS'));
    end
    fclose(fid)
    close(h)
end
return


clc;clear;
load unmatching_FWT
load dataBRI_epoch
%remove overshoot data
datebegin=737516;
dateendin=737881.993055556;
unmatchingtotal_FWT=sortrows(unmatchingtotal_FWT,1);
k=find(unmatchingtotal_FWT(:,1)<datebegin);
fprintf('removing %i data before %s\n',length(k),datestr(datebegin));
unmatchingtotal_FWT(k,:)=[];
k=find(unmatchingtotal_FWT(:,1)>dateendin);
fprintf('removing %i data after %s\n',length(k),datestr(dateendin));
unmatchingtotal_FWT(k,:)=[];

if 1
    %write unmatching to file
    fid=fopen('txtout/exact_unmatches_FWT.txt','w')
    h=waitbar(0,'pleasewait');
    for i=1:length(unmatchingtotal_FWT)
        waitbar(i/length(unmatchingtotal_FWT),h,sprintf('exact unmatches FWT.txt %.2f%%',i*100/length(unmatchingtotal_FWT)))
        fprintf(fid,'%f,%f,%s\n',unmatchingtotal_FWT(i,2),unmatchingtotal_FWT(i,3),datestr(unmatchingtotal_FWT(i,1),'dd/mmm/yyyy HH:MM:SS'));
    end
    fclose(fid)
    close(h)
end
return
for i=1:length(unmatching_FWT)
    FWTunmatchcount(i,1)=unmatching_FWT{i}.count;
    FWTunmatchcount(i,2)=i;
end
k=27603;
figure
load coast_i_aus.mat
plot(long,lat)
hold on
h1=plot(unmatching_FWT{k}.data(:,1),unmatching_FWT{k}.data(:,2),'o','MarkerSize',5,'Color','blue')
%plot(unmatchingtotal_FWT(:,2),unmatchingtotal_FWT(:,3),'x')

for i=1:length(dataBRI_epoch)
    if dataFWT_epoch{k}.epoch==dataBRI_epoch{i}.epoch
        m=i;
        break
    end
end

h2=plot(dataBRI_epoch{m}.data(:,1),dataBRI_epoch{m}.data(:,2),'x','MarkerSize',7,'Color','red','MarkerFaceColor','red','LineWidth',1.25);
title(sprintf('BRIGHT vs FIREWATCH %s',datestr(dataBRI_epoch{m}.epoch,'HH:MM dd-mmm-yyyy')))
legend([h2,h1],{'BRIGHT','FIREWATCH'})
ratiofix

return



