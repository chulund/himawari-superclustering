%script to cluster the dailydata
clc;clear;
load('matfile/BRIGHT_aus_daily.mat')
tic
%search radius in m
radius=3500;

%timing threshold in minutes
timeThres=20;

%get data for the day
datecheck=datenum([2020 01 04 0 0 0]);

%difference in day threshold (in day)
threshold=1;

%plotting each day
plotting=1;

%only include chosen clusters
includeanim=0;

for i=1:length(dailydata)
    if datenum(dailydata{i}.date)==datecheck
        k_starts=i;
        break
    end
end
datatoday=dailydata{k_starts};
[unique10minutes,~,c]=unique(datatoday.hs_time);
for i=1:length(unique10minutes)
    k=find(c==i);
    dataper10min{i}.hs_long=datatoday.hs_long(k);
    dataper10min{i}.hs_lat=datatoday.hs_lat(k);
    dataper10min{i}.hs_time=datatoday.hs_time(k);
    dataper10min{i}.hs_id=datatoday.hs_id(k);
end

for k=1:length(dataper10min)
    %take todays data
    hs_long=dataper10min{k}.hs_long;
    hs_lat=dataper10min{k}.hs_lat;
    hs_time=dataper10min{k}.hs_time;
    hs_id=dataper10min{k}.hs_id;
    
    if isempty(hs_long)
        continue
    end
    fprintf('processing date %s\n',datestr(floor(hs_time(1))))
    
    cor=[];
    fprintf('     1.creating circle\n')
    for i=1:length(hs_long)

        %create circle to check radius
        %[xv,yv] = createcircle(hs_long(i),hs_lat(i),radius,pi/5);
        newcircle = nsidedpoly(10, 'Center',[hs_long(i),hs_lat(i)], 'Radius', rad2deg(radius/6378137));
        xv=newcircle.Vertices(:,1);
        yv=newcircle.Vertices(:,2);

        [in,on] = inpolygon(hs_long,hs_lat,xv,yv);
        
        %create a corelation matrix
        cor(i,:)=in;
        
        %save circle
        hs_circle{i}=newcircle;
        
    end    

    %update corelation matrix to also consider time difference
    fprintf('     2.considering time difference\n')
    timediffcnt=0;
    if timeThres
        for i=1:length(cor)
            for j=1:length(cor)
                %skip if self correlation
                if i==j
                    continue
                end
                %skip if correlation is zero
                if cor(i,j)==0
                    continue
                end
                %check if time difference > threshold
                timediff=hs_time(i)-hs_time(j);
                if (timediff*1440)>abs(timeThres)
                    cor(i,j)=0; %set correlation to 0
                    timediffcnt=timediffcnt+1;
                end
            end
        end
    end

    %spatial clustering
    cor_check=cor;

    counter2=1; % for each cluster
    aggregate=[];
    fprintf('     3.spatial clustering\n')
    for i=1:length(cor_check)
        cor_process=cor_check(i,:);
        if sum(cor_process)==0
            continue
        end
        %remove self correlation
        cor_check(i,i)=0;

        member=[];
        looping=[];
        counter=1;
        member(counter)=i;
        cor_check(i,:)=0;

        index=[];index=find(cor_process);
        if isempty(index)
            aggregate{counter2}=member;
            counter2=counter2+1;
        end

        looping=[looping;index'];
        while ~isempty(looping)

            counter=counter+1;
            member(counter)=looping(1,1);

            index=[];
            index=find(cor_check(looping(1,1),:));        
            if ~isempty(index)
                looping=[looping;index'];
            end
            %remove visited row
            cor_check(looping(1,1),:)=0;
            looping(1)=[];

        end
        aggregate{counter2}=unique(member);
        counter2=counter2+1;

    end

    cluster_HS{k}=aggregate';
    
    %creating a cluster structure
    fprintf('     4.creating a structure\n')
    
    %declare a structure
    doy = day(datetime(datevec(floor(hs_time(1)))),'dayofyear');
    dailyaggregate{k}.date=datestr(floor(hs_time(1)));
    dailyaggregate{k}.numcluster=length(aggregate);
    
    %insert HS info into dailyaggregate
    for i=1:length(aggregate)
        %make an ID
        doy = day(datetime(datevec(floor(hs_time(1)))),'dayofyear');
        year=datevec(days(1));
        yy=year(1)-2000;
        dailyaggregate{k}.clusters{i}.id=sprintf('CS%02d%03d_%04i',yy,doy,i);
        %make a startenddate
        dailyaggregate{k}.clusters{i}.startend=[min(hs_time(aggregate{i})) max(hs_time(aggregate{i}))];
        dailyaggregate{k}.clusters{i}.numHS=length(aggregate{i});
        %make a cluster circle
        n=polyshape();
        for j=1:length(aggregate{i})
            n = union(n, hs_circle{aggregate{i}(j)});
        end
        dailyaggregate{k}.clusters{i}.circle=n;
        
        for j=1:length(aggregate{i})
            dailyaggregate{k}.clusters{i}.hs_data.hs_id(j,:)=hs_id(aggregate{i}(j),:);
            dailyaggregate{k}.clusters{i}.hs_data.hs_long(j,1)=hs_long(aggregate{i}(j));
            dailyaggregate{k}.clusters{i}.hs_data.hs_lat(j,1)=hs_lat(aggregate{i}(j));
            dailyaggregate{k}.clusters{i}.hs_data.hs_time(j,1)=hs_time(aggregate{i}(j));
            dailyaggregate{k}.clusters{i}.hs_data.hs_circle{j}=hs_circle{aggregate{i}(j)};
        end        
    end 
end

fprintf('superclustering daily\n');
supercluster={};
for i=1:length(dailyaggregate)
    if isempty(dailyaggregate{i})%to prevent processing empty field
        fprintf('   warning data day %i empty\n',i)
        continue
    end    

    fprintf('   processing day %i out of %i\n',i,length(dailyaggregate));
    
    %finding intersection between clusters in a day
    cor=zeros(length(dailyaggregate{i}.clusters),length(dailyaggregate{i}.clusters));
    for j=1:length(cor)
        for k=1:length(cor)
            polyout=intersect(dailyaggregate{i}.clusters{j}.circle,dailyaggregate{i}.clusters{k}.circle);
            if ~isempty(polyout.Vertices)
                cor(j,k)=1;
            end
        end
    end
    %spatial superclusters
    cor_check=cor;

    counter2=1; % for each cluster
    aggregate=[];
    for j=1:length(cor_check)
        cor_process=cor_check(j,:);
        if sum(cor_process)==0
            continue
        end
        
        %remove self correlation
        cor_check(j,j)=0;
        
        member=[];
        looping=[];
        counter=1;
        member(counter)=j;
        cor_check(j,:)=0;

        index=find(cor_process);
        if isempty(index)
            aggregate{counter2}=member;
            counter2=counter2+1;
        end

        looping=[looping;index'];
        while ~isempty(looping)

            counter=counter+1;
            member(counter)=looping(1,1);

            index=find(cor_check(looping(1,1),:));        
            if ~isempty(index)
                looping=[looping;index'];
            end
            %remove visited row
            cor_check(looping(1,1),:)=0;
            looping(1)=[];

        end
        aggregate{counter2}=unique(member);
        counter2=counter2+1;

    end

    %creating daily supercluster structure
    for j=1:length(aggregate)
        if length(aggregate{j})==1 %still a cluster
            dailysupercluster{i}.clusters{j}.id=dailyaggregate{i}.clusters{aggregate{j}}.id;
            dailysupercluster{i}.clusters{j}.startend=dailyaggregate{i}.clusters{aggregate{j}}.startend;
            dailysupercluster{i}.clusters{j}.numHS=dailyaggregate{i}.clusters{aggregate{j}}.numHS;
            dailysupercluster{i}.clusters{j}.circle=dailyaggregate{i}.clusters{aggregate{j}}.circle;
            dailysupercluster{i}.clusters{j}.hs_data=dailyaggregate{i}.clusters{aggregate{j}}.hs_data;
        else %super cluster
            %supercluster id
            dailysupercluster{i}.clusters{j}.id=sprintf('SC');
            %supercluster cluster number
            dailysupercluster{i}.clusters{j}.clusternum=length(aggregate{j});
            %declare supercluster start and endtime
            dailysupercluster{i}.clusters{j}.startend=[0 0];
            %declare supercluster number of hotspot
            dailysupercluster{i}.clusters{j}.numHS=0;
            %declare supercluter cluster's id
            dailysupercluster{i}.clusters{j}.clusterid=[];
            %declare new supercluster circle
            newcircle=polyshape;
            for k=1:length(aggregate{j})
                newcircle = union(newcircle, dailyaggregate{i}.clusters{aggregate{j}(k)}.circle);
                %update supercluster endtime
                if (dailysupercluster{i}.clusters{j}.startend(1)==0)|(dailysupercluster{i}.clusters{j}.startend(1)>dailyaggregate{i}.clusters{aggregate{j}(k)}.startend(1));
                   dailysupercluster{i}.clusters{j}.startend(1)=dailyaggregate{i}.clusters{aggregate{j}(k)}.startend(1);
                end
                if dailysupercluster{i}.clusters{j}.startend(2)<dailyaggregate{i}.clusters{aggregate{j}(k)}.startend(2);
                   dailysupercluster{i}.clusters{j}.startend(2)=dailyaggregate{i}.clusters{aggregate{j}(k)}.startend(2);
                end
                %update supercluster hsnumber
                dailysupercluster{i}.clusters{j}.numHS=dailysupercluster{i}.clusters{j}.numHS+dailyaggregate{i}.clusters{aggregate{j}(k)}.numHS;
                %add supercluster hs data  
                dailysupercluster{i}.clusters{j}.hs_datas{k}=dailyaggregate{i}.clusters{aggregate{j}(k)}.hs_data;
                %add cluster id 
                dailysupercluster{i}.clusters{j}.clusterid{length(dailysupercluster{i}.clusters{j}.clusterid)+1}=dailyaggregate{i}.clusters{aggregate{j}(k)}.id;
            end
            %update circle
            dailysupercluster{i}.clusters{j}.circle=newcircle;
        end
    end
end


%remove cluster
if includeanim
    %read included cluster
    fid=fopen('fileout/superclusteranim.txt','r');
    readcounter=1;
    while ~feof(fid)
        temp=fgetl(fid);
        superclusternumber{readcounter}=strsplit(temp);
        readcounter=readcounter+1;
    end
    fclose(fid);
    %take only the cluster id
    readcounter=1;
    for i=1:length(superclusternumber)
        for j=1:length(superclusternumber{i})
            if (j==1)||(j==length(superclusternumber{i}))
                continue
            end
            includedcluster{readcounter}=superclusternumber{i}{j};
            readcounter=readcounter+1;
        end
    end
    %remove any cluster not included
    for i=1:length(dailysupercluster)
        clusternumber2besaved=[]; 
        if isempty(dailysupercluster{i})
            continue
        end
        for j=1:length(dailysupercluster{i}.clusters)
            if strcmp(dailysupercluster{i}.clusters{j}.id,'SC')
                for m=1:length(dailysupercluster{i}.clusters{j})
                    for k=1:length(includedcluster)
                        if strcmp(dailysupercluster{i}.clusters{j}.clusterid{m},includedcluster{k})
                            clusternumber2besaved = [clusternumber2besaved;j];
                        end
                    end
                end
            else
                for k=1:length(includedcluster)
                    if strcmp(dailysupercluster{i}.clusters{j}.id,includedcluster{k})
                        clusternumber2besaved = [clusternumber2besaved;j];
                    end
                end
            end
        end
        clusternumber2besaved = unique(clusternumber2besaved);
        dailysupercluster{i}.clusters=dailysupercluster{i}.clusters(clusternumber2besaved);
    end
end

fprintf('superclustering daily superclusterdata\n')
%checking the superclusters day by day
for i=1:length(dailysupercluster)
     if isempty(dailysupercluster{i})%to prevent processing empty field
         continue
     else
         supercluster=dailysupercluster{i}.clusters;
         savei=i;
         break
     end
end

for i=savei+1:length(dailysupercluster)
    if isempty(dailysupercluster{i})%to prevent processing empty field
        fprintf('   warning data day %i empty\n',i)
        continue
    end

    fprintf('   processing day %i out of %i\n',i,length(dailysupercluster));
    %finding intersection between supercluster and next day
    cluster2check=dailysupercluster{i}.clusters;
    cor=zeros(length(supercluster),length(cluster2check));
    for j=1:length(supercluster)
        for k=1:length(cluster2check)
            %check if there's intersection and day difference < threshold
            polyout=intersect(supercluster{j}.circle,cluster2check{k}.circle);
            if supercluster{j}.startend(1)>cluster2check{k}.startend(1)&& supercluster{j}.startend(2)<cluster2check{k}.startend(2)
                did=0; % j is inside k
            elseif cluster2check{k}.startend(1)>supercluster{j}.startend(1)&& supercluster{j}.startend(2)>cluster2check{k}.startend(2)
                did=0; % k is inside j
            elseif supercluster{j}.startend(1)<cluster2check{k}.startend(2)&& supercluster{j}.startend(2)>cluster2check{k}.startend(1)
                did=0; % j intersect k, j precede
            elseif cluster2check{k}.startend(1)<supercluster{j}.startend(2)&& cluster2check{k}.startend(2)>supercluster{j}.startend(1)
                did=0; % j intersect k, k precede
            elseif cluster2check{k}.startend(1)>supercluster{j}.startend(2)
                did=abs(cluster2check{k}.startend(1)-supercluster{j}.startend(2)); % j & k not intersecting, j precede
            elseif supercluster{j}.startend(1)>cluster2check{k}.startend(2)
                did=abs(supercluster{j}.startend(1)-cluster2check{k}.startend(2)); % j & k not intersecting, k precede
            else
                did=[];                
            end
            if ~isempty(polyout.Vertices)&&(did<=threshold)
                cor(j,k)=1;
            end
        end
    end
    
    visitedcheck=[];
    visitcounter=0;
    
    %joining the rest into supercluster
    for j=1:length(supercluster)
        %joining matching clusters
        if sum(cor(j,:))>0
            tru=find(cor(j,:));
            %check if the cluster2check ever been visited
            cont=0;
            saved=[];
            for k=1:length(tru)
                if visitcounter>0
                    if sum(tru(k)==visitedcheck(:,1))>=1
                        cont=cont+1;
                        saved(cont)=k;                        
                    end
                end
            end
            if cont
                tru(saved)=[];
            end
            if isempty(tru)
                continue
            end            
            
            %update cluster id into supercluster
            if ~isfield(supercluster{j},'clusterid')
                supercluster{j}.clusterid{1}=supercluster{j}.id;
            end
            supercluster{j}.id=sprintf('SC');
            %declare new supercluster circle
            newcircle=supercluster{j}.circle;
            %update supercluster hs data
            if ~isfield(supercluster{j},'hs_datas')
                supercluster{j}.hs_datas{1}=supercluster{j}.hs_data;
                supercluster{j}=rmfield(supercluster{j},'hs_data');
            end
            %create new field clusternum
            if ~isfield(supercluster{j},'clusternum')
                supercluster{j}.clusternum=1;
            end

            for k=1:length(tru)
                %store visitation
                visitcounter=visitcounter+1;
                visitedcheck(visitcounter,1)=tru(k);
                visitedcheck(visitcounter,2)=j;
                
                newcircle = union(newcircle, cluster2check{tru(k)}.circle);
                %update supercluster endtime
                if supercluster{j}.startend(2)<cluster2check{tru(k)}.startend(2)
                   supercluster{j}.startend(2)=cluster2check{tru(k)}.startend(2);
                end
                %update supercluster hsnumber
                supercluster{j}.numHS=supercluster{j}.numHS+cluster2check{tru(k)}.numHS;
                %add supercluster hs data and cluster id and cluster num
                if strcmp(cluster2check{tru(k)}.id,'SC')
                    for m=1:length(cluster2check{tru(k)}.hs_datas)
                         supercluster{j}.hs_datas{1+length(supercluster{j}.hs_datas)}=cluster2check{tru(k)}.hs_datas{m};
                    end
                    for m=1:length(cluster2check{tru(k)}.clusterid)
                        supercluster{j}.clusterid{1+length(supercluster{j}.clusterid)}=cluster2check{tru(k)}.clusterid{m};
                    end
                    supercluster{j}.clusternum=supercluster{j}.clusternum+cluster2check{tru(k)}.clusternum;
                else
                    supercluster{j}.hs_datas{1+length(supercluster{j}.hs_datas)}=cluster2check{tru(k)}.hs_data;
                    supercluster{j}.clusterid{length(supercluster{j}.clusterid)+1}=cluster2check{tru(k)}.id;
                    supercluster{j}.clusternum=supercluster{j}.clusternum+1;
                end                
            end
            %update circle
            supercluster{j}.circle=newcircle;
            %add new attributes counter or add 1 to counter
            if ~isfield(supercluster{j},'updcounter')
                supercluster{j}.updcounter=1;
            else
                supercluster{j}.updcounter=supercluster{j}.updcounter+1;
            end
        end
    end
    %add unmatched to supercluster variable
    counter=length(supercluster);
    
    for j=1:length(cluster2check) 
        if sum(cor(:,j))>0
            %fprintf('\ngoes here in %i at %i',j,i)
            continue
        end
        if strcmp(cluster2check{j}.id,'SC')
            supercluster{counter+1}.id=cluster2check{j}.id;
            supercluster{counter+1}.startend=cluster2check{j}.startend;
            supercluster{counter+1}.numHS=cluster2check{j}.numHS;
            supercluster{counter+1}.circle=cluster2check{j}.circle;
            supercluster{counter+1}.hs_datas=cluster2check{j}.hs_datas;
            supercluster{counter+1}.clusterid=cluster2check{j}.clusterid;
            supercluster{counter+1}.clusternum=cluster2check{j}.clusternum;
        else
            supercluster{counter+1}.id=cluster2check{j}.id;
            supercluster{counter+1}.startend=cluster2check{j}.startend;
            supercluster{counter+1}.numHS=cluster2check{j}.numHS;
            supercluster{counter+1}.circle=cluster2check{j}.circle;
            supercluster{counter+1}.hs_data=cluster2check{j}.hs_data;
        end
        counter=counter+1;
    end
    if exist('tru')
        clear tru;
    end
    
    %=====================================================================%
    %START OF JANKY HACK 
    %rechecking intersection between supercluster
    %finding intersection between clusters in a day
    cor=zeros(length(supercluster),length(supercluster));
    for j=1:length(cor)
        for k=1:length(cor)
            %intersection
            polyout=intersect(supercluster{j}.circle,supercluster{k}.circle);
            %difference in day
            if supercluster{j}.startend(1)>=supercluster{k}.startend(1)&& supercluster{j}.startend(2)<=supercluster{k}.startend(2)
                did=0; % j is inside k
            elseif supercluster{k}.startend(1)>=supercluster{j}.startend(1)&& supercluster{j}.startend(2)>=supercluster{k}.startend(2)
                did=0; % k is inside j
            elseif supercluster{j}.startend(1)<=supercluster{k}.startend(2)&& supercluster{j}.startend(2)>=supercluster{k}.startend(1)
                did=0; % j intersect k, j precede
            elseif supercluster{k}.startend(1)<=supercluster{j}.startend(2)&& supercluster{k}.startend(2)>=supercluster{j}.startend(1)
                did=0; % j intersect k, k precede
            elseif supercluster{k}.startend(1)>supercluster{j}.startend(2)
                did=abs(supercluster{k}.startend(1)-supercluster{j}.startend(2)); % j & k not intersecting, j precede
            elseif supercluster{j}.startend(1)>supercluster{k}.startend(2)
                did=abs(supercluster{j}.startend(1)-supercluster{k}.startend(2)); % j & k not intersecting, k precede
            elseif sum(supercluster{j}.startend==supercluster{k}.startend)==2
                did=0; % j == k 
            else
                did=[]; %something weird happens
            end
            if ~isempty(polyout.Vertices)&&(did<=threshold)
                cor(j,k)=1;
            end          
        end
    end
    %spatial superclusters
    cor_check=cor;

    counter2=1; % for each cluster
    aggregate=[];
    for j=1:length(cor_check)
        cor_process=cor_check(j,:);
        if sum(cor_process)==0
            continue
        end
        
        %remove self correlation
        cor_check(j,j)=0;
        
        member=[];
        looping=[];
        counter3=1;
        member(counter3)=j;
        cor_check(j,:)=0;

        index=find(cor_process);
        if isempty(index)
            aggregate{counter2}=member;
            counter2=counter2+1;
        end

        looping=[looping;index'];
        while ~isempty(looping)

            counter3=counter3+1;
            member(counter3)=looping(1,1);

            index=find(cor_check(looping(1,1),:));        
            if ~isempty(index)
                looping=[looping;index'];
            end
            %remove visited row
            cor_check(looping(1,1),:)=0;
            looping(1)=[];

        end
        aggregate{counter2}=unique(member);
        counter2=counter2+1;

    end
    
    %creating new supercluster variable
    superclusterold=supercluster;
    supercluster={};
    for j=1:length(aggregate)
        if length(aggregate{j})==1
            supercluster{aggregate{j}}=superclusterold{aggregate{j}};
        else
            %combining instersecting supercluster
            nextSCcounter=length(supercluster)+1;
            supercluster{nextSCcounter}=superclusterold{aggregate{j}(1)};
            %update cluster id into supercluster
            if ~isfield(supercluster{nextSCcounter},'clusterid')
                supercluster{nextSCcounter}.clusterid{1}=supercluster{nextSCcounter}.id;
            end
            supercluster{nextSCcounter}.id=sprintf('SC');
            %declare new supercluster circle
            newcircle=supercluster{nextSCcounter}.circle;
            %update supercluster hs data
            if ~isfield(supercluster{nextSCcounter},'hs_datas')
                supercluster{nextSCcounter}.hs_datas{1}=supercluster{nextSCcounter}.hs_data;
                supercluster{nextSCcounter}=rmfield(supercluster{nextSCcounter},'hs_data');
            end
            %create new field clusternum
            if ~isfield(supercluster{nextSCcounter},'clusternum')
                supercluster{nextSCcounter}.clusternum=1;
            end
            for k=2:length(aggregate{j})
                newcircle = union(newcircle, superclusterold{aggregate{j}(k)}.circle);
                %update supercluster endtime %%UPDAte THIS
                if supercluster{nextSCcounter}.startend(1)>superclusterold{aggregate{j}(k)}.startend(1)
                   supercluster{nextSCcounter}.startend(1)=superclusterold{aggregate{j}(k)}.startend(1);
                end
                if supercluster{nextSCcounter}.startend(2)<superclusterold{aggregate{j}(k)}.startend(2)
                   supercluster{nextSCcounter}.startend(2)=superclusterold{aggregate{j}(k)}.startend(2);
                end
                %update supercluster hsnumber
                if isempty(supercluster{j})
                    supercluster{nextSCcounter}.numHS=0+superclusterold{aggregate{j}(k)}.numHS;
                else
                    supercluster{nextSCcounter}.numHS=supercluster{j}.numHS+superclusterold{aggregate{j}(k)}.numHS;
                end
                %add supercluster hs data and cluster id and cluster num
                if strcmp(superclusterold{aggregate{j}(k)}.id,'SC')
                    for m=1:length(superclusterold{aggregate{j}(k)}.hs_datas)
                         supercluster{nextSCcounter}.hs_datas{1+length(supercluster{nextSCcounter}.hs_datas)}=superclusterold{aggregate{j}(k)}.hs_datas{m};
                    end
                    for m=1:length(superclusterold{aggregate{j}(k)}.clusterid)
                        supercluster{nextSCcounter}.clusterid{1+length(supercluster{nextSCcounter}.clusterid)}=superclusterold{aggregate{j}(k)}.clusterid{m};
                    end
                    supercluster{nextSCcounter}.clusternum=supercluster{nextSCcounter}.clusternum+superclusterold{aggregate{j}(k)}.clusternum;
                else
                    supercluster{nextSCcounter}.hs_datas{1+length(supercluster{nextSCcounter}.hs_datas)}=superclusterold{aggregate{j}(k)}.hs_data;
                    supercluster{nextSCcounter}.clusterid{length(supercluster{nextSCcounter}.clusterid)+1}=superclusterold{aggregate{j}(k)}.id;
                    supercluster{nextSCcounter}.clusternum=supercluster{nextSCcounter}.clusternum+1;
                end
            end
            %update circle
            supercluster{nextSCcounter}.circle=newcircle;
            %add new attributes counter or add 1 to counter
            if ~isfield(supercluster{nextSCcounter},'updcounter')
                supercluster{nextSCcounter}.updcounter=1;
            else
                supercluster{nextSCcounter}.updcounter=supercluster{nextSCcounter}.updcounter+1;
            end
            
        end
    end
    %END OF JANKY HACK
    %=====================================================================%    
    
    %check and remove empty super cluster
    emptycounter=0;
    emptyvar=[];
    for j=1:length(supercluster)
        if isempty(supercluster{j})
            emptycounter=emptycounter+1;
            emptyvar(emptycounter)=j;
        end
    end
    supercluster(emptyvar)=[];
    supercluster_steps{i}=supercluster;
end

%check and remove empty super cluster steps
emptycounter=0;
emptyvar=[];
for j=1:length(supercluster_steps)
    if isempty(supercluster_steps{j})
        emptycounter=emptycounter+1;
        emptyvar(emptycounter)=j;
    end
end
supercluster_steps(emptyvar)=[];

%plotting
% for i=length(supercluster_steps):-1:1
%     supercluster=supercluster_steps(i);
% if plotting
%     figure
%     load coast_i_aus
%     plot(long,lat)
%     hold on
% 
%     cmap=distinguishable_colors(length(supercluster));
%     for z=1:length(supercluster)
%         superclustercount(z,1:2)=supercluster{z}.startend;
%     end
%     for j=1:length(supercluster)
%         if isempty(supercluster{j})
%             continue
%         end
%         %plot(supercluster{j}.circle,'FaceColor',cmap(j,:),'HoleEdgeAlpha',0.1,'FaceAlpha',0.4)
%         timeofday=supercluster{j}.startend(2)-floor(supercluster{j}.startend(2));
%         plot(supercluster{j}.circle,'FaceColor',[1-timeofday 0.1 0.1],'HoleEdgeAlpha',0.1,'FaceAlpha',1)
%         [x,y]=centroid(supercluster{j}.circle);
%         %check the end cluster number
%         if includeanim
%             cnumber=0;
%             if strcmp(supercluster{j}.id,'SC')
%                 for a=1:length(superclusternumber)
%                     for b=2:length(superclusternumber{a})-1
%                         if strcmp(supercluster{j}.clusterid{1},superclusternumber{a}{b})
%                             cnumber=str2double(superclusternumber{a}{1});
%                             break
%                         end
%                     end
%                 end
%             else
%                 for a=1:length(superclusternumber)
%                     for b=2:length(superclusternumber{a})-1
%                         if strcmp(supercluster{j}.id,superclusternumber{a}{b})
%                             cnumber=str2double(superclusternumber{a}{1});
%                             break
%                         end
%                     end
%                 end
%             end
%             text(x,y,sprintf('%i',cnumber),'Color',cmap(j,:))
%         else
%             text(x,y,sprintf('%i',j),'Color',[1-timeofday 0.1 0.1])
%         end
%     end
%     title(sprintf('Super Cluster %s %s',datestr(floor(supercluster{1}.startend(1))),datestr(max(superclustercount(:,2)),'HH:MM')))
% %         xlim([146.118838806517 148.3])
% %         ylim([-38.0924940373008 -35.8861147352058]) 
%     xlim([148 150.18])
%     ylim([-38.1 -36.6]) 
%     ratiofix
%     saveas(gcf,sprintf('figures/10minutessuperclustering%03i.png',i))
% end
% 
% close(gcf)
% 
% end
%save matfile/BRIGHT_aus_1daysupercluster.mat supercluster supercluster_steps

toc

load chirp
sound(y,Fs)