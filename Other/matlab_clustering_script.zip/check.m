%comparing HIMAWARI TIFF
clc;clear;
[A,refmat,bbox] = geotiffread('FulldiskNative.tif');
info = geotiffinfo('FulldiskNative.tif')



return
clc;clear;
t1=Tiff('FulldiskNearest.tif','r');
nearest1=read(t1);
t2=Tiff('FulldiskNative.tif','r');
native1=read(t2);

[c1,n]=imhist(nearest1);
[c2,n]=imhist(native1);

d1=pdist2(c1',c2')


t3=Tiff('AreaNearest.tif','r');
nearest2=read(t3);
t4=Tiff('AreaNative.tif','r');
native2=read(t4);

[c3,n]=imhist(nearest2);
[c4,n]=imhist(native2);

d2=pdist2(c3',c4')


