clc;clear
load coast_i_aus.mat
% figure
% %subplot(2,1,1)
% plot(long,lat,'-k')
% hold on
% plot(hs_long,hs_lat,'o','MarkerSize',2.5,...
%     'MarkerEdgeColor',[0.2 0.2 0.2],...
%     'MarkerFaceColor','red')
% rectangle('Position',[148.568011911822 -37.6863409504583 0.410358974086989 0.657522018898803],'EdgeColor','blue','LineWidth',2)
% title('BRIGHT Hotspot detection','FontSize',15)
% ratiofix
% saveas(gcf,'figures/BRIGHT_all.png')

figure
%subplot(2,1,2)
plot(long,lat,'-k')
hold on
load('D:\Research\2020\Hotspot\persistence\clustering_BRIGHT\matfile\BRIGHT_all_clean.mat')
h1=plot(hs_long,hs_lat,'o','MarkerSize',5,...
    'MarkerEdgeColor',[0.2 0.2 0.2],...
    'MarkerFaceColor','red')
load('D:\Research\2020\Hotspot\persistence\clustering_FIREWATCH\matfile\FIREWATCH_all_clean.mat')
k=find(hs_lat>-10.5);
hs_long(k)=[];hs_lat(k)=[];
h2=plot(hs_long,hs_lat,'x','MarkerSize',10,...
    'color','blue','LineWidth',1.2)
xlim([148.368011911822 148.978370885909])
ylim([-37.6863409504583 -37.0288189315595])
title('BRIGHT vs FIREWATCH','FontSize',15)
legend([h1,h2],{'BRIGHT','Firewatch'})
ratiofix
saveas(gcf,'figures/BRIGHTvsFIREWATCH.png')