% function to create a himawari pixel based on the pixel centre coordinates
% input long,lat center

function figureout= createhimawaribox(long,lat)
    figureout = nsidedpoly(4, 'Center',[long,lat], 'Radius', 0.01);
end