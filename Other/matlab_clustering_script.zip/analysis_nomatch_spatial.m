%analysis Firewatch unmatch

clc;clear
load matching_FWT.mat
load unmatching_FWT.mat
load matching_BRI.mat
load unmatching_BRI.mat

load nomatch_negative_FWT 

for i=1:length(dataFWT_epoch)
    anu1(i,1)=sum(dataFWT_epoch{i}.matches);
    anu1(i,2)=dataFWT_epoch{i}.epoch;
end

for i=1:length(dataBRI_epoch)
    anu2(i,1)=sum(dataBRI_epoch{i}.matches);
    anu2(i,2)=dataBRI_epoch{i}.epoch;
end

if 1
    %plot all figure with particular time
    for i=1:length(nomatch_negative)
        k=find((anu1(:,2)==(nomatch_negative(i,4))));
        m=find((anu2(:,2)==datenum(datestr(nomatch_negative(i,4)))));
        
        figure
        load coast_i_aus.mat
        plot(long,lat)
        hold on
        h1=plot(dataFWT_epoch{k}.data(:,1),dataFWT_epoch{k}.data(:,2),'o','MarkerSize',5,'Color','blue');%,'MarkerFaceColor','blue');
        if ~isempty(m)
            h2=plot(dataBRI_epoch{m}.data(:,1),dataBRI_epoch{m}.data(:,2),'x','MarkerSize',7,'Color','red','MarkerFaceColor','red','LineWidth',1.25);
        end
        title(sprintf('BRIGHT vs FIREWATCH %s',datestr(dataFWT_epoch{k}.epoch,'HH:MM dd-mmm-yyyy')))
        legend([h2,h1],{'BRIGHT','FIREWATCH'})
        ratiofix
        if ~isempty(m)
        %put attribute
            pos = arrayfun(@plotboxpos, gca, 'uni', 0);
            dim = cellfun(@(x) x.*[1 1 0.5 0.5], pos, 'uni',0);
            str = {sprintf('number of unmatch FWT = %i',length(dataFWT_epoch{k}.data(:,1))-length(dataBRI_epoch{m}.data(:,1))),
                sprintf('number of BRI = %i',length(dataBRI_epoch{m}.data(:,1))),
                sprintf('number of FWT = %i',length(dataFWT_epoch{k}.data(:,1))),
                sprintf('matches = %i (%.2f%%) of BRI',anu2(m,1),anu2(m,1)*100/length(dataBRI_epoch{m}.data(:,1)))}
            annotation('textbox',dim{1},'String',str,'FitBoxToText','on','vert','bottom','EdgeColor','none')
        end
        saveas(gcf,sprintf('figures/nomatch_spatial/%04d.png',i));
        close(gcf)
    end
end