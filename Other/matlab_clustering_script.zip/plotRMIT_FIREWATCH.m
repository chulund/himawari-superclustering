clc;clear;
load('FSA.mat')
load('FWT.mat')

load coast_i_aus.mat
figure
plot(long,lat,'-k')
hold on
cmap=distinguishable_colors(3);
go=.1;
h1=plot(FSA.hs_long,FSA.hs_lat,'X','Color',cmap(2,:),'MarkerFaceColor',cmap(2,:));
h2=plot(FWT.hs_long,FWT.hs_lat,'o','Color',[go go go],'MarkerFaceColor',cmap(3,:),'MarkerSize',2);
title(' RMIT and FIREWATCH Comparison','FontSize',30)
legend([h1,h2],{'RMIT','Firewatch'})
xlim([min(FSA.hs_long)-3 max(FSA.hs_long)+3])
ylim([min(FSA.hs_lat)-3 max(FSA.hs_lat)+3])
set(gcf, 'Position', get(0, 'Screensize'));a
ratiofix
saveas(gcf,'RMIT_FIREWATCH_all.png')