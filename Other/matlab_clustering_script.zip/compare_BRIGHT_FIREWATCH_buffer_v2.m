%compare BRIGHT and FIREWATCH using exact matches and tolerance (faster than v1)
clc;clear;

%select method
method=1;
%1.exact matches
%2.buffering

%count unmatch as well?
methodunmatch =1;

%which hotspot as reference
reference = 1;
%1.FIREWATCH as reference
%2.BRIGHT as reference

%part 1 loading data
fprintf('1. loading data\n')

if exist('dataBRIcomb.mat')
    load('dataBRIcomb.mat')
end
if ~exist('FWT.mat')
    FWT=load('FIREWATCH_aus_clean.mat');
    save FWT FWT
else
    load('FWT.mat')
end

dataBRI(:,1)=dataBRIcomb.hs_timeT;
dataBRI(:,2)=round(dataBRIcomb.hs_longT,2);
dataBRI(:,3)=round(dataBRIcomb.hs_latT,2);
dataBRI(:,4)=dataBRIcomb.id;

%fix BRIGHT coordinates in souther Australia to match FWT grid

k=find(dataBRI(:,3)<-35);
dataBRI(k,3)=dataBRI(k,3)-0.01;

dataFWT(:,1)=FWT.hs_time;
dataFWT(:,2)=FWT.hs_long;
dataFWT(:,3)=FWT.hs_lat;

%remove dataFWT outside of time range
datebegin=737516;
dateendin=737881.993055556;
k=find(dataFWT(:,1)<datebegin);
dataFWT(k,:)=[];
fprintf('removing %i data before %s\n',length(k),datestr(datebegin));
k=find(dataFWT(:,1)>dateendin);
dataFWT(k,:)=[];
fprintf('removing %i data after %s\n',length(k),datestr(dateendin));

fprintf('2. split into epoch\n')
if ~exist('dataBRI_epoch.mat','file')
    dataBRI=sortrows(dataBRI,1);
    uniquetime=unique(dataBRI(:,1));
    dataBRI_epoch={};
    h2=waitbar(0,'please wait');
    for i=1:length(uniquetime)
        waitbar(i/length(uniquetime),h2,sprintf('splitting epoch %.2f%%',i*100/length(uniquetime)));
        k=find(uniquetime(i)==dataBRI(:,1));
        dataBRI_epoch{i}.id=dataBRI(k,4);
        dataBRI_epoch{i}.epoch=uniquetime(i);
        dataBRI_epoch{i}.time=datestr(uniquetime(i));
        dataBRI_epoch{i}.data(:,1)=dataBRI(k,2);
        dataBRI_epoch{i}.data(:,2)=dataBRI(k,3);
    end
    close(h2)
    save dataBRI_epoch dataBRI_epoch
else
    load dataBRI_epoch
end
if ~exist('dataFWT_epoch.mat','file')
    dataFWT=sortrows(dataFWT,1);
    uniquetime=unique(dataFWT(:,1));
    dataFWT_epoch={};
    h2=waitbar(0,'please wait');
    for i=1:length(uniquetime)
        waitbar(i/length(uniquetime),h2,sprintf('splitting epoch %.2f%%',i*100/length(uniquetime)));
        k=find(uniquetime(i)==dataFWT(:,1));
        dataFWT_epoch{i}.epoch=uniquetime(i);
        dataFWT_epoch{i}.time=datestr(uniquetime(i));
        dataFWT_epoch{i}.data(:,1)=dataFWT(k,2);
        dataFWT_epoch{i}.data(:,2)=dataFWT(k,3);
    end
    close(h2)
    save dataFWT_epoch dataFWT_epoch
else
    load dataFWT_epoch
end

fprintf('3. comparing per epoch\n')
%firewatch as reference
dataFWT=sortrows(dataFWT,1);
uniquetimeFWT=unique(dataFWT(:,1));
h=waitbar(0,'pleasewait');
counter=1;counter2=1;
for i=1:length(dataBRI_epoch)
    waitbar(i/length(dataBRI_epoch),h,sprintf('%.2f%%',i*100/length(dataBRI_epoch)))
    
    %get the data
    j=find(dataBRI_epoch{i}.epoch==uniquetimeFWT);
    BRIcompare=dataBRI_epoch{i}.data;
    BRIid=dataBRI_epoch{i}.id;
    if ~isempty(j)
        FWTcompare=dataFWT_epoch{j}.data;
    else
        if methodunmatch
            sizedata=size(dataBRI_epoch{i}.data);
            dataBRI_epoch{i}.matches=zeros(sizedata(1),1);
            countunmatches=size(unmatches);
            unmatching{counter2}.date=dataBRI_epoch{i}.epoch;
            unmatching{counter2}.count=countunmatches(1);
            unmatching{counter2}.data=BRIcompare;
            unmatching{counter2}.id=BRIid;
            counter2=counter2+1;
        end
        continue
    end
    
    %comparing                
    switch method
        case 1
            idx=ismember(BRIcompare, FWTcompare, 'rows');
        case 2
            idx=ismembertol(BRIcompare, FWTcompare, 0.02, 'ByRows',1,'DataScale', [1,1]);
    end
    c = 1:length(BRIcompare(:,1));
    d = c(idx);
    e = c(~idx);
    if ~isempty(d)
        matches=BRIcompare(d,:);
        ID=BRIid(d,:);
        countmatches=size(matches);
        if ~isempty(e) && methodunmatch
            unmatches=BRIcompare(e,:);
            countunmatches=size(unmatches); 
        end
        if methodunmatch
            dataBRI_epoch{i}.matches=double(idx);
        end
    else
        matches=[];
        ID=[];
        countmatches=0;
        if methodunmatch
            unmatches=BRIcompare(e,:);
            countunmatches=size(unmatches);
            dataBRI_epoch{i}.matches=double(idx);
        end
    end

    %create cell
    if ~(countmatches==0)
        matching{counter}.date=dataBRI_epoch{i}.epoch;
        matching{counter}.count=countmatches(1);
        matching{counter}.data=matches;
        matching{counter}.id=ID;
        counter=counter+1;
    end
    if methodunmatch
        unmatching{counter2}.date=dataBRI_epoch{i}.epoch;
        unmatching{counter2}.count=countunmatches(1);
        unmatching{counter2}.data=unmatches;
        counter2=counter2+1;
    end
end
close(h)

fprintf('4. congregating matches \n')

%congregate
matchingtotal=[0,0,0];
for i=1:length(matching)
    sizetotal=size(matchingtotal);
    sizeplus=size(matching{i}.data);
    matchingtotal(sizetotal(1)+1:sizeplus(1)+sizetotal(1),1)=matching{i}.date;
    matchingtotal(sizetotal(1)+1:sizeplus(1)+sizetotal(1),2:3)=matching{i}.data;
    matchingtotal(sizetotal(1)+1:sizeplus(1)+sizetotal(1),4)=matching{i}.id;
end
matchingtotal(1,:)=[];

if method==1
    save matching matching matchingtotal
elseif method==2
    save matching_buffer matching matchingtotal
end

if methodunmatch
    fprintf('5. congregating unmatches \n')
    unmatchingtotal=[0,0,0];
    for i=1:length(unmatching)
        sizetotal=size(unmatchingtotal);
        sizeplus=size(unmatching{i}.data);
        unmatchingtotal(sizetotal(1)+1:sizeplus(1)+sizetotal(1),1)=unmatching{i}.date;
        unmatchingtotal(sizetotal(1)+1:sizeplus(1)+sizetotal(1),2:3)=unmatching{i}.data;
    end
    unmatchingtotal(1,:)=[];

    if method==1
        save unmatching unmatching unmatchingtotal dataBRI_epoch
    elseif method==2
        save unmatching_buffer unmatching unmatchingtotal dataBRI_epoch
    end
end
