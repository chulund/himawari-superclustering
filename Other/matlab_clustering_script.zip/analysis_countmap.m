clc;clear;
load('BRI.mat')
load('dataBRIcomb.mat')
load('FWT.mat')
load('matching_FWT.mat')

%% BRI image
BRItable=[BRI.hs_long;BRI.hs_lat;BRI.hs_time]';
t=array2table(BRItable(:,1:2));
[a,~,c]=unique(t,'rows');clc

data_BRI = [table2array(a) accumarray(c,1)];
s=20;
%define group
% numberofGroup=10;
% grouping=quantile(data(:,3),numberofGroup);
% [~, binId] = histc( data(:,3), grouping ) ;
% J = colormap(parula(numberofGroup+1));
% colorall=J(binId+1,:);
% 
% 
% h=gscatter(data(:,1),data(:,2),binId,colorall,'s',s);
% for i=1:length(h)
%     set(h(i),'MarkerFaceColor',colorall(i,:))
% end
figure
scatter(data_BRI(:,1),data_BRI(:,2),s,data_BRI(:,3),'filled','s')
title('BRIGHT Color Map')
ratiofix

if 0
    fid=fopen('txtout/countmap_BRI.txt','w');
    for i=1:length(data_BRI)
        fprintf(fid,'%f,%f,%i\n',data_BRI(i,1),data_BRI(i,2),data_BRI(i,3));
    end
    fclose(fid);
end

%% BRI transformed
BRITtable=[dataBRIcomb.hs_longT+0.01;dataBRIcomb.hs_latT-0.01;dataBRIcomb.hs_timeT]'; %also fixed
t=array2table(BRITtable(:,1:2));
[a,~,c]=unique(t,'rows');
data_BRIT = [table2array(a) accumarray(c,1)];
if 0
    fid=fopen('txtout/countmap_BRIT.txt','w');
    for i=1:length(data_BRIT)
        fprintf(fid,'%f,%f,%i\n',data_BRIT(i,1),data_BRIT(i,2),data_BRIT(i,3));
    end
    fclose(fid);
end


%% FWT image
FWTtable=[FWT.hs_long;FWT.hs_lat;FWT.hs_time]';
t=array2table(FWTtable(:,1:2));
[a,~,c]=unique(t,'rows');
data_FWT = [table2array(a) accumarray(c,1)];
s=20;
figure
scatter(data_FWT(:,1),data_FWT(:,2),s,data_FWT(:,3),'filled','s')
title('FIREWATCH Color Map')
ratiofix
if 0
    fid=fopen('txtout/countmap_FWT.txt','w');
    for i=1:length(data_FWT)
        fprintf(fid,'%f,%f,%i\n',data_FWT(i,1),data_FWT(i,2),data_FWT(i,3));
    end
    fclose(fid);
end

%% matching image
t=array2table(matchingtotal_FWT(:,2:3));
[a,~,c]=unique(t,'rows');
matchings = [table2array(a) accumarray(c,1)];
if 0
    fid=fopen('txtout/countmap_matching.txt','w');
    for i=1:length(matchings)
        fprintf(fid,'%f,%f,%i\n',matchings(i,1),matchings(i,2),matchings(i,3));
    end
    fclose(fid);
end