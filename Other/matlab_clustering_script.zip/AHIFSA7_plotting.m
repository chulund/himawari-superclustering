    %plot all data daily
clc;clear;
figure
load coast_i_aus
plot(long,lat)
hold on

load('matfile/AHIFSA_aus_daily.mat')
day=28;

plot(dailydata{day}.hs_long,dailydata{day}.hs_lat,'.r')
ratiofix
return

timeS=dailydata{8}.hs_time;
minimumT=min(timeS);
maximumT=max(timeS);
fullT=minimumT:1/8:maximumT+1; %4 hourly 
sumari=tabulate(timeS);
simpan=zeros(length(fullT));

for i=1:length(fullT)
    k=find(fullT(i)==sumari(:,1));
    if ~isempty(k);
        simpan(i)=i;
    end
end
fullT(find(simpan))=[];

data(:,1)=[fullT';sumari(:,1)];
data(:,2)=[zeros(length(fullT),1);sumari(:,2)];
data=sortrows(data,1);

figure
plot(data(:,1),data(:,2))
xlim([min(timeS)-datenum([0 0 0 1 0 0]) max(timeS)+datenum([0 0 0 1 0 0])])
title('Hotspot Time Series for 8 November 2019')
datetick('x','keeplimits')
ylabel('number of hotspot')
hold on
xlabel('time')
ylimit=get(gca,'YLim');
line([sumari(find(sumari(:,2)==max(sumari(:,2))),1) sumari(find(sumari(:,2)==max(sumari(:,2))),1)],[min(sumari(:,2))-.2*(max(sumari(:,2))-min(sumari(:,2))) max(sumari(:,2))+.2*(max(sumari(:,2))-min(sumari(:,2)))],'Color','red','LineStyle','--');
set(gca,'YLim',ylimit)
text(sumari(find(sumari(:,2)==max(sumari(:,2))),1)+datenum([0 0 0 0 30 0]),max(sumari(:,2)),sprintf('maximum %s with %i hotspots',datestr(sumari(find(sumari(:,2)==max(sumari(:,2))),1),'HH:MM'),max(sumari(:,2))),'Color','red')