superclusterUTM=supercluster;
for i=superclusternumber
    for j=1:length(supercluster{i}.hs_datas)
        for k=1:length(supercluster{i}.hs_datas{j}.hs_circle)
            for m=1:length(supercluster{i}.hs_datas{j}.hs_circle{k}.Vertices)
                longitude=supercluster{i}.hs_datas{j}.hs_circle{k}.Vertices(m,1);
                latitude=supercluster{i}.hs_datas{j}.hs_circle{k}.Vertices(m,2);
                xy=ell2utm([latitude;longitude;0],getUTMzone(longitude,'d'),2,'d');
                xys(m,1)=xy(1)+500000;xys(m,2)=xy(2)+10000000;                
            end
            superclusterUTM{i}.hs_datas{j}.hs_circle{k}.Vertices=xys;
        end
    end
    supercluster{i}.area=area(superclusterUTM{i}.circle);
end